#!/usr/bin/env python3
"""Build a credential-free Power Automate legacy import package, reproducibly.
Package layout follows OfficeDev/Microsoft-Teams-Shifts-Power-Automate-Templates.
A tenant import still needs to be validated by a Power Automate maker.
"""
from pathlib import Path
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'integrations/power-automate/personal-mode'
FLOW = 'f4793f1d-4370-4ac3-8a15-8f28c678f782'
API = '2655de83-4389-463b-8a2b-e0f8126cbd32'
CONNECTION = '6c7ced36-733f-4b6c-a49e-6300c9efac63'
NAME = 'BranchSuite - Personal email tasks'
API_PATH = '/providers/Microsoft.PowerApps/apis/shared_office365'
secure = {'secureData': {'properties': ['inputs', 'outputs']}}
# Compose accepts only secure inputs, which also hides its outputs in run history.
# An explicit 'outputs' entry makes Power Automate reject the entire import.
secure_compose = {'secureData': {'properties': ['inputs']}}
manifest = {
    'schema': '1.0',
    'details': {'displayName': NAME, 'description': 'Creates private tasks from your own Outlook inbox. Configure the three setup actions before enabling.', 'createdTime': '2026-09-18T00:00:00Z', 'packageTelemetryId': FLOW, 'creator': 'BranchSuite', 'sourceEnvironment': ''},
    'resources': {
        FLOW: {'type': 'Microsoft.Flow/flows', 'suggestedCreationType': 'New', 'creationType': 'Existing, New, Update', 'details': {'displayName': NAME}, 'configurableBy': 'User', 'hierarchy': 'Root', 'dependsOn': [API, CONNECTION]},
        API: {'id': API_PATH, 'name': 'shared_office365', 'type': 'Microsoft.PowerApps/apis', 'suggestedCreationType': 'Existing', 'details': {'displayName': 'Office 365 Outlook'}, 'configurableBy': 'System', 'hierarchy': 'Child', 'dependsOn': []},
        CONNECTION: {'type': 'Microsoft.PowerApps/apis/connections', 'suggestedCreationType': 'Existing', 'creationType': 'Existing', 'details': {'displayName': 'Choose your own Outlook connection'}, 'configurableBy': 'User', 'hierarchy': 'Child', 'dependsOn': [API]},
    },
}
trigger = {
    'type': 'OpenApiConnectionNotification',
    'inputs': {'parameters': {'folderPath': 'Inbox', 'importance': 'Any', 'fetchOnlyWithAttachment': False, 'includeAttachments': False}, 'host': {'apiId': API_PATH, 'connectionName': 'shared_office365', 'operationId': 'OnNewEmailV3'}, 'authentication': "@parameters('$authentication')"},
    'splitOn': "@triggerOutputs()?['body/value']",
    'runtimeConfiguration': secure,
}
actions = {
    'BranchSuite_endpoint': {'type': 'Compose', 'inputs': 'SET_ENDPOINT_FROM_BRANCHSUITE', 'runAfter': {}},
    'Mailbox_address': {'type': 'Compose', 'inputs': 'SET_YOUR_WORK_EMAIL', 'runAfter': {'BranchSuite_endpoint': ['Succeeded']}},
    'Personal_key': {'type': 'Compose', 'inputs': 'SET_PERSONAL_KEY_FROM_BRANCHSUITE', 'runAfter': {'Mailbox_address': ['Succeeded']}, 'runtimeConfiguration': secure_compose},
    'Only_when_configured': {
        'type': 'If', 'runAfter': {'Personal_key': ['Succeeded']},
        'expression': {'and': [
            {'startsWith': ["@outputs('BranchSuite_endpoint')", 'https://']},
            {'not': {'equals': ["@outputs('Mailbox_address')", 'SET_YOUR_WORK_EMAIL']}},
            {'not': {'equals': ["@outputs('Personal_key')", 'SET_PERSONAL_KEY_FROM_BRANCHSUITE']}},
        ]},
        'actions': {'Send_to_BranchSuite': {
            'type': 'Http', 'runAfter': {}, 'runtimeConfiguration': secure,
            'inputs': {'uri': "@outputs('BranchSuite_endpoint')", 'method': 'POST',
                'headers': {'Content-Type': 'application/json', 'x-personal-key': "@outputs('Personal_key')"},
                'body': {'mailboxAddress': "@outputs('Mailbox_address')", 'conversationId': "@triggerOutputs()?['body/conversationId']", 'messageId': "@triggerOutputs()?['body/id']", 'from': "@triggerOutputs()?['body/from']", 'to': "@triggerOutputs()?['body/toRecipients']", 'cc': "@triggerOutputs()?['body/ccRecipients']", 'subject': "@triggerOutputs()?['body/subject']", 'body': "@triggerOutputs()?['body/body']", 'receivedAt': "@triggerOutputs()?['body/receivedDateTime']"},
                'retryPolicy': {'type': 'exponential', 'count': 4, 'interval': 'PT20S'},
            },
        }},
        'else': {'actions': {'Setup_required': {'type': 'Terminate', 'inputs': {'runStatus': 'Cancelled'}, 'runAfter': {}}}},
    },
}
definition = {
    'name': FLOW, 'id': '/providers/Microsoft.Flow/flows/' + FLOW, 'type': 'Microsoft.Flow/flows',
    'properties': {'apiId': '/providers/Microsoft.PowerApps/apis/shared_logicflows', 'displayName': NAME, 'state': 'Stopped',
        'definition': {'$schema': 'https://schema.management.azure.com/providers/Microsoft.Logic/schemas/2016-06-01/workflowdefinition.json#', 'contentVersion': '1.0.0.0', 'parameters': {'$connections': {'defaultValue': {}, 'type': 'Object'}, '$authentication': {'defaultValue': {}, 'type': 'SecureObject'}}, 'triggers': {'When_a_new_email_arrives': trigger}, 'actions': actions, 'outputs': {}},
        'connectionReferences': {'shared_office365': {'connectionName': CONNECTION, 'source': 'Embedded', 'id': API_PATH, 'tier': 'NotSpecified'}},
        'flowFailureAlertSubscribed': True,
    },
}
files = {
    'manifest.json': manifest,
    'Microsoft.Flow/flows/manifest.json': {'packageSchemaVersion': '1.0', 'flowAssets': {'assetPaths': [FLOW]}},
    f'Microsoft.Flow/flows/{FLOW}/definition.json': definition,
    f'Microsoft.Flow/flows/{FLOW}/apisMap.json': {'shared_office365': API},
    f'Microsoft.Flow/flows/{FLOW}/connectionsMap.json': {'shared_office365': CONNECTION},
}
archive = ROOT / 'public/power-automate/BranchSuite-Personal-Mode.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for path, value in files.items():
        data = json.dumps(value, indent=2) + '\n'
        destination = SOURCE / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(data)
        item = zipfile.ZipInfo(path, date_time=(2026, 9, 18, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(item, data)
print(archive.relative_to(ROOT))
