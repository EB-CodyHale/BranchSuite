/**
 * Preload reviewed account JSON using Application Default Credentials.
 * See docs/account-import.md. Dry run by default; --apply performs one atomic batch.
 */
import { readFileSync } from 'node:fs';
import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getFirestore, Timestamp } from 'firebase-admin/firestore';
import { planAccountImport } from './lib/account-import.mjs';

function arg(name) { const at = process.argv.indexOf(`--${name}`); return at < 0 ? null : process.argv[at + 1]; }
async function main() {
  const projectId = arg('project');
  if (!projectId || !arg('input')) throw new Error('Usage: node scripts/import-accounts.mjs --project ID --input reviewed.json [--admin-id UID] [--apply]');
  const input = JSON.parse(readFileSync(arg('input'), 'utf8'));
  initializeApp({ projectId, credential: applicationDefault() });
  const db = getFirestore();
  const inventory = {};
  await Promise.all(['branches', 'accounts', 'accountUnits', 'users'].map(async (name) => {
    inventory[name] = (await db.collection(name).get()).docs.map((doc) => ({ ...doc.data(), id: doc.id, updateTime: doc.updateTime }));
  }));
  const plan = planAccountImport(input, inventory, { adminId: arg('admin-id') });
  console.log(JSON.stringify({ projectId, apply: process.argv.includes('--apply'), ...plan.summary }, null, 2));
  if (!process.argv.includes('--apply') || !plan.writes.length) return;
  const batch = db.batch();
  for (const write of plan.writes) {
    const ref = db.collection(write.collection).doc(write.id);
    if (write.exists === false) batch.create(ref, write.data);
    else {
      if (!(write.updateTime instanceof Timestamp)) throw new Error(`Missing concurrency precondition for ${ref.path}.`);
      batch.update(ref, write.data, { lastUpdateTime: write.updateTime });
    }
  }
  await batch.commit();
  console.log(`Committed ${plan.writes.length} writes atomically.`);
}
main().catch((error) => { console.error(error.message); process.exitCode = 1; });
