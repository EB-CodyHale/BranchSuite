/** Run against an isolated Firestore emulator only:
 * FIRESTORE_EMULATOR_HOST=127.0.0.1:8189 node scripts/test-personal-rules.mjs
 * Load firestore.rules when starting the emulator. No production access.
 */
import assert from 'node:assert/strict';
const host = process.env.FIRESTORE_EMULATOR_HOST;
if (!/^127\.0\.0\.1:\d+$/.test(host || '')) throw new Error('A loopback Firestore emulator is required.');
const project = 'demo-personal-mode';
const base = `http://${host}/v1/projects/${project}/databases/(default)/documents`;
const uid = `personal-owner-${Date.now()}`;
const other = `${uid}-other`;
const root = `personalBoards/${uid}`;
const current = Date.now();
let checks = 0;
const encode = (value) => Buffer.from(JSON.stringify(value)).toString('base64url');
function token(user) {
  return `${encode({ alg: 'none', typ: 'JWT' })}.${encode({ iss: `https://securetoken.google.com/${project}`, aud: project, sub: user, user_id: user, iat: Math.floor(current / 1000), exp: Math.floor(current / 1000) + 3600, auth_time: Math.floor(current / 1000), firebase: { sign_in_provider: 'custom', identities: {} } })}.`;
}
function field(value) {
  if (value === null) return { nullValue: null };
  if (typeof value === 'string') return { stringValue: value };
  if (typeof value === 'number') return { integerValue: String(value) };
  if (typeof value === 'boolean') return { booleanValue: value };
  if (Array.isArray(value)) return { arrayValue: { values: value.map(field) } };
  return { mapValue: { fields: fields(value) } };
}
const fields = (value) => Object.fromEntries(Object.entries(value).map(([key, value]) => [key, field(value)]));
async function request(method, path, user, value, allowed = true, patch = false) {
  const params = patch ? '?' + new URLSearchParams(Object.keys(value).map((key) => ['updateMask.fieldPaths', key])) : '';
  const response = await fetch(`${base}/${path}${params}`, {
    method, headers: { 'Content-Type': 'application/json', ...(user ? { Authorization: `Bearer ${user === 'seed' ? 'owner' : token(user)}` } : {}) },
    ...(value ? { body: JSON.stringify({ fields: fields(value) }) } : {}),
  });
  const body = await response.json();
  assert.equal(response.ok, allowed, `${method} ${path} as ${user}: ${response.status} ${JSON.stringify(body)}`);
  if (!allowed) assert.equal(response.status, 403, JSON.stringify(body));
  checks++;
}
await request('PATCH', `users/${uid}`, 'seed', { role: 'member', email: 'owner@example.com', branchIds: ['b1'], active: true });
await request('PATCH', `users/${other}`, 'seed', { role: 'admin', email: 'other@example.com', branchIds: ['b1'], active: true });
await request('PATCH', root, 'seed', { status: 'receiving', mailboxAddress: 'owner@example.com' });
const task = { scope: 'personal', ownerUid: uid, branchId: '__personal__', title: 'Private task', assigneeId: uid,
  status: 'open', completedAt: null, completedBy: null, closedByReply: null, createdAt: current - 10000, updatedAt: current - 10000 };
await request('PATCH', `${root}/tasks/personal_test`, 'seed', task);
await request('PATCH', `${root}/details/personal_test`, 'seed', { bodyText: 'Private email' });
await request('PATCH', `${root}/tasks/personal_test/messages/message`, 'seed', { bodyText: 'Private followup' });
await request('PATCH', `personalIngestCredentials/${uid}`, 'seed', { tokenHash: 'hidden' });
for (const path of [root, `${root}/tasks`, `${root}/tasks/personal_test`, `${root}/details/personal_test`, `${root}/tasks/personal_test/messages/message`]) {
  await request('GET', path, uid);
  await request('GET', path, other, null, false);
  await request('GET', path, null, null, false);
}
await request('GET', `personalIngestCredentials/${uid}`, uid, null, false);
await request('GET', `personalIngestCredentials/${uid}`, other, null, false);
await request('PATCH', root, uid, { status: 'receiving' }, false, true);
await request('PATCH', `${root}/details/personal_test`, uid, { bodyText: 'overwrite' }, false, true);
await request('PATCH', `${root}/tasks/forged`, uid, task, false);
await request('PATCH', `${root}/preferences/view`, uid, { mode: 'combined' });
await request('GET', `${root}/preferences/view`, other, null, false);
await request('PATCH', `${root}/preferences/view`, uid, { mode: 'public' }, false);
await request('PATCH', `${root}/preferences/view`, uid, { mode: 'personal', ownerUid: other }, false);
for (const patch of [{ ownerUid: other }, { assigneeId: other }, { branchId: 'b1' }, { title: 'tampered' }, { sourceEmail: { from: 'fake' } }, { updatedAt: current - 20000 }]) {
  await request('PATCH', `${root}/tasks/personal_test`, uid, { updatedAt: current, ...patch }, false, true);
}
await request('PATCH', `${root}/tasks/personal_test`, uid, { category: 'client-communication', updatedAt: current }, true, true);
await request('PATCH', `${root}/tasks/personal_test`, other, { status: 'done', completedBy: other, completedAt: current + 1, updatedAt: current + 1 }, false, true);
await request('PATCH', `${root}/tasks/personal_test`, uid, { status: 'done', completedBy: other, completedAt: current + 1, updatedAt: current + 1 }, false, true);
await request('PATCH', `${root}/tasks/personal_test`, uid, { status: 'done', completedBy: uid, completedAt: current + 1, updatedAt: current + 1 }, true, true);
await request('PATCH', `${root}/tasks/personal_test`, uid, { category: 'branch-operations', updatedAt: current + 2 }, false, true);
await request('PATCH', `${root}/tasks/personal_test`, uid, { status: 'open', completedBy: null, completedAt: null, closedByReply: null, updatedAt: current + 2 }, true, true);
await request('PATCH', `users/${uid}`, 'seed', { active: false }, true, true);
await request('GET', `${root}/tasks/personal_test`, uid, null, false);
await request('PATCH', `${root}/preferences/view`, uid, { mode: 'branch' }, false);
console.log(`PASS: ${checks} emulator checks for private reads, roles, credentials, preferences, mutations, completion, reopening and deactivation.`);
