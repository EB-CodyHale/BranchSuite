/**
 * First-run seed.
 *
 * Creates the branches and the first admin user document. Everything else
 * (accounts, the rest of the roster) is easier to add from the Setup tab
 * once one admin can sign in.
 *
 * The one thing this exists to get right: the user document ID has to be
 * the Firebase Auth UID, exactly. Typing that by hand in the console is
 * where first-run setup usually goes wrong, and the failure is silent --
 * you sign in, the rules find no user document, and every read is denied
 * with no clue why.
 *
 * Run it after you have signed in once, so an Auth UID exists:
 *
 *   export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
 *   node scripts/seed.mjs --uid <auth-uid> --email you@company.com \
 *     --name "Your Name" --initials YN \
 *     --b1-mailbox plx-edwardsvilleil@prologistix.com \
 *     --b2-mailbox plx-bolingbrook@prologistix.com
 *
 * The target project comes from `.firebaserc`, and prints before any write.
 * Pass --project <id> to override it.
 *
 * Safe to run twice. Branches are merged, and an existing user document
 * is left alone unless you pass --force.
 */

import { readFileSync } from 'node:fs';
import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';

/* Match these to your real branches before the first run. The IDs are
 * what land in every task and order document, so changing one later means
 * rewriting data. Short and stable beats descriptive. */
const BRANCHES = [
  { id: 'b1', name: 'Granite City', code: '30080' },
  { id: 'b2', name: 'Bolingbrook', code: '20062' },
];

function arg(name) {
  const i = process.argv.indexOf(`--${name}`);
  return i === -1 ? null : process.argv[i + 1] || null;
}

function mailboxAddresses(branchId) {
  const value = arg(`${branchId}-mailbox`);
  if (!value) return null;
  const addresses = [...new Set(value.split(',').map((item) => item.trim().toLowerCase()).filter(Boolean))];
  if (!addresses.length || addresses.some((address) => !/^[^\s<>@]+@[^\s<>@]+\.[^\s<>@]+$/.test(address))) {
    console.error(`--${branchId}-mailbox must be one valid SMTP address, or a comma-separated list.`);
    process.exit(1);
  }
  return addresses;
}

const uid = arg('uid');
const email = arg('email');
const name = arg('name') || 'Admin';
const initials = arg('initials') || null;
const force = process.argv.includes('--force');

if (!uid || !email) {
  console.error('Need --uid and --email. See the comment at the top of this file.');
  process.exit(1);
}
if (!initials) {
  console.error('Need --initials. They are how you show up on the job order board.');
  process.exit(1);
}

/* Which project this writes to is decided here, from the repo, and not by
 * whatever gcloud happens to have as its current project. Application
 * default credentials carry an ambient project id, and when that is some
 * other project the writes go there instead: a bare `5 NOT_FOUND` if it has
 * no Firestore database, or, worse, a clean success against the wrong one.
 * `.firebaserc` is what `firebase use --add` wrote, so it is the intent. */
function projectFromFirebaserc() {
  try {
    const rc = JSON.parse(readFileSync(new URL('../.firebaserc', import.meta.url), 'utf8'));
    return rc.projects?.default || null;
  } catch {
    return null;
  }
}

const projectId = arg('project') || projectFromFirebaserc() || process.env.GOOGLE_CLOUD_PROJECT;

if (!projectId) {
  console.error('No project. Run `firebase use --add` first, or pass --project <id>.');
  process.exit(1);
}

initializeApp({ credential: applicationDefault(), projectId });
const db = getFirestore();

console.log(`project ${projectId}`);

const branchIds = BRANCHES.map((b) => b.id);

for (const b of BRANCHES) {
  const { id, ...rest } = b;
  const mailboxes = mailboxAddresses(id);
  const branch = {
    ...rest,
    ...(mailboxes ? { mailboxAddresses: mailboxes } : {}),
  };
  await db.collection('branches').doc(id).set(branch, { merge: true });
  console.log(`branch  ${id}  ${rest.name}`);
  if (mailboxes) console.log(`mailbox ${id}  ${mailboxes.join(', ')}`);
}

const userRef = db.collection('users').doc(uid);
const existing = await userRef.get();

if (existing.exists && !force) {
  console.log(`user    ${uid}  already exists, left alone. Pass --force to overwrite.`);
} else {
  await userRef.set({
    name,
    // Lowercased on purpose. handleReply looks a sender up with an exact
    // match on this field, so a capitalized address here means replies
    // from that person silently never close anything.
    email: email.toLowerCase(),
    initials: initials.toUpperCase(),
    role: 'admin',
    branchIds,
    marker: 'none',
    outToday: false,
  });
  console.log(`user    ${uid}  ${email.toLowerCase()}  admin on ${branchIds.join(', ')}`);
}

console.log('\nDone. Sign in and the Setup tab will let you add everyone else.');
process.exit(0);
