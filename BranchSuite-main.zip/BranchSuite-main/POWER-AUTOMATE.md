# Power Automate

How to run the supervised inbound-email flow. Read [SETUP.md](SETUP.md)
first; this needs the deployed `ingestEmail` URL, the ingest key, the exact
branch ID, and the branch's configured mailbox address.

The production rule is simple: **one enabled inbound flow owns one mailbox
stream**. Do not copy two flows and point both copies at the same mailbox.

---

## Before you start

**Check the licence.** The flow posts to a Cloud Function through the generic
**HTTP** action, which is a premium connector. It needs a Power Automate Premium
or Process licence. The Microsoft 365-specific HTTP actions cannot call the
function.

**Check mailbox access.** The account that owns the connection needs Full
Access to the shared mailbox. If that person cannot open the mailbox in Outlook
on the web, the trigger will not see it either.

**Choose the one owner for this stream.**

- If the mailbox belongs to one branch, build one flow and hard-code that
  branch's `branchId`.
- If different branches have different mailboxes, each mailbox can have its own
  flow and branch ID.
- If one mailbox receives work for multiple branches, build one flow with an
  explicit, deterministic routing step before `ingestEmail`. Do not clone the
  flow with different hard-coded branch IDs; both clones would ingest every
  message.

**Collect four values.**

| Value | Where it came from |
| --- | --- |
| `ingestEmail` URL | Functions deploy output or `firebase functions:list` |
| `BOARD_INGEST_KEY` | the secret generated in setup step 5 |
| `branchId` | the stable branch document ID seeded in setup step 7 |
| `mailboxAddress` | the exact shared-mailbox SMTP address bound to that branch |

`handleReply` is not part of this inbound flow. It requires separate outbound
capture; see [Reply completion setup and verification](#reply-completion-setup-and-verification).

---

## Idempotency contract

Every request must send a stable `messageId` from the Outlook trigger. Prefer
`internetMessageId`; fall back to the trigger's `id` when it is unavailable.
Use the same untouched value on every retry. Never generate a GUID or append a
timestamp in the flow.

The function applies two protections:

1. An exact retry with the same stable message ID replays the first result. It
   does not call the classifier or write another task.
2. A new message on a known conversation updates its single open task, including
   prior-day work. The response is `created: false`, `updated: true`. The task
   retains the new text, refreshes its summary, and can escalate priority. A
   completed same-day task receives context without reopening; completed older
   work can become a fresh task on a later Central day. Multiple open tasks
   are flagged for manual review instead of guessing which one to change.

Each stable-ID receipt also stores a fingerprint of the immutable request
fields. If the flow later reuses that `messageId` with a different conversation,
sender, subject, text body, or received time, ingestion returns HTTP 409 with
`messageId was already used for different message content`. This catches a
broken ID mapping instead of replaying the wrong result. Fix the mapping; never
generate a replacement ID to bypass the conflict.

Requests without `messageId` are rejected. This keeps retries safe even when a
run is retried across Central midnight.

Tasks receive a `boardDate` such as `2026-09-10`, calculated in
`America/Chicago`. At midnight Central the app advances to the next day
automatically. Open tasks from earlier dates carry forward with their original
date and owner. Tasks completed that day remain in Cleared until the next day;
there is no close-out flow or snapshot action.

---

## Build the flow

### 1. Create one automated cloud flow

Go to [make.powerautomate.com](https://make.powerautomate.com). Check the
environment in the top right because flows are not visible across environments.

Choose **Create, Automated cloud flow**. Name it for both the mailbox and
branch, for example `Board intake - Granite City mailbox`. Select **When a new
email arrives in a shared mailbox (V2)**.

During the supervised pilot, open the trigger's **Settings**, turn on
**Concurrency Control**, and set the degree of parallelism to `1`. The backend
is still idempotent, but sequential runs make the first launch easier to inspect.

### 2. Configure the trigger

- **Mailbox Address:** the shared mailbox SMTP address. Type it directly.
- **Folder:** `Inbox`.
- **Include Attachments:** off.
- **Only with Attachments:** off.

Leave the subject and sender filters empty. The explicit noise condition below
is easier to inspect and adjust.

Exchange/Outlook rules that immediately move mail out of Inbox can win the race
against this folder trigger. Microsoft documents that an Inbox trigger is not
expected to fire for messages rules move into another folder. During the pilot,
disable those moves or reproduce them as actions near the end of this flow,
after `Post to ingestEmail`. If mail must land in a different folder first,
point the trigger at that final folder and test every rule destination that is
meant to reach the board. See the
[Office 365 Outlook connector limits](https://learn.microsoft.com/en-us/connectors/office365/#trigger-behavior-when-an-email-folder-is-changed).

Copy the exact SMTP address you typed here. Step 7 sends that same literal as
`mailboxAddress`; the function checks it against the selected branch before it
classifies or writes anything.

### 3. Capture the stable message ID

Add **Compose** and rename it `Stable message ID`. On the expression tab, use:

```text
if(
  empty(triggerOutputs()?['body/internetMessageId']),
  triggerOutputs()?['body/id'],
  triggerOutputs()?['body/internetMessageId']
)
```

Do not use `guid()`, `utcNow()`, a run ID, or the conversation ID here. A
conversation identifies a thread; `messageId` identifies this exact delivery
and makes retries safe.

### 4. Convert the body to text

Add **Html to text** from the Content Conversion connector. Set **Content** to
the trigger's **Body** field.

Use this action's output everywhere below. Do not use **Body Preview**, which is
truncated and can omit the sentence that makes the email actionable.

### 5. Drop obvious noise

Add **Condition** and rename it `Is this noise`. Build three rows joined with
**Or**:

| Left expression | Operator | Right |
| --- | --- | --- |
| `startsWith(triggerOutputs()?['body/subject'], 'Automatic reply')` | is equal to | `true` |
| `startsWith(triggerOutputs()?['body/subject'], 'Undeliverable')` | is equal to | `true` |
| `contains(toLower(triggerOutputs()?['body/from']), 'no-reply')` | is equal to | `true` |

Paste the left side through the expression tab. In **If yes**, add **Terminate**
with status `Succeeded`. Put every remaining action in **If no**.

Keep this filter narrow. Ambiguous messages should reach the classifier.

### 6. Store the key

Preferred: put the flow in a **Solution**, create a Text environment variable
for `BOARD_INGEST_KEY`, and use the environment variable in the HTTP header.

If the key must be pasted into the action, open the HTTP action's **Settings**
and enable **Secure Inputs** and **Secure Outputs**. That hides it from run
history, but people who can edit the flow can still inspect it.

### 7. Post to ingestEmail

Add **HTTP** and rename it `Post to ingestEmail`.

- **Method:** `POST`
- **URI:** the `ingestEmail` URL
- **Headers:**

```text
Content-Type: application/json
x-board-key: <the key or environment-variable reference>
```

Use this body, replacing the literal branch ID and mailbox address. The current
Bolingbrook branch is `b2`:

```json
{
  "branchId": "b2",
  "mailboxAddress": "plx-bolingbrook@prologistix.com",
  "messageId": "@{outputs('Stable_message_ID')}",
  "from": "@{triggerOutputs()?['body/from']}",
  "to": "@{triggerOutputs()?['body/toRecipients']}",
  "cc": "@{triggerOutputs()?['body/ccRecipients']}",
  "subject": "@{triggerOutputs()?['body/subject']}",
  "body": "@{body('Html_to_text')}",
  "conversationId": "@{triggerOutputs()?['body/conversationId']}",
  "webLink": "@{triggerOutputs()?['body/webLink']}",
  "receivedAt": "@{triggerOutputs()?['body/receivedDateTime']}"
}
```

Power Automate action references use internal names with underscores. If you
renamed either action differently, select its dynamic output in the designer or
adjust `Stable_message_ID` and `Html_to_text` accordingly.

`to` and `cc` are the trigger's semicolon-separated recipient strings. They are
shown in the task drawer (who a teammate's reply went to, especially) and given
to the classifier. They also drive the timecards rule: an EmployBridge
`timecards.*` or `timcards.*` sender is skipped with `timecards email not
addressed to this branch` unless one of the branch's configured
`mailboxAddresses`, or an active board user in that branch, is on the To line. Add any alias the branch receives mail at
to that list. If a flow omits `to`, nothing is skipped. Recipients are not part
of the retry fingerprint, so adding them does not make old runs return 409.

Keep `mailboxAddress` a deliberate literal in a one-mailbox flow. Do not derive
it from To/Cc headers: aliases, distribution lists, and forwarding can make
those values differ from the Inbox the trigger actually watches.

Outlook's `receivedDateTime` includes a timezone designator. If this field is
ever supplied from another source, it must be Unix milliseconds or an ISO 8601
string ending in `Z` or an explicit offset such as `-05:00`.

Leave the HTTP action's normal retry policy in place. Retries are safe because
the body reuses the trigger's stable `messageId`.

### 8. Read the answer, then stop

Add **Parse JSON** with the HTTP response body as **Content** and this schema:

```json
{
  "type": "object",
  "properties": {
    "created": { "type": "boolean" },
    "updated": { "type": "boolean" },
    "closed": { "type": "boolean" },
    "closeReason": { "type": "string" },
    "priority": { "type": "string" },
    "reason": { "type": "string" },
    "taskId": { "type": "string" },
    "assigned": { "type": "boolean" },
    "needsAccountReview": { "type": "boolean" },
    "jobOrderId": { "type": ["string", "null"] },
    "jobOrderCreated": { "type": "boolean" },
    "jobOrderUpdated": { "type": "boolean" }
  }
}
```

The outcomes are:

| Response | Meaning | Next action |
| --- | --- | --- |
| `created: true` | actionable message created a task, or an exact retry replayed that original success | stop |
| `created: true`, `jobOrderCreated: true` | the task and its account-linked order were created together | stop; verify the requested number of blank openings |
| `created: false`, `no action required` | classifier intentionally skipped it | stop |
| `created: false`, `timecards email not addressed to this branch` | a timecards mailbox copied the branch without addressing it; no model call | stop |
| `created: false`, `updated: true` | follow-up saved to its existing task; context/urgency refreshed | inspect the latest update and Email replies in the drawer |
| `created: false`, `updated: false`, `multiple open tasks match this thread` | ambiguous existing work | choose/resolve duplicate tasks manually, then resubmit the original run |
| HTTP 409, `messageId was already used for different message content` | the ID was reused with a different immutable payload | fail the run and fix the field mapping |

An exact retry replays the original response, so it can legitimately return
`created: true` again even though no second document was written. Idempotency is
verified by counting cards, not by expecting a different retry response.
`needsAccountReview: true` means the task was safely left for a manager to pick
the account/location in the drawer; it is not a failed run.
`jobOrderId: null` means no order was guessed. The expanded task shows whether
the blocker was unresolved routing or a missing exact headcount. Once a manager
resolves routing, the same drawer can create the linked openings without
retyping the request.

HTTP 502 (classification failed) and HTTP 503 (task changed during processing)
are retryable with the exact original payload. Leave the normal HTTP retry
policy enabled.

HTTP 409 is deliberately not a duplicate-success response. Do not catch it and
resubmit with a generated ID; doing so would defeat the protection.

Send every client follow-up to `ingestEmail` with its own stable message ID and
the same conversation ID. Do not filter out replies or terminate the flow just
because that conversation has already been seen. Incoming client messages update
context and urgency; a client message never completes work. A reply that reaches
this inbox from an active board user in the branch (a teammate who replied all
with the shared mailbox copied, for example) also gets the same strict completion
check as `handleReply`. It can complete a single open task, shown under
**Completed by reply**, and the response includes `closed` and `closeReason`.
Replies from people who are not on the branch roster only add context.
`handleReply` remains the path for team replies that never reach this inbox.

Save the flow, leave it off until the pilot steps below are ready, and turn it
on only while someone is watching run history and the board.

---

## Supervised launch test

Use a unique subject tag such as `BS-PILOT-20260910-01` so the run is easy to
find. Avoid real client PII in the first tests.

1. Turn on this one flow and send one realistic order email to its shared
   mailbox. Use a configured account contact and state one exact headcount,
   role, and location.
2. Open **My flows, the flow, Run history**. Confirm `Post to ingestEmail`
   returned HTTP 200 and inspect the response.
3. Open [`suite.ebtools.pro`](https://suite.ebtools.pro) and confirm exactly one
   card appears under the correct branch and today's Central date, with the
   expected account and owner. Open **Job orders** and confirm one linked order
   has exactly the requested number of blank lines. If that account has no
   owner, confirm the order says **Unowned** and shows no person's initials.
4. Use **Resubmit** on that same flow run. It must leave the board at exactly
   one card, even if the replayed response still says `created: true`.
5. Send a follow-up in the same conversation adding a 10am cutoff, then a later
   message stating the cutoff was missed and nobody replied. Each should return
   `created: false`, `updated: true`, keep one card, and appear in its Email
   replies. The summary should include the deadline and escalation, and the
   missed deadline should mark the task Hot. Resubmit a follow-up: the reply
   count must not increase. Repeat with a carried task from yesterday.
6. Send a harmless confirmation with a new subject tag. It should return
   `created: false` and `no action required`.
7. Complete the test card manually on the board. Keep the flow supervised until
   normal mailbox traffic has produced several correctly routed results.
8. Before broad launch, temporarily send one canary request with the wrong
   `branchId` but the same `mailboxAddress`. It must return HTTP 400 and create
   no task. Restore `b2`, save, and rerun the correct canary.

If nothing appears, inspect the function logs:

```bash
firebase functions:log --only ingestEmail
```

---

## Recover follow-ups skipped by an older deployment

Earlier versions returned `thread already on the board` without retaining that
new message. After deploying this update, resubmit each original Power Automate
run for the missing follow-ups, preferably oldest first. Keep the original
message ID, conversation ID, body, and received time unchanged. A matching old
skip receipt is upgraded once: the message is retained, the existing task is
updated, and subsequent retries replay the updated result. Already-created and
already-updated receipts remain idempotent.

The backend cannot recover text that was never stored. It needs the original
flow run or message to be delivered again. Older events are added to the
history and merged with current context. A delayed cutoff can still raise
priority; it cannot replace the newest message preview or a newer explicit deadline.

## Reply completion setup and verification

The inbound flow above does not capture outbound replies. Before enabling
`handleReply`, verify a separate capture path can observe the actual sent
message, preserve its thread ID, and identify the employee who sent it. A
client response or `thread already on the board` ingest result is not a team
completion event.

Confirm where sent messages are stored in your tenant. Shared-mailbox messages
may be saved in the employee’s Sent Items unless shared-mailbox copies are
configured. Microsoft documents [shared-mailbox sent-item storage](https://learn.microsoft.com/en-us/troubleshoot/exchange/user-and-shared-mailboxes/sent-mail-is-not-saved)
and the [Outlook connector’s folder and trigger limitations](https://learn.microsoft.com/en-us/connectors/office365/).
Do not assume changing an Inbox trigger to Sent Items provides reliable capture;
verify actual sends and retries in run history before enabling automation.

Send a separate authenticated HTTP POST to the deployed `handleReply` URL with
`Content-Type: application/json` and the same `x-board-key` secret. Preserve the
same body on every retry:

```json
{
  "branchId": "b2",
  "messageId": "<stable identifier of this exact sent reply>",
  "conversationId": "<same conversation ID as the original task email>",
  "from": "employee@example.com",
  "to": "client@example.com",
  "cc": "",
  "body": "The corrected timecard has been submitted and the payroll total is now 40 hours.",
  "receivedAt": "2026-09-14T15:30:00Z"
}
```

`from` must be the actual authenticated employee’s board email, with active
membership in the selected branch. A shared Send As address alone cannot
identify that person; the capture path must provide trustworthy employee
identity or leave the task for manual completion. Never substitute the task
owner or a fixed manager email. Send full plain text from Html to text, not
Body Preview. For this endpoint, `receivedAt` is the sent reply’s event time,
including `Z` or an explicit offset. Do not use `utcNow()` on retries. A stable
`messageId` is required; never generate one in the flow.

The handler considers tasks created on or before the reply, including prior
days. It closes only a single unambiguous open task; multiple open tasks in the
same thread are left for manual review. The original request, task summary,
and newest reply text are evaluated together. Quoted history is not evidence
of new completion. Closing a task does not close its linked job order or fill
any candidate openings.

| Result | Meaning / verification |
| --- | --- |
| `closed: true`, `awaitingConfirmation: false` | The task is complete. Find it in **Cleared** with **Completed by reply**; open it to inspect who, when, the excerpt, and the reason. |
| `closed: false` with a reason | Nothing was completed. Inspect the reason for incomplete work, unknown/inactive sender, missing branch membership, no matching task, or ambiguous tasks. |
| Exact message retry | Replays the recorded result; does not close a different task or undo a person’s subsequent reopen. Check current board state when reviewing old run results. |
| HTTP 400 / 409 / 502 / 503 | Invalid payload / conflicting message identity / model failure / concurrent task change. Inspect the response and correct the mapping or retry the same unchanged request. |

Use a harmless supervised test thread and verify these cases in run history
and on the board:

1. Leave a task open overnight (or use an existing prior-day open task). Confirm
   it is visible and claimable on today’s board, with its original date.
2. Send “I’m looking into this.” Confirm `closed: false` and the task stays open.
3. Send a reply that fully resolves the specific request. Confirm `closed: true`,
   one task in Cleared, and matching reply evidence in its drawer. Repeat with a
   resolution sentence beyond the first 400 characters.
4. Resubmit the same sent-message event. Confirm there is still one task and
   the completion time has not changed. Reopen it on the board and retry again;
   it must remain open.
5. Verify a non-member/client message, quoted completed text with a new partial
   update, and a thread with two open tasks cannot auto-complete work.
6. On the following Central day, confirm completed tasks do not carry forward
   and remaining open work does. Historical dates remain available.

Inspect backend failures with:

```bash
firebase functions:log --only handleReply
```

Deploy hosting, functions, Firestore rules, and the task indexes together when rolling out these
changes. Wait for indexes to become ready before checking live carryover. The
local tests exercise the handler with a stubbed classifier; they do not prove
that a tenant’s outbound capture flow is configured or that the live model
will classify every message correctly.

---

## Shared intake mailbox: many branches, one flow

When one mailbox receives copies of many branches' mail (each branch address has
the intake address added as a recipient, and an Outlook rule files those copies
into one folder), build **one** flow for that folder and let the function decide
the branch. Adding the next branch is then a data change in the tool, with no
flow edit.

Build it exactly like the flow above, with three differences.

1. **Trigger:** keep **When a new email arrives in a shared mailbox (V2)** and
   point **Mailbox Address** at the intake shared mailbox, with **Folder** set to
   the rule's folder rather than `Inbox`. No flow runs on anyone's personal
   mail. Keep the rule that files these copies inside that shared mailbox; a
   rule in a personal mailbox never moves the shared copy. Everything in
   [Configure the trigger](#2-configure-the-trigger) about rules racing the
   Inbox trigger applies here: point the trigger at the folder the rule actually
   files into, and confirm the connection account has Full Access to the shared
   mailbox.
2. **Body:** omit `branchId` and `mailboxAddress`, and always send `to` and `cc`.

```json
{
  "messageId": "@{outputs('Stable_message_ID')}",
  "from": "@{triggerOutputs()?['body/from']}",
  "to": "@{triggerOutputs()?['body/toRecipients']}",
  "cc": "@{triggerOutputs()?['body/ccRecipients']}",
  "subject": "@{triggerOutputs()?['body/subject']}",
  "body": "@{body('Html_to_text')}",
  "conversationId": "@{triggerOutputs()?['body/conversationId']}",
  "webLink": "@{triggerOutputs()?['body/webLink']}",
  "receivedAt": "@{triggerOutputs()?['body/receivedDateTime']}"
}
```

3. **Expect skips.** The function matches the To line against every branch's
   configured `mailboxAddresses`, then the Cc line if no To recipient matched.
   Mail for a branch that is not set up in the tool returns `created: false`
   with `no configured branch for these recipients`. That is the normal answer
   for the branches you have not onboarded yet, not a failure. Leave the run
   successful and do not add a Terminate branch for it.

| Response | Meaning |
| --- | --- |
| `no configured branch for these recipients` | no branch has one of these recipients bound, or the copy arrived without its original To/Cc headers |
| `recipients match more than one configured branch` | one message named two configured branches; route it by hand |

To onboard a branch, create it in the tool and bind its exact mailbox address
(see [SETUP.md](SETUP.md)). A branch can hold several addresses, which is how one
branch number with both a ProLogistix and a ResourceMFG mailbox is served.
Addresses must match exactly after lowercasing; a misspelled address silently
skips that branch's mail.

**One owner per branch, not just per mailbox.** If a branch already has its own
single-mailbox flow, turn that flow off before the intake flow starts covering
that branch. Both flows see the same message ID for the same branch, and the
second delivery fails when it tries to record a message that already exists.

---

## Adding another branch

Do not use **Save As** on the first flow when the copy would watch the same
mailbox. Two triggers on one Inbox both receive every message, and hard-coding a
different `branchId` does not make either one selective.

- A genuinely separate branch mailbox can get its own flow. Change the mailbox
  address, the flow name, and the `branchId`, then repeat the supervised test.
- Copies of many branches' mail landing in one folder need the single intake
  flow above, not one flow per branch.

At any moment, each mailbox stream and each branch should have exactly one
enabled owner.

---

## What breaks first, and why

**The flow will not run and HTTP shows a licence error.** The flow owner lacks a
Power Automate Premium or Process licence.

**The trigger never fires.** The connection account lost Full Access to the
shared mailbox, the connection needs reauthorization, or the flow is off.

**Every request returns 401.** `x-board-key` does not match the deployed secret.
Rotating the secret requires redeploying the functions before the new value is
live.

**Every request returns 400.** A required field such as `branchId`,
`mailboxAddress`, `messageId`, or `conversationId` is empty, the branch has no
mailbox binding, or that address is not configured for the branch. Open the
failed run and inspect the actual composed request. A custom `receivedAt`
without `Z` or an explicit UTC offset is also rejected.

**A request returns 409 with `messageId was already used for different message
content`.** The stable ID is being reused while at least one immutable request
field changes. Compare the failed run with the first run for that ID, then fix
the ID or payload mapping. Never work around this by generating a new ID.

**Retries create duplicates.** Verify `messageId` is populated from `Stable
message ID`, never regenerated, and only one enabled flow watches the mailbox.

**Tasks have titles full of markup.** The HTTP body points at the trigger's HTML
Body instead of the **Html to text** output.

**A mailbox/branch request is rejected.** The hard-coded `branchId`, literal
`mailboxAddress`, or branch document binding disagree. This is intentional.
Turn off duplicate flows, correct all three values, then repeat the canary.

**A task exists but nobody can see it.** Its `branchId` does not appear in any
intended user's `branchIds` array.
