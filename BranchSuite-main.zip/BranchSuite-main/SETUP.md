# Setup

Ordered. Each step assumes the one before it worked. Steps marked **you**
need your login or your console access and cannot be done from the repo.

Budget about half an hour for steps 1 through 6, most of it waiting on the
first deploy.

This repo targets Node.js 24. If you use `nvm`, the checked-in `.nvmrc` makes
the local runtime explicit:

```bash
nvm install
nvm use
node --version
```

---

## 1. Create the project — **you**

In the [Firebase console](https://console.firebase.google.com), create a
project. Name it whatever you like. Turn Google Analytics off, nothing here
uses it.

Then, in the project:

- **Build, Firestore Database, Create database.** Pick production mode and
  a region close to the branch. `us-central1` is the safe default. The
  region cannot be changed later.
- **Build, Authentication, Get started.**

Note the project ID. Not the display name, the ID, which is usually the
name plus a few digits.

Steps 5 and 6 need the project on the **Blaze** plan. Nothing before them
does, so you can leave it on Spark until step 5 tells you otherwise. See
the note at the top of step 5.

## 2. Point the repo at it

```bash
firebase login
firebase use --add
```

Pick the project and give it the alias `default`. This writes `.firebaserc`,
which is gitignored, so every person who clones does this once.

## 3. Fill in the web config

In the console: **Project settings, Your apps, Web, register an app.** Skip
hosting setup in that dialog, step 6 handles it.

Copy the config values into a local env file:

```bash
cp .env.example .env.local
```

Fill all six `VITE_FIREBASE_*` values. These are public client values, not
secrets. `.env.local` stays out of git anyway, so each person fills their
own or you pass the file around directly.

Sanity check before moving on:

```bash
npm run dev
```

The sign-in screen should ask for an email and a password instead of
showing the local-mode person picker. Nothing will sign in yet, step 4
turns the provider on. If you still see the picker, the env file did not
load. Restart the dev server, Vite only reads env at startup.

## 4. Email sign-in — **you**

In Firebase: **Authentication, Sign-in method, Add new provider,
Email/Password.** Enable the first toggle. Leave **Email link (passwordless
sign-in)** off, the board signs in with a password.

Then **Authentication, Settings, User actions**, and turn **Enable create
(sign-up)** off.

Do not skip that. The six values in `.env.local` are public, they ship
inside the browser bundle, and with sign-up left on anyone who reads them
can create an account in your project. The rules would show such an account
nothing, because no user document exists for its UID, but you would be
carrying a pile of junk logins. Off means accounts come from you, in the
console, which is what step 7 does.

Password resets are sent by Firebase and need nothing configured. The
wording lives in **Authentication, Templates** if you want it to say your
company name.

Last thing: **Authentication, Settings, Authorized domains.** Add the
domain you will actually serve from. Production uses `suite.ebtools.pro`.
`localhost` is there by default.

## 5. Server secrets — **you**

This is where the project has to move to **Blaze**, the pay-as-you-go plan.
Secret Manager, Cloud Functions, and any call out to a non-Google service
are all Blaze-only, and the OpenAI call in the classifier is all three at
once. `firebase functions:secrets:set` fails on Spark with a link to the
upgrade page. Take the link.

Blaze keeps the same free monthly allowances Spark has and bills only past
them, so one branch's volume lands in the low cents. Set a budget alert
while you are in there: **Usage and billing, Details and settings, Budget
alerts**. It emails you, it does not cap anything, which is the point worth
knowing before you rely on it.

Everything up to here works on Spark. If you want the board running before
you deal with billing, skip to step 6 and deploy only what does not need
functions:

```bash
firebase deploy --only firestore:rules,firestore:indexes,hosting
```

That gives you sign-in, the day board, and job orders, with tasks typed in
by hand. Email intake arrives when the functions do. Daily boards do not need
a scheduled snapshot: each task carries an `America/Chicago` `boardDate`, and the
active date advances automatically at midnight Central, carrying unfinished
tasks forward. Both manual and reply-completed tasks appear in Cleared on their
completion date; the original task date remains unchanged.

Two secrets, neither of which ever reaches the browser.

```bash
firebase functions:secrets:set OPENAI_API_KEY
firebase functions:secrets:set BOARD_INGEST_KEY
```

`OPENAI_API_KEY` is a key from your OpenAI account with access to
[`gpt-5.6-luna`](https://developers.openai.com/api/docs/models/gpt-5.6-luna).
Branch intake, thread updates, reply-completion checks, and personal intake use
this model through Chat Completions with JSON output and `reasoning_effort: none`.
Cost depends on email volume, message length, and output tokens.

`BOARD_INGEST_KEY` is any long random string you make up. It is the shared
secret between Power Automate and the two HTTP endpoints. Generate one:

```bash
openssl rand -hex 32
```

Save that value somewhere you can get it back. Step 8 needs it, and
Firebase will not show it to you again.

## 6. Deploy

The functions are second generation and target Node.js 24, which is GA for
[Cloud Run functions](https://docs.cloud.google.com/functions/docs/runtime-support).
Use a current Firebase CLI; this repo was verified with Firebase CLI 15.24.0.

```bash
cd functions && npm install && cd ..
npm install
npm run build
firebase deploy --only firestore:rules,firestore:indexes,functions,hosting
```

First deploy takes a few minutes and will ask to enable some APIs. Say yes.

Two things to read in the output:

- The **hosting URL**, something like `<project>.web.app`. That is the board.
  To serve it from your own address instead, see **Your own domain** below.
- The **function URL** for `ingestEmail`. Step 8 needs it. You can get it back
  later with `firebase functions:list`. `handleReply` is intentionally not part
  of the inbound pilot flow.

If the rules fail to compile, nothing else deploys. Fix and rerun.

## 7. Seed the first admin

Sign-up is off, so every account starts in the console.

**Authentication, Users, Add user.** Use your work address in lowercase and
any starter password. Copy the **User UID** from the row it creates.

You can sign in with that pair right now, and the board will show you
nothing useful, because the rules cannot find a user document for that UID
yet. That is expected, and it is what the seed fixes.

Then, from the repo:

```bash
gcloud auth application-default login
node scripts/seed.mjs --uid <your-uid> --email you@company.com \
  --name "Your Name" --initials YN \
  --b1-mailbox plx-edwardsvilleil@prologistix.com \
  --b2-mailbox plx-bolingbrook@prologistix.com
```

Edit the `BRANCHES` list at the top of `scripts/seed.mjs` first if your
branch names or codes differ from the placeholders. The branch IDs land in
every task and order document, so pick them once.

Pass one `--<branch-id>-mailbox` flag for every branch whose ingest flow will
be enabled, using its exact shared-mailbox SMTP address. For the current
Bolingbrook flow that is `--b2-mailbox`. The endpoint fails closed when a
branch has no configured mailbox, or when the request names a different one;
this prevents a copied flow from quietly writing into the wrong branch.

No `gcloud`? Use a service account key instead: **Project settings, Service
accounts, Generate new private key**, then
`export GOOGLE_APPLICATION_CREDENTIALS=/path/to/that.json` before running
the script. Delete the key file when you are done with it.

Reload the board and sign in with that address and password. You should see
an empty day board and the Setup tab. Replace the starter password using the
**Forgot your password** link on the sign-in screen.

Everyone else is added on the board under **Setup, People and markers, Add a
person** — by an admin for any branch, or by a manager for the branches they
belong to. A manager can add members and managers, grant or remove their own
branches on someone already on the roster, and change a member to manager and
back. Only an admin can create an admin, change anyone's admin role, or touch
branches the manager does not belong to. Enter their name, work email, initials, role, and branches.
The `createBoardUser` function creates their sign-in and their `users`
document under the same UID, and the board sends them Firebase's password
email so they can choose their own password. There is no console step and no
UID to copy. The wording of that email lives in **Authentication, Templates,
Password reset**.

If someone already has a sign-in from the console but no roster entry, adding
them by the same email reuses that sign-in and leaves their password alone.

An admin can also **Remove** someone from that row. Removing deletes their
sign-in and their roster record, and it cannot be undone. Their work stays on
the board: completed tasks and reply evidence are untouched, and anything still
assigned to them shows a former-owner badge until an admin reassigns it. An
admin cannot remove their own account, which is what keeps at least one admin
in place, and managers cannot remove anyone.

Client routing is maintained under **Setup, Accounts and routing**. Add the
parent customer first, then add its locations/departments and exact contact
emails. A contact who covers the full operation belongs to the parent account;
a location-specific contact should be scoped to that sub-account. Use **Test
sender routing** before enabling ingest. Ambiguous matches intentionally remain
unassigned until a manager resolves them from the task drawer.

Each branch also has two reserved accounts, **Payroll** (`payroll-<branchId>`)
and **Internal** (`internal-<branchId>`). They are never matched from email text.
EmployBridge timecards mailboxes route to Payroll unless the email resolves to
exactly one client account; EmployBridge system inboxes without a person's name
(`crt@`, `backgroundchecks@`, `talentsupportteam@`) route to Internal. Reserved
accounts never create job orders. When routing finds no account, or a timecards
email clearly names a client, the classifier suggests an account from the branch
list. The task shows **Suggested account** with a Review flag, no owner, and no
job order until a manager confirms it under **Account routing**.

That same directory drives job orders. A new order email creates openings only
when it contains one exact headcount and resolves to one active account and, when
needed, one location/department. The order inherits only a valid configured
owner; an account with no owner stays unowned. All generated candidate lines are
blank until a team member fills them.

The browser still never creates a sign-in itself. It holds a public API key,
so anything client-side that could create an Auth account could be driven by
anyone who read the bundle. **Add a person** instead calls the
`createBoardUser` function, which reads the caller's roster entry on the
server and refuses anyone who is not an active admin. Only the first admin,
above, is made in the console.

## 8. Power Automate — **you**

Start with exactly one supervised inbound flow for one mailbox/branch pair,
with `branchId` hard coded. [POWER-AUTOMATE.md](POWER-AUTOMATE.md) is the
click-by-click build. What this step needs from the steps above:

| Value | Where it came from |
| --- | --- |
| `ingestEmail` URL | step 6 deploy output |
| `x-board-key` header value | the `BOARD_INGEST_KEY` you generated in step 5 |
| `branchId` | the branch ID you seeded in step 7 |
| `mailboxAddress` | the exact SMTP address configured for that branch in step 7 |

Store the key in an environment variable or Key Vault in the flow, not
inline. Send the trigger's stable `internetMessageId` as `messageId`, falling
back to its `id` only if needed. The function uses that value to replay the
original result for exact retries rather than classifying or writing twice. It
returns HTTP 409 if that ID is later reused with different message content,
which exposes a broken mapping instead of silently replaying the wrong result.

Do not enable a second copy against the same mailbox. Both flows would receive
every message, even if their hard-coded branch IDs differ. A second branch gets
its own flow only when it has its own mailbox; a shared mailbox needs one
explicit routing flow.

The inbound flow does not call `handleReply`. Automatic reply completion needs
a separate outbound capture path with a stable reply ID, original thread ID,
and verified employee identity. Follow the [reply setup and supervised checks](POWER-AUTOMATE.md#reply-completion-setup-and-verification)
before enabling it. People can complete carried tasks on the board meanwhile.

Test it by sending one real-looking email to the shared mailbox and
watching the day board. Retry that same flow run once and confirm it returns the
same result without adding a second task. If nothing lands, check the function
logs:

```bash
firebase functions:log --only ingestEmail
```

A 401 means the header does not match the secret. A 400 means the flow is
missing a required field such as `branchId`, `mailboxAddress`, `messageId`, or
`conversationId`; it also reports a mailbox/branch mismatch before any task is
written.

---

## Your own domain

Production is `https://suite.ebtools.pro`. Firebase Hosting currently owns this
custom domain and provisions its certificate. The default
`https://branchsuite.web.app` address remains a useful fallback.

### Keep one host in charge

GitHub Pages must stay disabled for this domain. The repo intentionally has no
tracked `CNAME` file: that file is a GitHub Pages mechanism and Firebase Hosting
does not use it. Do not recreate it.

### Add the domain in Firebase

If the domain is ever disconnected, use **Hosting, Add custom domain** and enter
`suite.ebtools.pro`. Firebase gives you the ownership and serving records to
add. Use the exact values shown in the console; any DNS value copied into this
guide can go stale.

### At the registrar

DNS for `ebtools.pro` is at Spaceship, so any requested records get edited
there rather than at GitHub. Remove records that point `suite` at another host,
then add only the values from Firebase's domain wizard.

### Wait

SSL provisioning usually takes a few hours and can take a day. The console
shows the domain as pending until the certificate is issued. A browser error
about the certificate during that window is expected and not something to fix.

### One thing to go back for

Keep `suite.ebtools.pro` under **Authentication, Settings, Authorized domains**
from step 4. Email and password sign-in works without it, but password reset
links and anything OAuth you add later do not.

---

## What breaks first, and why

**Every read is denied right after sign-in.** No user document, or the
document ID is not exactly the Auth UID. This is what step 7 exists to
prevent. Check that the document ID in `users` matches the UID in
Authentication character for character.

**A new person cannot sign in, and gets no way to register.** That is step
4 working. Nobody creates their own login, because the browser config is
public. An admin adds them from **Setup, People and markers**, and they choose
a password from the setup email. No email? Check spam, or have them use
**Forgot your password** on the sign-in screen.

**Add a person says it could not be added.** Confirm the functions are
deployed, then check `firebase functions:log --only createBoardUser`. A
permission error there means the functions' runtime service account lacks the
**Firebase Authentication Admin** role; the default compute service account has
it through Editor.

**Incoming email creates duplicate tasks.** Confirm the flow sends a stable
`messageId` and that only one enabled flow watches that mailbox. An exact retry
replays its first result. New messages on a conversation update its existing
open task, including prior-day tasks; they should return `updated: true`. Missing stable IDs are rejected rather than accepted with a
weaker fingerprint.

**Client follow-ups do not update the task.** Every new message must reach
`ingestEmail` with a distinct stable message ID and the same conversation ID.
Expect `created: false`, `updated: true`, a new reply in the task drawer, and
priority escalation when the client adds a deadline or reports it was missed.
Old `thread already on the board` runs can be resubmitted unchanged to recover
previously skipped messages; see [the recovery steps](POWER-AUTOMATE.md#recover-follow-ups-skipped-by-an-older-deployment).

**Timecards email returns `timecards email not addressed to this branch`.** Mail
from an EmployBridge `timecards.*` / `timcards.*` sender is skipped unless one of
the branch's `mailboxAddresses`, or an active board user in that branch, is on
its To line; a Cc copy is not branch work.
If the branch receives mail through an alias, add that alias to
`branches/{branchId}.mailboxAddresses`. Flows that do not send `to` skip this
check and classify timecards mail normally.

**A branch's mail is skipped with `no configured branch for these
recipients`.** The shared intake flow resolves the branch from the message's To
line, then its Cc line, against `branches/{branchId}.mailboxAddresses`. Either
that branch is not set up yet, its address is bound with a different spelling,
or the copy reached the intake mailbox without its original recipients. Bind the
exact address, lowercased, to the branch document. One branch can hold several
addresses when a branch number has more than one brand mailbox.

**Ingest returns HTTP 400 for every message.** Confirm `branchId`,
`mailboxAddress`, `messageId`, and `conversationId` are all present. The literal
mailbox address must exactly match an entry in
`branches/{branchId}.mailboxAddresses` after lowercasing.

**Ingest returns HTTP 409 with `messageId was already used for different
message content`.** The flow reused a stable ID but changed the conversation,
sender, subject, body, or received time. Do not generate a new ID to bypass the
check. Correct the trigger mapping so exact retries send the same payload.

**Replies never close anything.** A team reply can close a task two ways: it
reaches the shared inbox through `ingestEmail` from an active board user in that
branch (the sender must match their roster email), or an outbound flow sends it
to `handleReply`. Replies from people not on the roster only add context. The
`ingestEmail` response for a team reply includes `closed` and `closeReason`;
`handleReply` responses give sender membership, thread matching, ambiguity, and
classification reasons. Successful completions appear under Cleared with reply evidence in
the drawer. See the [reply verification cases](POWER-AUTOMATE.md#reply-completion-setup-and-verification).

**Job orders read as empty for someone who can see the day board.** Their
user document has the branch in `branchIds`, but the orders were written
with a different branch ID. Both boards filter on the same field, so
compare the `branchId` on an order document against the user's
`branchIds`.

**The domain shows a blank page, certificate warning, or old version.** Check
`suite.ebtools.pro` in the Firebase Hosting domain view. Its ownership, host,
and certificate status should all be active. Then confirm Spaceship DNS still
matches the records Firebase requests and GitHub Pages remains disabled.

**Nothing deploys after a rules edit.** Rules compile as a unit. A syntax
error in one block fails the whole deploy, including functions and
hosting.
