'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  THREAD_BODY_MAX_LENGTH,
  buildThreadMessage,
  planThreadTaskUpdate,
  selectInboundTask,
  threadMessageId,
  threadTaskFingerprint,
  threadUpdateContext,
  validateThreadUpdate,
} = require('../lib/thread-updates');

const at = (time, day = '2026-09-14') => Date.parse(`${day}T${time}:00-05:00`);
const input = (overrides = {}) => ({
  branchId: 'b1', conversationId: 'thread-1', messageId: 'message-cutoff',
  from: 'client@example.com', subject: 'Coverage',
  body: 'Please confirm coverage by our 10am cutoff.',
  createdAt: at('09:40'), dayKey: '2026-09-14', ...overrides,
});
const task = (overrides = {}) => ({
  branchId: 'b1', boardDate: '2026-09-14', status: 'open', priority: 'normal',
  title: 'Confirm coverage', detail: 'Confirm four associates and a lead.',
  createdAt: at('09:20'), updatedAt: at('09:20'),
  ownerId: 'team-member', jobOrderId: 'existing-order',
  sourceEmail: {
    conversationId: 'thread-1', messageId: 'message-request',
    from: 'client@example.com', subject: 'Coverage', receivedAt: at('09:20'),
  },
  ...overrides,
});
const verdict = (overrides = {}) => ({
  detail: 'Confirm four associates and a lead before the client’s 10am cutoff.',
  summary: 'Client added a 10am cutoff.', priority: 'high',
  priorityReason: 'Client needs confirmation before 10am.',
  deadlineText: '10am today', deadlineMissed: false,
  ...overrides,
});
const candidate = (id = 'task-1', overrides = {}) => ({ id, data: task(overrides) });

test('client cutoff then missed-deadline replies update the original 9:20 task', () => {
  const original = task();
  const withCutoff = {
    ...original,
    ...planThreadTaskUpdate(original, input(), 'inbound', verdict(), at('09:41')),
  };
  assert.equal(withCutoff.priority, 'high');
  assert.match(withCutoff.detail, /10am cutoff/);
  assert.equal(withCutoff.latestThreadUpdate.deadlineText, '10am today');
  assert.equal(withCutoff.latestThreadUpdate.deadlineMissed, false);
  assert.equal(withCutoff.threadUpdateCount, 1);

  const missed = input({
    messageId: 'message-missed', createdAt: at('10:47'),
    body: 'Our 10am cutoff has now been missed and nobody has responded.',
  });
  const withMissed = {
    ...withCutoff,
    ...planThreadTaskUpdate(withCutoff, missed, 'inbound', verdict({
      detail: 'Urgently respond: coverage remains unconfirmed and the client’s 10am cutoff was missed.',
      summary: 'Client reports the cutoff was missed without a response.',
      priority: 'normal', deadlineText: null, deadlineMissed: true,
    }), at('10:48')),
  };
  assert.equal(withMissed.priority, 'high');
  assert.match(withMissed.detail, /cutoff was missed/);
  assert.equal(withMissed.threadUpdateCount, 2);
  assert.equal(withMissed.lastThreadMessageAt, at('10:47'));
  assert.equal(withMissed.latestThreadUpdate.receivedAt, at('10:47'));
  assert.equal(withMissed.latestThreadUpdate.deadlineText, '10am today');
  assert.equal(withMissed.latestThreadUpdate.deadlineMissed, true);
  assert.match(withMissed.latestThreadUpdate.excerpt, /nobody has responded/);
  assert.equal(withMissed.status, 'open');
  assert.equal(withMissed.ownerId, original.ownerId);
  assert.equal(withMissed.jobOrderId, original.jobOrderId);
  assert.deepEqual(withMissed.sourceEmail, original.sourceEmail);
});

test('a missed deadline forces high priority even if the model says low', () => {
  const patch = planThreadTaskUpdate(task({ priority: 'low' }), input(), 'inbound', verdict({
    priority: 'low', deadlineMissed: true,
  }), at('10:48'));
  assert.equal(patch.priority, 'high');
});

test('older messages merge context while preserving the latest evidence and missed deadline', () => {
  const latest = task({
    priority: 'high', detail: 'Deadline missed.', updatedAt: at('10:48'),
    threadUpdateCount: 2, lastThreadMessageAt: at('10:47'),
    latestThreadUpdate: { receivedAt: at('10:47'), deadlineMissed: true },
  });
  const patch = planThreadTaskUpdate(latest, input(), 'inbound', verdict({ detail: 'The 10am deadline was missed.' }), at('11:00'));
  assert.equal(patch.threadUpdateCount, 3);
  assert.equal(patch.detail, 'The 10am deadline was missed.');
  assert.equal(patch.priority, 'high');
  assert.equal(patch.lastThreadMessageAt, at('10:47'));
  assert.equal(patch.latestThreadUpdate.receivedAt, at('10:47'));
  assert.equal(patch.latestThreadUpdate.deadlineMissed, true);
  const message = buildThreadMessage('task-1', input(), 'inbound', at('11:00'));
  assert.equal(message.receivedAt, at('09:40'));
  assert.match(message.bodyText, /10am cutoff/);
});

test('thread messages, model context, and latest update carry recipients', () => {
  const staffReply = input({ from: 'luz@example.com', to: ['client@example.com'], cc: ['board@example.com'] });
  const message = buildThreadMessage('task-1', staffReply, 'inbound', at('11:00'));
  assert.deepEqual(message.to, ['client@example.com']);
  assert.deepEqual(message.cc, ['board@example.com']);
  assert.equal(buildThreadMessage('task-1', input(), 'inbound', at('11:00')).to, null);

  const original = task({ sourceEmail: { ...task().sourceEmail, to: ['board@example.com'] } });
  const context = threadUpdateContext(original, null, [message],
    input({ messageId: 'later', createdAt: at('11:05'), to: ['board@example.com'] }), 'inbound');
  assert.deepEqual(context.task.requestedTo, ['board@example.com']);
  assert.deepEqual(context.recentMessages[0].to, ['client@example.com']);
  assert.deepEqual(context.message.to, ['board@example.com']);

  const patch = planThreadTaskUpdate(original, staffReply, 'inbound', verdict(), at('09:41'));
  assert.deepEqual(patch.latestThreadUpdate.to, ['client@example.com']);
  assert.deepEqual(patch.latestThreadUpdate.cc, ['board@example.com']);
});

test('updates never lower priority or erase an omitted deadline', () => {
  const existing = task({
    priority: 'high',
    latestThreadUpdate: { deadlineText: '10am today', deadlineMissed: true },
  });
  const patch = planThreadTaskUpdate(existing, input({ createdAt: at('11:00') }), 'outbound', verdict({
    priority: 'low', deadlineText: null, deadlineMissed: false,
  }), at('11:01'));
  assert.equal(patch.priority, 'high');
  assert.equal(patch.latestThreadUpdate.deadlineText, '10am today');
  assert.equal(patch.latestThreadUpdate.deadlineMissed, true);
  assert.equal(patch.latestThreadUpdate.direction, 'outbound');
});

test('an explicit replacement cutoff can replace a missed deadline without downgrading priority', () => {
  const existing = task({
    priority: 'high',
    latestThreadUpdate: { deadlineText: '10am today', deadlineMissed: true },
  });
  const patch = planThreadTaskUpdate(existing, input({ createdAt: at('11:00') }), 'inbound', verdict({
    priority: 'normal', deadlineText: 'Noon today', deadlineMissed: false,
  }), at('11:01'));
  assert.equal(patch.priority, 'high');
  assert.equal(patch.latestThreadUpdate.deadlineText, 'Noon today');
  assert.equal(patch.latestThreadUpdate.deadlineMissed, false);
});

test('server updates advance a browser revision even when its clock is ahead', () => {
  const patch = planThreadTaskUpdate(task({ updatedAt: at('12:00') }), input(), 'inbound', verdict(), at('10:00'));
  assert.equal(patch.updatedAt, at('12:00') + 1);
});

test('only the exact branch and conversation match an inbound task', () => {
  const selected = candidate();
  assert.deepEqual(selectInboundTask([
    candidate('other-branch', { branchId: 'b2' }),
    candidate('other-thread', { sourceEmail: { conversationId: 'Thread-1', receivedAt: at('09:20') } }),
    selected,
  ], input()), { kind: 'task', candidate: selected });
  assert.deepEqual(selectInboundTask([selected], input({ branchId: null })), { kind: 'none' });
});

test('one older open task is selected ahead of a completed task today', () => {
  const carried = candidate('carried', {
    boardDate: '2026-09-13', createdAt: at('09:20', '2026-09-13'),
    sourceEmail: { conversationId: 'thread-1', receivedAt: at('09:20', '2026-09-13') },
  });
  assert.deepEqual(selectInboundTask([candidate('today', { status: 'done' }), carried], input()), {
    kind: 'task', candidate: carried,
  });
});

test('multiple open tasks across dates remain ambiguous', () => {
  const result = selectInboundTask([
    candidate(),
    candidate('older', { boardDate: '2026-09-13', createdAt: at('09:20', '2026-09-13') }),
  ], input());
  assert.equal(result.kind, 'ambiguous');
  assert.match(result.reason, /multiple open tasks/);
});

test('messages cannot attach to tasks originating after their event time', () => {
  assert.deepEqual(selectInboundTask([candidate()], input({ createdAt: at('09:00') })), { kind: 'none' });
  assert.deepEqual(selectInboundTask([candidate('future', { boardDate: '2026-09-15' })], input()), { kind: 'none' });
  assert.deepEqual(selectInboundTask([candidate('unknown', {
    createdAt: null, sourceEmail: { conversationId: 'thread-1' },
  })], input()), { kind: 'none' });
});

test('same-day done and reply-closed tasks receive context without being reopened', () => {
  for (const status of ['done', 'reply_closed']) {
    const completed = candidate('task-1', { status, completedBy: 'user-1' });
    assert.deepEqual(selectInboundTask([completed], input()), { kind: 'task', candidate: completed });
    const patch = planThreadTaskUpdate(completed.data, input(), 'inbound', verdict(), at('09:41'));
    assert.equal(Object.hasOwn(patch, 'status'), false);
    assert.equal(Object.hasOwn(patch, 'completedBy'), false);
    assert.equal(Object.hasOwn(patch, 'closedByReply'), false);
    assert.equal({ ...completed.data, ...patch }.status, status);
  }
});

test('prior-day completed tasks permit fresh work but multiple completed tasks today are ambiguous', () => {
  assert.deepEqual(selectInboundTask([
    candidate('yesterday', { status: 'done', boardDate: '2026-09-13' }),
  ], input()), { kind: 'none' });
  assert.equal(selectInboundTask([
    candidate('one', { status: 'done' }), candidate('two', { status: 'reply_closed' }),
  ], input()).kind, 'ambiguous');
});

test('thread message identity is stable, scoped, case-sensitive, and independent of delivery timing/content', () => {
  const initial = threadMessageId('task-1', input(), 'inbound');
  assert.match(initial, /^thread_message_[a-f0-9]{64}$/);
  assert.equal(initial, threadMessageId('task-1', input({ body: 'Changed', createdAt: at('11:00') }), 'inbound'));
  const distinct = [
    threadMessageId('task-2', input(), 'inbound'),
    threadMessageId('task-1', input({ messageId: 'MESSAGE-CUTOFF' }), 'inbound'),
    threadMessageId('task-1', input({ branchId: 'b2' }), 'inbound'),
    threadMessageId('task-1', input({ conversationId: 'thread-2' }), 'inbound'),
    threadMessageId('task-1', input(), 'outbound'),
  ];
  for (const id of distinct) assert.notEqual(initial, id);
  assert.throws(() => threadMessageId('task-1', input({ messageId: '' }), 'inbound'), /messageId/);
  assert.throws(() => threadMessageId('task-1', input(), 'unknown'), /direction/);
});

test('stored messages retain sanitized full bodies, event times, and explicit truncation', () => {
  const html = buildThreadMessage('task-1', input({
    body: '<p>The deadline &amp; request still stand.</p><script>steal()</script>',
    webLink: 'https://outlook.office.com/mail/id/1',
  }), 'inbound', at('11:00'));
  assert.equal(html.bodyText, 'The deadline & request still stand.');
  assert.equal(html.receivedAt, at('09:40'));
  assert.equal(html.recordedAt, at('11:00'));
  assert.equal(html.isTruncated, false);
  assert.equal(html.webLink, 'https://outlook.office.com/mail/id/1');
  const large = buildThreadMessage('task-1', input({ body: 'x'.repeat(22000) }), 'inbound', at('11:00'));
  assert.equal(large.bodyText.length, THREAD_BODY_MAX_LENGTH);
  assert.equal(large.originalLength, 22000);
  assert.equal(large.isTruncated, true);
  assert.equal(Object.hasOwn(large, 'webLink'), false);
});

test('model context keeps the original request and orders replies by event time', () => {
  const cutoff = buildThreadMessage('task-1', input(), 'inbound', at('11:00'));
  const response = buildThreadMessage('task-1', input({
    messageId: 'response', from: 'team@example.com', createdAt: at('10:30'),
    body: 'We are still checking the lead.',
  }), 'outbound', at('10:31'));
  const missed = input({ messageId: 'missed', body: 'Deadline missed.', createdAt: at('10:47') });
  const context = threadUpdateContext(task(), {
    bodyText: 'Please confirm four associates AND one lead.', isTruncated: false,
  }, [response, cutoff], missed, 'inbound');
  assert.equal(context.timeZone, 'America/Chicago');
  assert.match(context.task.originalRequest, /AND one lead/);
  assert.equal(context.task.summary, task().detail);
  assert.equal(context.task.requestedAt, at('09:20'));
  assert.deepEqual(context.recentMessages.map((message) => message.receivedAt), [at('09:40'), at('10:30')]);
  assert.equal(context.recentMessages[1].direction, 'outbound');
  assert.equal(context.message.body, 'Deadline missed.');
  assert.equal(context.message.receivedAt, at('10:47'));
});

test('context makes full-message, original-request, excerpt, and history truncation explicit', () => {
  const messages = Array.from({ length: 15 }, (_, index) => ({
    messageId: `message-${index}`, direction: 'inbound', receivedAt: at('09:20') + index,
    bodyText: 'x'.repeat(3000),
  }));
  const context = threadUpdateContext(task(), {
    bodyText: 'Original', isTruncated: true,
  }, messages, input({ body: 'y'.repeat(21000) }), 'inbound');
  assert.equal(context.task.requestTruncated, true);
  assert.equal(context.message.truncated, true);
  assert.equal(context.message.body.length, THREAD_BODY_MAX_LENGTH);
  assert.equal(context.recentMessagesTruncated, true);
  assert.equal(context.recentMessages.length, 12);
  assert.equal(context.recentMessages[0].receivedAt, at('09:20') + 3);
  assert.equal(context.recentMessages[0].truncated, true);
  assert.equal(context.recentMessages[0].body.length, 2000);
});

test('context excludes other branches, other conversations, and the currently processed message', () => {
  const current = buildThreadMessage('task-1', input(), 'inbound', at('09:41'));
  const context = threadUpdateContext(task(), null, [
    current, { ...current, messageId: 'other', branchId: 'b2' },
    { ...current, messageId: 'other', conversationId: 'other' },
  ], input(), 'inbound');
  assert.deepEqual(context.recentMessages, []);
  assert.equal(context.task.originalRequestAvailable, false);
});

test('validator rejects workflow, ownership, and ID fields that a model cannot change', () => {
  for (const key of ['status', 'ownerId', 'taskId', 'accountId', 'jobOrderId', 'jobOrderRequest']) {
    assert.throws(() => validateThreadUpdate({ ...verdict(), [key]: 'malicious' }), /unsupported fields/);
  }
  assert.deepEqual(validateThreadUpdate(verdict()), verdict());
});

test('validator rejects malformed types, missing fields, and oversized output', () => {
  for (const value of [null, [], 'text']) assert.throws(() => validateThreadUpdate(value), /JSON object/);
  for (const field of ['detail', 'summary', 'priorityReason', 'deadlineText']) {
    assert.throws(() => validateThreadUpdate(verdict({ [field]: 17 })), /string/);
    assert.throws(() => validateThreadUpdate(verdict({ [field]: undefined })), /string/);
  }
  for (const [field, maximum] of [['detail', 2000], ['summary', 500], ['priorityReason', 300], ['deadlineText', 200]]) {
    assert.throws(() => validateThreadUpdate(verdict({ [field]: 'x'.repeat(maximum + 1) })), /too long/);
  }
  assert.throws(() => validateThreadUpdate(verdict({ priority: 'urgent' })), /priority/);
  assert.throws(() => validateThreadUpdate(verdict({ deadlineMissed: 'true' })), /boolean/);
  assert.throws(() => validateThreadUpdate(verdict({ detail: ' ' })), /nonempty/);
});

test('fingerprint detects workflow and context changes and is stable across history order', () => {
  const detail = { bodyText: 'Original request', isTruncated: false };
  const one = buildThreadMessage('task-1', input({ messageId: 'one', createdAt: at('09:25') }), 'inbound', at('09:26'));
  const two = buildThreadMessage('task-1', input({ messageId: 'two', createdAt: at('09:30') }), 'inbound', at('09:31'));
  const fingerprint = threadTaskFingerprint(task(), detail, [one, two], input(), 'inbound');
  assert.equal(fingerprint, threadTaskFingerprint(task(), detail, [two, one], input(), 'inbound'));
  for (const changed of [
    task({ status: 'done' }), task({ updatedAt: at('10:00') }),
    task({ detail: 'Changed request' }), task({ threadUpdateCount: 1 }),
  ]) assert.notEqual(fingerprint, threadTaskFingerprint(changed, detail, [one, two], input(), 'inbound'));
  assert.notEqual(fingerprint, threadTaskFingerprint(task(), { ...detail, bodyText: 'New request' }, [one, two], input(), 'inbound'));
  assert.notEqual(fingerprint, threadTaskFingerprint(task(), detail, [{ ...one, bodyText: 'New context' }, two], input(), 'inbound'));
});


test('a delayed critical cutoff can escalate normal work without replacing the latest message', () => {
  const latest = task({
    detail: 'Client is still awaiting confirmation.', threadUpdateCount: 1,
    lastThreadMessageAt: at('10:47'),
    latestThreadUpdate: { from: 'client@example.com', receivedAt: at('10:47'),
      excerpt: 'Any update?', summary: 'Client is still waiting.', direction: 'inbound',
      deadlineText: null, deadlineMissed: false, priorityReason: null },
  });
  const patch = planThreadTaskUpdate(latest, input(), 'inbound', verdict({
    detail: 'Client is still waiting; the earlier message set a 10am cutoff.',
  }), at('11:00'));
  assert.equal(patch.priority, 'high');
  assert.equal(patch.latestThreadUpdate.deadlineText, '10am today');
  assert.equal(patch.latestThreadUpdate.excerpt, 'Any update?');
  assert.equal(patch.latestThreadUpdate.receivedAt, at('10:47'));
  assert.equal(patch.lastThreadMessageAt, at('10:47'));
  assert.match(patch.detail, /earlier message set a 10am cutoff/);
});

test('a delayed superseded cutoff cannot replace a newer explicit deadline', () => {
  const latest = task({ lastThreadMessageAt: at('11:00'),
    latestThreadUpdate: { receivedAt: at('11:00'), deadlineText: 'Noon today',
      deadlineMissed: false, excerpt: 'We can extend this until noon.' } });
  const patch = planThreadTaskUpdate(latest, input(), 'inbound', verdict({
    deadlineText: '10am today', deadlineMissed: true,
    detail: 'Client extended the original 10am cutoff until noon.',
  }), at('11:10'));
  assert.equal(patch.latestThreadUpdate.deadlineText, 'Noon today');
  assert.equal(patch.latestThreadUpdate.deadlineMissed, false);
  assert.equal(patch.latestThreadUpdate.excerpt, 'We can extend this until noon.');
});
