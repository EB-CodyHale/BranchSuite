'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const emailCore = require('../lib/email-core');

const requestBody = {
  branchId: 'b1', conversationId: 'thread-1', messageId: 'reply-1',
  from: 'Person <person@example.com>', body: 'All four associates and the lead are confirmed.',
  receivedAt: '2026-09-10T16:00:00Z',
};
const originalTask = {
  branchId: 'b1', boardDate: '2026-09-09', status: 'open',
  title: 'Confirm coverage', detail: 'Four associates and one lead.',
  createdAt: Date.parse('2026-09-09T15:00:00Z'), updatedAt: 1,
  completedAt: null, completedBy: null, closedByReply: null,
  sourceEmail: {
    conversationId: 'thread-1', subject: 'Coverage', from: 'client@example.com',
    receivedAt: Date.parse('2026-09-09T15:00:00Z'),
  },
};

// Execute the actual HTTP handler with an in-memory Firestore boundary and a
// deterministic model response. No project credentials, network, or live writes.
function harness({ verdict = { resolved: true, reason: 'All requested coverage is confirmed.' }, onModel } = {}) {
  const records = new Map(Object.entries({
    'users/person': { email: 'person@example.com', name: 'Person', branchIds: ['b1'], active: true },
    'tasks/task-1': structuredClone(originalTask),
    'taskEmailDetails/task-1': {
      taskId: 'task-1', branchId: 'b1', bodyText: 'Please confirm four associates AND one lead.',
      isTruncated: false,
    },
  }));
  const modelCalls = [];
  const errors = [];
  const getField = (record, field) => field.split('.').reduce((value, key) => value?.[key], record);
  const document = (key) => {
    const ref = { path: key, id: key.split('/').at(-1), get: async () => snapshot(key) };
    return ref;
  };
  const snapshot = (key) => ({
    id: key.split('/').at(-1), ref: document(key), exists: records.has(key),
    data: () => structuredClone(records.get(key)),
  });
  const query = (collection, filters = [], maximum = Infinity, sorting = []) => ({
    where: (field, operator, value) => {
      assert.equal(operator, '==');
      return query(collection, [...filters, [field, value]], maximum, sorting);
    },
    limit: (count) => query(collection, filters, count, sorting),
    orderBy: (field, direction = 'asc') => query(collection, filters, maximum, [...sorting, [field, direction]]),
    doc: (id) => document(`${collection}/${id}`),
    get: async () => {
      let keys = [...records.keys()].filter((key) => key.split('/')[0] === collection)
        .filter((key) => filters.every(([field, value]) => getField(records.get(key), field) === value));
      for (const [field, direction] of [...sorting].reverse()) {
        keys = keys.filter((key) => getField(records.get(key), field) !== undefined);
        keys.sort((left, right) => {
          const a = getField(records.get(left), field), b = getField(records.get(right), field);
          return (a < b ? -1 : a > b ? 1 : 0) * (direction === 'desc' ? -1 : 1);
        });
      }
      const docs = keys.slice(0, maximum).map(snapshot);
      return { docs, size: docs.length, empty: !docs.length };
    },
  });
  const db = {
    collection: query,
    runTransaction: async (callback) => {
      const writes = [];
      const result = await callback({
        get: (reference) => reference.get(),
        create: (reference, data) => writes.push(() => {
          assert.equal(records.has(reference.path), false, 'receipts must not be overwritten');
          records.set(reference.path, structuredClone(data));
        }),
        update: (reference, data) => writes.push(() => {
          assert.equal(records.has(reference.path), true);
          records.set(reference.path, { ...records.get(reference.path), ...structuredClone(data) });
        }),
      });
      writes.forEach((write) => write());
      return result;
    },
  };
  class FakeOpenAI {
    constructor() {
      this.chat = { completions: { create: async (request) => {
        assert.equal(request.model, 'gpt-5.6-luna');
        assert.equal(request.reasoning_effort, 'none');
        assert.equal('temperature' in request, false);
        assert.equal(request.response_format.type, 'json_object');
        modelCalls.push(structuredClone(request));
        if (onModel) await onModel(records);
        return { choices: [{ message: { content: typeof verdict === 'string' ? verdict : JSON.stringify(verdict) } }] };
      } } };
    }
  }
  const exports = {};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '..', 'index.js'), 'utf8'), {
    exports, Buffer,
    console: { error: (...args) => errors.push(args) },
    require: (name) => {
      if (name === 'firebase-functions/v2/https') {
        return { onRequest: (_options, handler) => handler, onCall: (handler) => handler, HttpsError: Error };
      }
      if (name === 'firebase-functions/params') return { defineSecret: () => ({ value: () => 'test-secret' }) };
      if (name === 'firebase-admin') return { initializeApp() {}, firestore: () => db };
      if (name === 'openai') return FakeOpenAI;
      if (name === './lib/email-core') return emailCore;
      if (name === './lib/thread-updates') {
        const helpers = require('../lib/thread-updates');
        return {
          ...helpers,
          // Inline objects created by the VM have another realm's prototype.
          // In production the handler and helper share a realm; mirror that
          // boundary without weakening the real model's plain-object checks.
          planThreadTaskUpdate: (...args) => helpers.planThreadTaskUpdate(...structuredClone(args)),
        };
      }
      if (name.startsWith('./')) return require(path.join(__dirname, '..', name));
      return require(name);
    },
  }, { filename: 'functions/index.js' });

  return {
    records, modelCalls, errors,
    request: async (body = requestBody) => {
      const response = { statusCode: 200, body: null };
      const res = {
        status(code) { response.statusCode = code; return this; },
        json(body) { response.body = structuredClone(body); return this; },
        send(body) { response.body = body; return this; },
      };
      await exports.handleReply({ method: 'POST', get: () => 'test-secret', body }, res);
      return response;
    },
  };
}

test('resolving reply closes yesterday\'s task with visible audit and original request context', async () => {
  const app = harness();
  const result = await app.request();
  assert.equal(result.statusCode, 200, JSON.stringify(app.errors));
  assert.equal(result.body.closed, true);
  assert.equal(result.body.updated, true);
  assert.equal(result.body.awaitingConfirmation, false);
  const task = app.records.get('tasks/task-1');
  assert.equal(task.status, 'reply_closed');
  assert.equal(task.boardDate, '2026-09-09');
  assert.equal(task.completedAt, null);
  assert.equal(task.closedByReply.byUserId, 'person');
  assert.equal(task.closedByReply.messageId, 'reply-1');
  assert.equal(task.closedByReply.receivedAt, Date.parse(requestBody.receivedAt));
  assert.match(task.closedByReply.reason, /coverage/);
  const context = JSON.parse(app.modelCalls[0].messages[1].content);
  assert.match(context.task.originalRequest, /AND one lead/);
  assert.equal(context.task.summary, originalTask.detail);
  assert.equal(context.reply.body, requestBody.body);
  assert.equal([...app.records.keys()].filter((key) => key.startsWith('emailReplies/')).length, 1);
  const messages = [...app.records.entries()].filter(([key]) => key.startsWith('taskEmailMessages/'));
  assert.equal(messages.length, 1);
  assert.equal(messages[0][1].direction, 'outbound');
  assert.equal(messages[0][1].bodyText, requestBody.body);
});

test('negative model verdict leaves partial work open and retries replay without another model call', async () => {
  const app = harness({ verdict: { resolved: false, reason: 'The lead is still unconfirmed.' } });
  const body = { ...requestBody, body: 'Introduction. '.repeat(40) + 'The lead is still unconfirmed.' };
  const result = await app.request(body);
  assert.equal(result.body.closed, false);
  assert.equal(result.body.updated, true);
  assert.match(result.body.reason, /lead/);
  assert.equal(app.records.get('tasks/task-1').status, 'open');
  assert.match(JSON.parse(app.modelCalls[0].messages[1].content).reply.body, /lead is still unconfirmed/);
  assert.equal((await app.request(body)).body.replayed, true);
  assert.equal(app.modelCalls.length, 1);
  assert.equal(app.records.get('tasks/task-1').threadUpdateCount, 1);
  const messages = [...app.records.entries()].filter(([key]) => key.startsWith('taskEmailMessages/'));
  assert.equal(messages.length, 1);
  assert.equal(messages[0][1].bodyText, body.body);
});

test('nonresolving team replies add visible context without erasing client urgency or requested work', async () => {
  const app = harness({ verdict: { resolved: false, reason: 'The lead is still unconfirmed.' } });
  Object.assign(app.records.get('tasks/task-1'), {
    detail: 'The 10 am cutoff was missed. Confirm four associates and one lead urgently.',
    priority: 'high', threadUpdateCount: 2,
    lastThreadMessageAt: Date.parse('2026-09-10T15:47:00Z'),
    latestThreadUpdate: {
      from: 'client@example.com', receivedAt: Date.parse('2026-09-10T15:47:00Z'),
      direction: 'inbound', summary: 'Deadline missed.', deadlineText: '10 am today',
      deadlineMissed: true, priorityReason: 'Client deadline missed without a response.',
    },
  });
  const before = structuredClone(app.records.get('tasks/task-1'));
  const body = { ...requestBody, body: 'I have confirmed four associates, but I am still checking on a lead.' };
  const result = await app.request(body);
  assert.equal(result.statusCode, 200, JSON.stringify(result.body));
  assert.equal(result.body.closed, false);
  assert.equal(result.body.updated, true);
  const task = app.records.get('tasks/task-1');
  assert.equal(task.status, 'open');
  assert.equal(task.detail, before.detail);
  assert.equal(task.priority, 'high');
  assert.equal(task.latestThreadUpdate.deadlineText, '10 am today');
  assert.equal(task.latestThreadUpdate.deadlineMissed, true);
  assert.equal(task.latestThreadUpdate.direction, 'outbound');
  assert.match(task.latestThreadUpdate.summary, /lead/i);
  assert.equal(task.threadUpdateCount, 3);
  assert.ok(task.updatedAt > before.updatedAt);
  assert.deepEqual(task.sourceEmail, before.sourceEmail);
  const messages = [...app.records.entries()].filter(([key]) => key.startsWith('taskEmailMessages/'));
  assert.equal(messages.length, 1);
  assert.equal(messages[0][1].bodyText, body.body);
});

test('reply completion checks include later client requests from the stored thread', async () => {
  const app = harness({ verdict: { resolved: false, reason: 'The updated request needs two leads.' } });
  app.records.set('taskEmailMessages/client-followup', {
    taskId: 'task-1', branchId: 'b1', conversationId: requestBody.conversationId,
    messageId: 'client-followup', direction: 'inbound', from: 'client@example.com',
    receivedAt: Date.parse('2026-09-10T15:30:00Z'),
    bodyText: 'The request has changed: we now need two leads in addition to four associates.',
    isTruncated: false,
  });
  const result = await app.request();
  assert.equal(result.statusCode, 200, JSON.stringify(result.body));
  assert.equal(result.body.closed, false);
  assert.equal(result.body.updated, true);
  const context = app.modelCalls[0].messages.find((message) => message.role === 'user').content;
  assert.match(context, /now need two leads/);
  assert.match(context, /Please confirm four associates AND one lead/);
  assert.equal(app.records.get('tasks/task-1').status, 'open');
});

test('new client thread context during reply verification prevents a stale automatic completion', async () => {
  const app = harness({ onModel(records) {
    records.set('taskEmailMessages/client-followup', {
      taskId: 'task-1', branchId: 'b1', direction: 'inbound', messageId: 'client-followup',
      receivedAt: Date.parse('2026-09-10T15:30:00Z'),
      bodyText: 'Actually we now need two leads.', isTruncated: false,
    });
  } });
  const result = await app.request();
  assert.equal(result.statusCode, 503, JSON.stringify(result.body));
  assert.match(result.body.error, /retry/i);
  assert.equal(app.records.get('tasks/task-1').status, 'open');
  assert.equal([...app.records.keys()].filter((key) => key.startsWith('emailReplies/')).length, 0);
});

test('a reply without branchId stores context under the matched authorized branch', async () => {
  const app = harness({ verdict: { resolved: false, reason: 'The lead is still unconfirmed.' } });
  const result = await app.request({ ...requestBody, branchId: undefined });
  assert.equal(result.statusCode, 200, JSON.stringify(app.errors));
  assert.equal(result.body.closed, false);
  assert.equal(result.body.updated, true);
  const messages = [...app.records.entries()].filter(([key]) => key.startsWith('taskEmailMessages/'));
  assert.equal(messages.length, 1);
  assert.equal(messages[0][1].branchId, 'b1');
  assert.equal(messages[0][1].taskId, 'task-1');
  assert.equal(messages[0][1].subject, 'Coverage');
});

test('a delayed team reply adds history without closing a task with newer client context', async () => {
  const app = harness();
  Object.assign(app.records.get('tasks/task-1'), {
    priority: 'high', threadUpdateCount: 1,
    lastThreadMessageAt: Date.parse('2026-09-10T16:15:00Z'),
    latestThreadUpdate: {
      from: 'client@example.com', receivedAt: Date.parse('2026-09-10T16:15:00Z'),
      direction: 'inbound', summary: 'The request changed again.',
      deadlineText: null, deadlineMissed: false,
    },
  });
  const latest = structuredClone(app.records.get('tasks/task-1').latestThreadUpdate);
  const result = await app.request();
  assert.equal(result.statusCode, 200, JSON.stringify(app.errors));
  assert.equal(result.body.closed, false);
  assert.equal(result.body.updated, true);
  assert.match(result.body.reason, /newer thread/);
  assert.equal(app.modelCalls.length, 0);
  const task = app.records.get('tasks/task-1');
  assert.equal(task.status, 'open');
  assert.equal(task.priority, 'high');
  assert.deepEqual(task.latestThreadUpdate, latest);
  assert.equal(task.threadUpdateCount, 2);
});

test('incomplete recent thread context cannot automatically close work even with a positive model stub', async () => {
  for (const mode of ['long_message', 'stored_truncation', 'history_limit']) {
    const app = harness();
    const count = mode === 'history_limit' ? 13 : 1;
    for (let index = 0; index < count; index += 1) {
      app.records.set(`taskEmailMessages/client-followup-${index}`, {
        taskId: 'task-1', branchId: 'b1', conversationId: requestBody.conversationId,
        messageId: `client-followup-${index}`, direction: 'inbound', from: 'client@example.com',
        receivedAt: Date.parse('2026-09-10T15:30:00Z') + index,
        bodyText: mode === 'long_message'
          ? `${'Additional request details. '.repeat(100)}We also need two leads, not one.`
          : 'The client sent additional request details.',
        isTruncated: mode === 'stored_truncation',
      });
    }
    const result = await app.request();
    assert.equal(result.statusCode, 200, `${mode}: ${JSON.stringify(app.errors)}`);
    assert.equal(result.body.closed, false, mode);
    assert.equal(result.body.updated, true);
    assert.match(result.body.reason, /truncated|incomplete/i);
    assert.equal(app.modelCalls.length, 0, mode);
    assert.equal(app.records.get('tasks/task-1').status, 'open');
  }
});

test('exact reply retries cannot re-close a reopened task or close another task', async () => {
  const app = harness();
  await app.request();
  app.records.get('tasks/task-1').status = 'open';
  app.records.get('tasks/task-1').closedByReply = null;
  app.records.set('tasks/task-2', { ...structuredClone(originalTask), boardDate: '2026-09-10' });
  const result = await app.request();
  assert.equal(result.body.replayed, true);
  assert.equal(result.body.taskId, 'task-1');
  assert.equal(app.records.get('tasks/task-1').status, 'open');
  assert.equal(app.records.get('tasks/task-2').status, 'open');
  assert.equal(app.modelCalls.length, 1);
});

test('reusing a reply message ID with different content returns 409', async () => {
  const app = harness();
  await app.request();
  const result = await app.request({ ...requestBody, body: 'Actually still pending.' });
  assert.equal(result.statusCode, 409);
  assert.match(result.body.error, /different message content/);
  assert.equal(app.modelCalls.length, 1);
});

test('missing stable message ID is rejected before model calls or writes', async () => {
  const app = harness();
  const result = await app.request({ ...requestBody, messageId: undefined });
  assert.equal(result.statusCode, 400);
  assert.match(result.body.error, /messageId/);
  assert.equal(app.modelCalls.length, 0);
  assert.equal(app.records.get('tasks/task-1').status, 'open');
});

test('multiple open tasks across dates require manual choice', async () => {
  const app = harness();
  app.records.set('tasks/task-2', { ...structuredClone(originalTask), boardDate: '2026-09-10' });
  const result = await app.request();
  assert.equal(result.body.closed, false);
  assert.match(result.body.reason, /multiple open tasks/);
  assert.equal(app.modelCalls.length, 0);
});

test('a sent reply cannot close a task whose request arrived later', async () => {
  const app = harness();
  const task = app.records.get('tasks/task-1');
  task.boardDate = '2026-09-10';
  task.sourceEmail.receivedAt = Date.parse('2026-09-10T17:00:00Z');
  const result = await app.request();
  assert.equal(result.body.closed, false);
  assert.equal(app.modelCalls.length, 0);
});

test('unknown or unauthorized senders do not close tasks', async () => {
  for (const mutation of [
    (records) => records.delete('users/person'),
    (records) => { records.get('users/person').active = false; },
    (records) => { records.get('users/person').branchIds = ['b2']; },
  ]) {
    const app = harness();
    mutation(app.records);
    const result = await app.request();
    assert.equal(result.body.closed, false);
    assert.equal(app.modelCalls.length, 0);
    assert.equal(app.records.get('tasks/task-1').status, 'open');
  }
});

test('transaction rechecks human completion, membership, context and newly ambiguous threads', async () => {
  for (const mutation of [
    (records) => { records.get('tasks/task-1').status = 'done'; },
    (records) => { records.get('users/person').branchIds = []; },
    (records) => { records.get('tasks/task-1').detail = 'Now need two leads.'; },
    (records) => { records.get('taskEmailDetails/task-1').bodyText = 'Now need two leads.'; },
    (records) => records.set('tasks/task-2', structuredClone(originalTask)),
  ]) {
    const app = harness({ onModel: mutation });
    const result = await app.request();
    if (result.statusCode === 503) assert.match(result.body.error, /retry this message/);
    else assert.equal(result.body.closed, false);
    assert.notEqual(app.records.get('tasks/task-1').status, 'reply_closed');
    assert.equal([...app.records.keys()].filter((key) => key.startsWith('emailReplies/')).length, 0);
  }
});

test('a routine task update during verification returns 503 so the sent-mail flow retries', async () => {
  const app = harness({ onModel: (records) => { records.get('tasks/task-1').updatedAt += 1; } });
  const result = await app.request();
  assert.equal(result.statusCode, 503);
  assert.match(result.body.error, /retry this message/);
  assert.equal(app.records.get('tasks/task-1').status, 'open');
  assert.equal([...app.records.keys()].some((key) => key.startsWith('emailReplies/')), false);
});

test('reply closure revision is newer than a slightly fast browser clock', async () => {
  const app = harness();
  const browserRevision = Date.now() + 5 * 60 * 1000;
  app.records.get('tasks/task-1').updatedAt = browserRevision;
  const result = await app.request();
  assert.equal(result.body.closed, true);
  const task = app.records.get('tasks/task-1');
  assert.equal(task.updatedAt, browserRevision + 1);
  assert.ok(task.closedByReply.at < browserRevision);
});

test('malformed model response returns a retryable error and leaves the task open', async () => {
  const app = harness({ verdict: '{"resolved":"true"}' });
  const result = await app.request();
  assert.equal(result.statusCode, 502);
  assert.equal(app.records.get('tasks/task-1').status, 'open');
  assert.equal([...app.records.keys()].filter((key) => key.startsWith('emailReplies/')).length, 0);
});

test('truncated requests or replies stay open without asking the model to guess', async () => {
  for (const truncateRequest of [true, false]) {
    const app = harness();
    if (truncateRequest) app.records.get('taskEmailDetails/task-1').isTruncated = true;
    const result = await app.request({
      ...requestBody, body: truncateRequest ? requestBody.body : 'Done. '.repeat(1100),
    });
    assert.equal(result.body.closed, false);
    assert.match(result.body.reason, /truncated/);
    assert.equal(app.modelCalls.length, 0);
    assert.equal(app.records.get('tasks/task-1').status, 'open');
  }
});
