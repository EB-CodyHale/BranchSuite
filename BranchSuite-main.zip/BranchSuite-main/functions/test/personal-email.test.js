'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createPersonalEmailService, tokenOwner, keyHash } = require('../lib/personal-email');

const email = {
  mailboxAddress: 'owner@example.com', conversationId: 'conversation', messageId: 'message-1',
  from: 'client@example.com', to: 'owner@example.com', subject: 'Review the schedule',
  body: '<p>Please review the schedule today.</p>', receivedAt: '2026-09-18T14:00:00Z',
};
const actionable = { actionRequired: true, title: 'Review the schedule', detail: 'Review today.', priority: 'normal' };
function harness() {
  const records = new Map([
    ['users/owner', { email: 'owner@example.com', active: true, role: 'member', branchIds: ['branch-1'] }],
    ['users/other', { email: 'other@example.com', active: true, role: 'admin', branchIds: ['branch-1'] }],
  ]);
  const snapshot = (path) => ({ exists: records.has(path), data: () => structuredClone(records.get(path)) });
  const doc = (path) => ({ path, get: async () => snapshot(path) });
  let tail = Promise.resolve();
  const db = { doc, runTransaction(work) {
    const pending = tail.then(async () => {
      const writes = []; let startedWriting = false;
      const result = await work({
        get: async (ref) => { assert.equal(startedWriting, false, 'all reads precede writes'); return snapshot(ref.path); },
        set(ref, value, options) { startedWriting = true; writes.push(() => records.set(ref.path, options?.merge ? { ...records.get(ref.path), ...structuredClone(value) } : structuredClone(value))); },
        create(ref, value) { startedWriting = true; writes.push(() => { assert.equal(records.has(ref.path), false); records.set(ref.path, structuredClone(value)); }); },
        update(ref, value) { startedWriting = true; writes.push(() => { assert.equal(records.has(ref.path), true); records.set(ref.path, { ...records.get(ref.path), ...structuredClone(value) }); }); },
      });
      writes.forEach((write) => write()); return result;
    });
    tail = pending.catch(() => {}); return pending;
  } };
  const app = { records, calls: 0, verdict: actionable, onModel: null };
  app.service = createPersonalEmailService({ db, now: () => Date.parse('2026-09-20T16:00:00Z'), classify: async (input) => {
    app.calls++; if (app.onModel) await app.onModel(input); return app.verdict;
  } });
  return app;
}
const tasks = (app) => [...app.records].filter(([path]) => /^personalBoards\/[^/]+\/tasks\/[^/]+$/.test(path));

test('connection stores only a hash and uses the signed-in roster email', async () => {
  const app = harness(); const connection = await app.service.connect('owner');
  assert.equal(tokenOwner(connection.token), 'owner');
  assert.equal(connection.mailboxAddress, email.mailboxAddress);
  assert.equal(app.records.get('personalIngestCredentials/owner').tokenHash, keyHash(connection.token));
  assert.equal(JSON.stringify([...app.records]).includes(connection.token), false);
  assert.equal(app.records.get('personalBoards/owner').status, 'awaiting-email');
});
test('payload owner/branch cannot redirect personal mail into any shared collection', async () => {
  const app = harness(); const { token } = await app.service.connect('owner');
  const response = await app.service.ingest(token, { ...email, ownerUid: 'other', branchId: 'branch-1' });
  assert.equal(response.created, true); assert.equal(tasks(app).length, 1);
  const [path, task] = tasks(app)[0];
  assert.equal(path.startsWith('personalBoards/owner/'), true);
  assert.equal(task.ownerUid, 'owner'); assert.equal(task.assigneeId, 'owner');
  assert.equal(task.branchId, '__personal__'); assert.equal(task.jobOrderId, null);
  assert.equal([...app.records.keys()].some((key) => /^(tasks|orders|taskEmailDetails)\//.test(key)), false);
  assert.equal(app.records.get(`personalBoards/owner/details/${response.taskId}`).bodyText, 'Please review the schedule today.');
});
test('missing, tampered, wrong-mailbox and revoked credentials reject before classification', async () => {
  const app = harness(); const { token } = await app.service.connect('owner');
  for (const bad of [undefined, '', 'test-secret', `${token.slice(0, -1)}${token.endsWith('0') ? '1' : '0'}`]) {
    await assert.rejects(app.service.ingest(bad, email), (err) => err.status === 401);
  }
  await assert.rejects(app.service.ingest(token, { ...email, mailboxAddress: 'other@example.com' }), (err) => err.status === 400);
  await app.service.disconnect('owner');
  await assert.rejects(app.service.ingest(token, email), (err) => err.status === 401);
  assert.equal(app.calls, 0);
});
test('a replacement key revokes the old key and disabled/deleted users cannot ingest', async () => {
  const app = harness(); const first = await app.service.connect('owner'); const second = await app.service.connect('owner');
  await assert.rejects(app.service.ingest(first.token, email), (err) => err.status === 401);
  app.records.get('users/owner').active = false;
  await assert.rejects(app.service.ingest(second.token, email), (err) => err.status === 401);
  await assert.rejects(app.service.connect('owner'), (err) => err.status === 403);
  app.records.delete('users/owner');
  await assert.rejects(app.service.ingest(second.token, email), (err) => err.status === 401);
});
test('disconnect during classification prevents task and receipt writes', async () => {
  const app = harness(); const { token } = await app.service.connect('owner');
  app.onModel = () => app.service.disconnect('owner');
  await assert.rejects(app.service.ingest(token, email), (err) => err.status === 401);
  assert.equal(tasks(app).length, 0);
  assert.equal(app.records.get('personalBoards/owner').status, 'disconnected');
});
test('duplicate delivery is idempotent, concurrent retries create only one task, changed content conflicts', async () => {
  const app = harness(); const { token } = await app.service.connect('owner');
  const responses = await Promise.all([app.service.ingest(token, email), app.service.ingest(token, email)]);
  assert.deepEqual(responses[0], responses[1]); assert.equal(tasks(app).length, 1);
  const calls = app.calls;
  assert.deepEqual(await app.service.ingest(token, email), responses[0]); assert.equal(app.calls, calls);
  await assert.rejects(app.service.ingest(token, { ...email, body: 'Different' }), (err) => err.status === 409);
});
test('the same message and conversation remain isolated across mailbox owners', async () => {
  const app = harness(); const one = await app.service.connect('owner'); const two = await app.service.connect('other');
  const a = await app.service.ingest(one.token, email);
  const b = await app.service.ingest(two.token, { ...email, mailboxAddress: 'other@example.com' });
  assert.notEqual(a.taskId, b.taskId); assert.equal(tasks(app).length, 2);
});
test('non-actionable mail records receipt and delivery status without creating a task', async () => {
  const app = harness(); app.verdict = { actionRequired: false };
  const { token } = await app.service.connect('owner');
  assert.equal((await app.service.ingest(token, email)).created, false);
  assert.equal(tasks(app).length, 0); assert.equal(app.records.get('personalBoards/owner').status, 'receiving');
  await app.service.ingest(token, email); assert.equal(app.calls, 1);
});
test('followups carry open work across days, retain messages, and preserve human completion', async () => {
  const app = harness(); const { token } = await app.service.connect('owner');
  const first = await app.service.ingest(token, email);
  const next = await app.service.ingest(token, { ...email, messageId: 'message-2', receivedAt: '2026-09-19T14:00:00Z' });
  assert.equal(next.taskId, first.taskId); assert.equal(tasks(app).length, 1);
  const task = app.records.get(`personalBoards/owner/tasks/${first.taskId}`);
  assert.equal(task.boardDate, '2026-09-18'); assert.equal(task.threadUpdateCount, 1);
  task.status = 'done'; task.completedBy = 'owner'; task.completedAt = Date.parse('2026-09-19T15:00:00Z');
  // A fresh day can start a fresh task; an earlier replay cannot reopen a closed task.
  const fresh = await app.service.ingest(token, { ...email, messageId: 'message-3', receivedAt: '2026-09-20T14:00:00Z' });
  assert.notEqual(fresh.taskId, first.taskId); assert.equal(task.status, 'done');
  assert.equal(tasks(app).length, 2);
});
test('same-day followups never reopen a completed task or replace latest context with delayed mail', async () => {
  const app = harness(); const { token } = await app.service.connect('owner');
  const first = await app.service.ingest(token, email);
  await app.service.ingest(token, { ...email, messageId: 'new', receivedAt: '2026-09-18T16:00:00Z', body: 'Latest context' });
  let task = app.records.get(`personalBoards/owner/tasks/${first.taskId}`); task.status = 'done'; task.completedBy = 'owner';
  await app.service.ingest(token, { ...email, messageId: 'late', receivedAt: '2026-09-18T15:00:00Z', body: 'Older context' });
  task = app.records.get(`personalBoards/owner/tasks/${first.taskId}`);
  assert.equal(task.status, 'done'); assert.equal(task.latestThreadUpdate.excerpt, 'Latest context');
  assert.equal(task.threadUpdateCount, 2);
});
test('invalid model output creates no task and no receipt so delivery can retry', async () => {
  const app = harness(); const { token } = await app.service.connect('owner'); app.verdict = { actionRequired: 'yes' };
  await assert.rejects(app.service.ingest(token, email)); assert.equal(tasks(app).length, 0);
  app.verdict = actionable; assert.equal((await app.service.ingest(token, email)).created, true);
});

test('a delayed older-day email does not get attached to a newer request', async () => {
  const app = harness(); const { token } = await app.service.connect('owner');
  const response = await app.service.ingest(token, { ...email, receivedAt: '2026-09-20T14:00:00Z' });
  const late = await app.service.ingest(token, { ...email, messageId: 'delayed-earlier-request' });
  assert.equal(late.updated, false); assert.equal(late.created, false);
  assert.equal(tasks(app).length, 1);
  assert.equal(app.records.get(`personalBoards/owner/tasks/${response.taskId}`).threadUpdateCount, undefined);
});
