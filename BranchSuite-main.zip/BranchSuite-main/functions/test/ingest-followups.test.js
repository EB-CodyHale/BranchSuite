'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { ingestPayloadHash, ingestReceiptId, normalizeIngestInput } = require('../lib/email-core');

const originalEmail = {
  branchId: 'b1', mailboxAddress: 'branch@example.com', conversationId: 'client-thread',
  messageId: 'request-0920', from: 'Client <client@example.com>', subject: 'Coverage request',
  body: 'Please confirm four associates and one lead for tomorrow.',
  receivedAt: '2026-09-14T14:20:00Z',
};
const cutoffEmail = {
  ...originalEmail, messageId: 'cutoff-0945', receivedAt: '2026-09-14T14:45:00Z',
  body: 'Please respond by the 10 am cutoff today. We need an answer before then.',
};
const missedEmail = {
  ...originalEmail, messageId: 'missed-1047', receivedAt: '2026-09-14T15:47:00Z',
  body: 'The 10 am deadline has now been missed, and no one has responded. Please escalate.',
};
const createVerdict = {
  actionRequired: true, title: 'Confirm coverage',
  detail: 'Confirm four associates and one lead for tomorrow.', priority: 'normal',
  jobOrderRequest: null,
};
const cutoffVerdict = {
  detail: 'Confirm four associates and one lead before the client’s 10 am cutoff today.',
  summary: 'Client added a 10 am response cutoff.', priority: 'high',
  priorityReason: 'Client needs a response before the 10 am cutoff.',
  deadlineText: '10 am today', deadlineMissed: false,
};
const missedVerdict = {
  detail: 'The 10 am deadline was missed without a response. Escalate the coverage request.',
  summary: 'Client reports the 10 am deadline was missed without a response.', priority: 'high',
  priorityReason: 'The stated response deadline was missed.',
  deadlineText: '10 am today', deadlineMissed: true,
};
const originalTask = {
  branchId: 'b1', boardDate: '2026-09-14', status: 'open',
  title: createVerdict.title, detail: createVerdict.detail, priority: 'normal',
  assigneeId: 'owner-1', jobOrderId: 'existing-order', accountId: 'account-1',
  createdAt: Date.parse(originalEmail.receivedAt), updatedAt: 1,
  completedAt: null, completedBy: null, closedByReply: null,
  source: 'email', sourceEmail: {
    conversationId: originalEmail.conversationId, messageId: originalEmail.messageId,
    subject: originalEmail.subject, from: originalEmail.from,
    mailboxAddress: originalEmail.mailboxAddress, receivedAt: Date.parse(originalEmail.receivedAt),
  },
};

// Load the real HTTP functions behind an in-memory Firestore and model boundary.
// Transactions are serialized so simultaneous HTTP requests re-read each other's
// writes, as a retried Firestore transaction would. Tests never use credentials.
function harness({ seeded = true, verdicts = [cutoffVerdict], onModel } = {}) {
  const records = new Map([
    ['branches/b1', { mailboxAddresses: ['branch@example.com'] }],
  ]);
  if (seeded) {
    records.set('tasks/task-1', structuredClone(originalTask));
    records.set('taskEmailDetails/task-1', {
      taskId: 'task-1', branchId: 'b1', bodyText: originalEmail.body, isTruncated: false,
    });
    records.set('orders/existing-order', { branchId: 'b1', status: 'open', headcount: 4 });
  }
  const modelCalls = [];
  const errors = [];
  const getField = (record, field) => field.split('.').reduce((value, key) => value?.[key], record);
  const document = (key) => ({ path: key, id: key.split('/').at(-1), get: async () => snapshot(key) });
  const snapshot = (key) => {
    const value = structuredClone(records.get(key));
    return {
      id: key.split('/').at(-1), ref: document(key), exists: records.has(key),
      data: () => structuredClone(value),
    };
  };
  const query = (collection, filters = [], maximum = Infinity, sorting = []) => ({
    where: (field, operator, value) => query(collection, [...filters, [field, operator, value]], maximum, sorting),
    limit: (count) => query(collection, filters, count, sorting),
    orderBy: (field, direction = 'asc') => query(collection, filters, maximum, [...sorting, [field, direction]]),
    doc: (id) => document(`${collection}/${id}`),
    get: async () => {
      let keys = [...records.keys()].filter((key) => key.split('/')[0] === collection)
        .filter((key) => filters.every(([field, operator, value]) => {
          const actual = getField(records.get(key), field);
          if (operator === '==') return actual === value;
          if (operator === '<=') return actual <= value;
          if (operator === '>=') return actual >= value;
          if (operator === '<') return actual < value;
          if (operator === '>') return actual > value;
          if (operator === 'in') return value.includes(actual);
          if (operator === 'array-contains') return Array.isArray(actual) && actual.includes(value);
          assert.fail(`unsupported query operator ${operator}`);
        }));
      for (const [field, direction] of [...sorting].reverse()) {
        keys = keys.filter((key) => getField(records.get(key), field) !== undefined);
        keys.sort((left, right) => {
          const a = getField(records.get(left), field), b = getField(records.get(right), field);
          return (a < b ? -1 : a > b ? 1 : 0) * (direction === 'desc' ? -1 : 1);
        });
      }
      const docs = keys.slice(0, maximum).map(snapshot);
      return { docs, size: docs.length, empty: !docs.length };
    },
  });
  let transactionTail = Promise.resolve();
  const db = {
    collection: query,
    runTransaction: (callback) => {
      const transaction = transactionTail.then(async () => {
        const writes = [];
        const result = await callback({
          get: (reference) => reference.get(),
          create: (reference, data) => writes.push(() => {
            assert.equal(records.has(reference.path), false, 'receipts and messages must not be overwritten');
            records.set(reference.path, structuredClone(data));
          }),
          update: (reference, data) => writes.push(() => {
            assert.equal(records.has(reference.path), true);
            records.set(reference.path, { ...records.get(reference.path), ...structuredClone(data) });
          }),
        });
        writes.forEach((write) => write());
        return result;
      });
      transactionTail = transaction.catch(() => {});
      return transaction;
    },
  };
  class FakeOpenAI {
    constructor() {
      this.chat = { completions: { create: async (request) => {
        assert.equal(request.model, 'gpt-5.6-luna');
        assert.equal(request.reasoning_effort, 'none');
        assert.equal('temperature' in request, false);
        assert.equal(request.response_format.type, 'json_object');
        const index = modelCalls.length;
        modelCalls.push(structuredClone(request));
        if (onModel) await onModel(records, index, request);
        const verdict = verdicts[Math.min(index, verdicts.length - 1)];
        if (verdict instanceof Error) throw verdict;
        return { choices: [{ message: { content: typeof verdict === 'string' ? verdict : JSON.stringify(verdict) } }] };
      } } };
    }
  }
  const exports = {};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '..', 'index.js'), 'utf8'), {
    exports, Buffer,
    console: { error: (...args) => errors.push(args) },
    require: (name) => {
      if (name === 'firebase-functions/v2/https') {
        return { onRequest: (_options, handler) => handler, onCall: (handler) => handler, HttpsError: Error };
      }
      if (name === 'firebase-functions/params') return { defineSecret: () => ({ value: () => 'test-secret' }) };
      if (name === 'firebase-admin') return { initializeApp() {}, firestore: () => db };
      if (name === 'openai') return FakeOpenAI;
      if (name.startsWith('./')) return require(path.join(__dirname, '..', name));
      return require(name);
    },
  }, { filename: 'functions/index.js' });
  return {
    records, modelCalls, errors,
    request: async (body = cutoffEmail) => {
      const response = { statusCode: 200, body: null };
      const res = {
        status(code) { response.statusCode = code; return this; },
        json(body) { response.body = structuredClone(body); return this; },
        send(body) { response.body = body; return this; },
      };
      await exports.ingestEmail({ method: 'POST', get: () => 'test-secret', body }, res);
      return response;
    },
  };
}

function collectionRecords(app, collection) {
  return [...app.records.entries()].filter(([key]) => key.startsWith(`${collection}/`));
}

function assertUpdated(result, taskId = 'task-1') {
  assert.equal(result.statusCode, 200, JSON.stringify(result.body));
  assert.equal(result.body.created, false);
  assert.equal(result.body.updated, true);
  assert.equal(result.body.taskId, taskId);
}

test('9:20 request, 10 am cutoff, and 10:47 missed deadline remain one task with escalating context', async () => {
  const app = harness({ seeded: false, verdicts: [createVerdict, cutoffVerdict, missedVerdict] });
  const created = await app.request(originalEmail);
  assert.equal(created.statusCode, 200, JSON.stringify(created.body));
  assert.equal(created.body.created, true);
  const taskKey = `tasks/${created.body.taskId}`;
  Object.assign(app.records.get(taskKey), { assigneeId: 'owner-1', jobOrderId: 'existing-order' });
  const original = structuredClone(app.records.get(taskKey));

  assertUpdated(await app.request(cutoffEmail), created.body.taskId);
  const cutoff = app.records.get(taskKey);
  assert.equal(cutoff.priority, 'high');
  assert.match(cutoff.detail, /10 am/);
  assert.equal(cutoff.latestThreadUpdate.deadlineText, '10 am today');
  assert.equal(cutoff.latestThreadUpdate.deadlineMissed, false);

  assertUpdated(await app.request(missedEmail), created.body.taskId);
  const task = app.records.get(taskKey);
  assert.equal(task.status, 'open');
  assert.equal(task.priority, 'high');
  assert.match(task.detail, /missed/i);
  assert.equal(task.latestThreadUpdate.deadlineMissed, true);
  assert.equal(task.lastThreadMessageAt, Date.parse(missedEmail.receivedAt));
  assert.equal(task.threadUpdateCount, 2);
  assert.equal(task.assigneeId, 'owner-1');
  assert.equal(task.jobOrderId, 'existing-order');
  assert.deepEqual(task.sourceEmail, original.sourceEmail);
  assert.equal(task.boardDate, original.boardDate);
  assert.equal(task.createdAt, original.createdAt);
  assert.equal(collectionRecords(app, 'tasks').length, 1);
  assert.equal(collectionRecords(app, 'emailIngests').length, 3);
  const messages = collectionRecords(app, 'taskEmailMessages').map(([, message]) => message);
  assert.ok(messages.some((message) => message.messageId === cutoffEmail.messageId && message.bodyText === cutoffEmail.body));
  assert.ok(messages.some((message) => message.messageId === missedEmail.messageId && message.bodyText === missedEmail.body));
  const finalModelContext = app.modelCalls.at(-1).messages.find((message) => message.role === 'user').content;
  assert.match(finalModelContext, /10 am/);
  assert.match(finalModelContext, /four associates/i);
});

test('same-thread followup stores full body and retries count and write it only once', async () => {
  const app = harness();
  const body = { ...cutoffEmail, body: `${cutoffEmail.body}\n\n${'Additional client context. '.repeat(80).trimEnd()}\nFrom: Prior sender\nQuoted original request.` };
  const original = structuredClone(app.records.get('tasks/task-1'));
  const order = structuredClone(app.records.get('orders/existing-order'));
  assertUpdated(await app.request(body));
  const afterFirst = structuredClone([...app.records.entries()]);
  const firstMessageKeys = collectionRecords(app, 'taskEmailMessages').map(([key]) => key);
  assert.equal(firstMessageKeys.length, 1);
  const message = app.records.get(firstMessageKeys[0]);
  assert.equal(message.taskId, 'task-1');
  assert.equal(message.branchId, body.branchId);
  assert.equal(message.bodyText, body.body);
  assert.equal(message.direction, 'inbound');
  assert.equal(message.receivedAt, Date.parse(body.receivedAt));
  assert.equal(app.records.get('tasks/task-1').threadUpdateCount, 1);
  assertUpdated(await app.request(body));
  assert.deepEqual([...app.records.entries()], afterFirst);
  assert.equal(app.modelCalls.length, 1);
  const task = app.records.get('tasks/task-1');
  for (const field of ['sourceEmail', 'boardDate', 'createdAt', 'assigneeId', 'jobOrderId', 'accountId']) {
    assert.deepEqual(task[field], original[field], `${field} stays tied to the original task`);
  }
  assert.deepEqual(app.records.get('orders/existing-order'), order);
});

test('followup message identity rejects different payloads without changing saved context', async () => {
  const app = harness();
  await app.request();
  const before = structuredClone([...app.records.entries()]);
  const result = await app.request({ ...cutoffEmail, body: 'Different content with the same message ID.' });
  assert.equal(result.statusCode, 409);
  assert.match(result.body.error, /different message content/);
  assert.deepEqual([...app.records.entries()], before);
  assert.equal(app.modelCalls.length, 1);
});

test('replaying a pre-fix skipped followup upgrades its receipt and restores context exactly once', async () => {
  const app = harness();
  const input = normalizeIngestInput(cutoffEmail);
  const receiptKey = `emailIngests/${ingestReceiptId(input)}`;
  app.records.set(receiptKey, {
    branchId: input.branchId, payloadHash: ingestPayloadHash(input),
    response: { created: false, reason: 'thread already on the board', taskId: 'task-1' },
    recordedAt: 1,
  });
  assertUpdated(await app.request());
  assert.equal(app.records.get(receiptKey).response.updated, true);
  assert.equal(collectionRecords(app, 'emailIngests').length, 1);
  assert.equal(collectionRecords(app, 'taskEmailMessages').length, 1);
  assert.equal(app.records.get('tasks/task-1').threadUpdateCount, 1);
  const restored = structuredClone([...app.records.entries()]);
  assertUpdated(await app.request());
  assert.deepEqual([...app.records.entries()], restored);
  assert.equal(app.modelCalls.length, 1);
});

test('original-created and no-action receipts retain their original replay behavior', async () => {
  for (const response of [
    { created: true, taskId: 'task-1', assigned: true },
    { created: false, reason: 'no action required' },
  ]) {
    const app = harness();
    const input = normalizeIngestInput(cutoffEmail);
    app.records.set(`emailIngests/${ingestReceiptId(input)}`, {
      branchId: input.branchId, payloadHash: ingestPayloadHash(input), response, recordedAt: 1,
    });
    const before = structuredClone([...app.records.entries()]);
    const replay = await app.request();
    assert.equal(replay.statusCode, 200);
    assert.deepEqual(replay.body, response);
    assert.deepEqual([...app.records.entries()], before);
    assert.equal(app.modelCalls.length, 0);
  }
});

test('next-day followup updates the sole open task and preserves its original board date', async () => {
  const app = harness();
  const result = await app.request({ ...cutoffEmail, receivedAt: '2026-09-15T14:45:00Z' });
  assertUpdated(result);
  assert.equal(collectionRecords(app, 'tasks').length, 1);
  assert.equal(app.records.get('tasks/task-1').boardDate, '2026-09-14');
  assert.equal(app.records.get('tasks/task-1').assigneeId, 'owner-1');
});

test('multiple open tasks on a thread skip ambiguous updates without writes or model guesses', async () => {
  const app = harness();
  app.records.set('tasks/task-2', { ...structuredClone(originalTask), boardDate: '2026-09-13' });
  const before = structuredClone([...app.records.entries()]);
  const result = await app.request();
  assert.equal(result.statusCode, 200);
  assert.equal(result.body.created, false);
  assert.notEqual(result.body.updated, true);
  assert.match(result.body.reason, /multiple|ambiguous/i);
  assert.equal(app.modelCalls.length, 0);
  assert.deepEqual([...app.records.entries()], before);
});

test('same-day completed tasks receive followup context without losing their completion', async () => {
  for (const status of ['done', 'reply_closed']) {
    const app = harness();
    const completion = { completedAt: 10, completedBy: 'owner-1', closedByReply: { messageId: 'old-reply' } };
    Object.assign(app.records.get('tasks/task-1'), { status, ...completion });
    assertUpdated(await app.request());
    const task = app.records.get('tasks/task-1');
    assert.equal(task.status, status);
    for (const [field, value] of Object.entries(completion)) assert.deepEqual(task[field], value);
    assert.equal(task.threadUpdateCount, 1);
    assert.equal(collectionRecords(app, 'tasks').length, 1);
    assert.equal(collectionRecords(app, 'taskEmailMessages').length, 1);
  }
});

test('a delayed older message merges context without replacing newer missed-deadline evidence', async () => {
  const mergedVerdict = { ...cutoffVerdict, priority: 'low',
    detail: 'Confirm four associates and a lead; the 10 am cutoff was missed and the client is still waiting.' };
  const app = harness({ verdicts: [missedVerdict, mergedVerdict] });
  assertUpdated(await app.request(missedEmail));
  const latest = structuredClone(app.records.get('tasks/task-1'));
  assertUpdated(await app.request(cutoffEmail));
  const task = app.records.get('tasks/task-1');
  assert.equal(task.priority, 'high');
  assert.equal(task.detail, mergedVerdict.detail);
  const context = JSON.parse(app.modelCalls[1].messages[1].content);
  assert.equal(context.task.summary, missedVerdict.detail);
  assert.ok(context.message.receivedAt < context.task.latestThreadUpdate.receivedAt);
  assert.deepEqual(task.latestThreadUpdate, latest.latestThreadUpdate);
  assert.equal(task.lastThreadMessageAt, Date.parse(missedEmail.receivedAt));
  assert.equal(task.threadUpdateCount, 2);
  assert.equal(collectionRecords(app, 'taskEmailMessages').length, 2);
});

test('followup classification failures leave no receipt so delivery can safely retry', async () => {
  for (const failed of [new Error('model unavailable'), '{"priority":"critical"}', '{"detail":7}']) {
    const app = harness({ verdicts: [failed, cutoffVerdict] });
    const before = structuredClone([...app.records.entries()]);
    const result = await app.request();
    assert.equal(result.statusCode, 502, JSON.stringify(result.body));
    assert.deepEqual([...app.records.entries()], before);
    assertUpdated(await app.request());
    assert.equal(collectionRecords(app, 'emailIngests').length, 1);
    assert.equal(collectionRecords(app, 'taskEmailMessages').length, 1);
  }
});

test('malformed inbound followups are rejected before reading the model or changing a task', async () => {
  for (const invalid of [
    { ...cutoffEmail, messageId: undefined },
    { ...cutoffEmail, receivedAt: '2026-09-14T09:45:00' },
    { ...cutoffEmail, mailboxAddress: 'other@example.com' },
  ]) {
    const app = harness();
    const before = structuredClone([...app.records.entries()]);
    const result = await app.request(invalid);
    assert.equal(result.statusCode, 400);
    assert.equal(app.modelCalls.length, 0);
    assert.deepEqual([...app.records.entries()], before);
  }
});

test('a task appearing during initial classification requests retry instead of swallowing its followup', async () => {
  const app = harness({
    seeded: false, verdicts: [createVerdict, cutoffVerdict],
    onModel(records, index) {
      if (index !== 0) return;
      records.set('tasks/task-1', structuredClone(originalTask));
      records.set('taskEmailDetails/task-1', {
        taskId: 'task-1', branchId: 'b1', bodyText: originalEmail.body, isTruncated: false,
      });
    },
  });
  const result = await app.request();
  assert.equal(result.statusCode, 503, JSON.stringify(result.body));
  assert.match(result.body.error, /retry/i);
  assert.equal(collectionRecords(app, 'tasks').length, 1);
  assert.equal(collectionRecords(app, 'emailIngests').length, 0);
  assert.equal(collectionRecords(app, 'taskEmailMessages').length, 0);
  assertUpdated(await app.request());
  assert.equal(collectionRecords(app, 'tasks').length, 1);
  assert.equal(collectionRecords(app, 'taskEmailMessages').length, 1);
});

test('task or email context edited during followup classification requests retry without stale writes', async () => {
  for (const mutation of [
    (records) => { records.get('tasks/task-1').detail = 'The client now needs two leads.'; },
    (records) => { records.get('tasks/task-1').updatedAt += 1; },
    (records) => { records.get('taskEmailDetails/task-1').bodyText = 'Now request two leads.'; },
    (records) => { records.set('taskEmailMessages/new-context', {
      taskId: 'task-1', branchId: 'b1', receivedAt: Date.parse('2026-09-14T14:30:00Z'),
      bodyText: 'Actually request two leads.', direction: 'inbound', messageId: 'new-context',
    }); },
  ]) {
    const app = harness({ onModel: mutation });
    const result = await app.request();
    assert.equal(result.statusCode, 503, JSON.stringify(result.body));
    assert.match(result.body.error, /retry/i);
    assert.equal(collectionRecords(app, 'emailIngests').length, 0);
    assert.equal(app.records.get('tasks/task-1').threadUpdateCount, undefined);
    assert.equal(collectionRecords(app, 'taskEmailMessages').filter(([, message]) => message.messageId === cutoffEmail.messageId).length, 0);
  }
});

test('simultaneous followups cannot silently overwrite each other and retry preserves both messages', async () => {
  let release;
  const bothInModel = new Promise((resolve) => { release = resolve; });
  let entered = 0;
  const app = harness({
    verdicts: [cutoffVerdict, missedVerdict, missedVerdict],
    async onModel() {
      entered += 1;
      if (entered === 2) release();
      if (entered <= 2) await bothInModel;
    },
  });
  const results = await Promise.all([app.request(cutoffEmail), app.request(missedEmail)]);
  assert.deepEqual(results.map((result) => result.statusCode).sort(), [200, 503]);
  assert.equal(collectionRecords(app, 'emailIngests').length, 1);
  assert.equal(collectionRecords(app, 'taskEmailMessages').length, 1);
  const retryBody = results[0].statusCode === 503 ? cutoffEmail : missedEmail;
  assertUpdated(await app.request(retryBody));
  const task = app.records.get('tasks/task-1');
  assert.equal(task.threadUpdateCount, 2);
  assert.equal(task.lastThreadMessageAt, Date.parse(missedEmail.receivedAt));
  assert.equal(task.priority, 'high');
  assert.equal(task.latestThreadUpdate.deadlineMissed, true);
  assert.equal(collectionRecords(app, 'emailIngests').length, 2);
  assert.deepEqual(collectionRecords(app, 'taskEmailMessages').map(([, message]) => message.messageId).sort(), [cutoffEmail.messageId, missedEmail.messageId].sort());
});


test('late delivery of a previously unknown cutoff still escalates the active task', async () => {
  const reminder = { ...missedEmail, body: 'Any update on coverage?' };
  const reminderVerdict = { ...cutoffVerdict, priority: 'normal',
    detail: 'Client is awaiting coverage confirmation.', summary: 'Client asks for an update.',
    priorityReason: null, deadlineText: null, deadlineMissed: false };
  const mergedVerdict = { ...cutoffVerdict,
    detail: 'Client is awaiting coverage confirmation; an earlier email set a 10 am cutoff.' };
  const app = harness({ verdicts: [reminderVerdict, mergedVerdict] });
  assertUpdated(await app.request(reminder));
  assert.equal(app.records.get('tasks/task-1').priority, 'normal');
  assertUpdated(await app.request(cutoffEmail));
  const task = app.records.get('tasks/task-1');
  assert.equal(task.priority, 'high');
  assert.equal(task.detail, mergedVerdict.detail);
  assert.equal(task.latestThreadUpdate.excerpt, reminder.body);
  assert.equal(task.latestThreadUpdate.deadlineText, '10 am today');
  assert.equal(task.lastThreadMessageAt, Date.parse(reminder.receivedAt));
  assert.equal(task.threadUpdateCount, 2);
});


test('recovering a skipped message retains its originally recorded task even when another task is now open', async () => {
  const app = harness();
  app.records.get('tasks/task-1').status = 'done';
  app.records.set('tasks/other-open', { ...structuredClone(originalTask), boardDate: '2026-09-13' });
  const input = normalizeIngestInput(cutoffEmail);
  app.records.set(`emailIngests/${ingestReceiptId(input)}`, {
    payloadHash: ingestPayloadHash(input),
    response: { created: false, reason: 'thread already on the board', taskId: 'task-1' },
  });
  assertUpdated(await app.request());
  assert.equal(app.records.get('tasks/task-1').threadUpdateCount, 1);
  assert.equal(app.records.get('tasks/task-1').status, 'done');
  assert.equal(app.records.get('tasks/other-open').threadUpdateCount, undefined);
  assert.equal(collectionRecords(app, 'taskEmailMessages')[0][1].taskId, 'task-1');
});

const timecardsCopy = {
  ...originalEmail, conversationId: 'timecards-thread', messageId: 'timecards-1',
  from: 'Timecards <timecards.bolingbrookil@employbridge.com>',
  to: 'payroll@employbridge.com', cc: 'branch@example.com',
  body: 'Please approve the attached timecard exceptions.',
};

test('timecards copies are skipped before triage while mail addressed to the branch is classified', async () => {
  const app = harness({ seeded: false, verdicts: [createVerdict] });
  const skipped = await app.request(timecardsCopy);
  assert.equal(skipped.statusCode, 200, JSON.stringify(skipped.body));
  assert.deepEqual(skipped.body, {
    created: false, updated: false, reason: 'timecards email not addressed to this branch',
  });
  assert.equal(app.modelCalls.length, 0);
  assert.equal(app.records.size, 1, 'only the branch record exists');

  const addressed = await app.request({ ...timecardsCopy, messageId: 'timecards-2', to: 'Branch@example.com' });
  assert.equal(addressed.body.created, true, JSON.stringify(addressed.body));
  assert.equal(app.modelCalls.length, 1);

  const seeded = harness();
  const before = structuredClone([...seeded.records.entries()]);
  const onThread = await seeded.request({ ...cutoffEmail, from: timecardsCopy.from, to: '', cc: 'branch@example.com' });
  assert.equal(onThread.body.reason, 'timecards email not addressed to this branch');
  assert.deepEqual([...seeded.records.entries()], before, 'an open thread is not updated by a timecards copy');
  assert.equal(seeded.modelCalls.length, 0);
});

test('recipients are stored on tasks and replies, and teammate senders are flagged to the model', async () => {
  const app = harness({ seeded: false, verdicts: [
    createVerdict, cutoffVerdict, { resolved: false, reason: 'The reply asks the client a question.' },
  ] });
  app.records.set('users/luz', { email: 'luz@example.com', name: 'Luz', branchIds: ['b1'], active: true });
  const created = await app.request({ ...originalEmail, to: 'branch@example.com', cc: '' });
  assert.equal(created.body.created, true, JSON.stringify(created.body));
  const taskKey = `tasks/${created.body.taskId}`;
  assert.deepEqual(app.records.get(taskKey).sourceEmail.to, ['branch@example.com']);
  assert.deepEqual(app.records.get(taskKey).sourceEmail.cc, []);
  assert.deepEqual(app.records.get(`taskEmailDetails/${created.body.taskId}`).to, ['branch@example.com']);
  const firstPrompt = app.modelCalls[0].messages.find((message) => message.role === 'user').content;
  assert.match(firstPrompt, /^To: branch@example\.com$/m);
  assert.match(firstPrompt, /^Cc: \(none\)$/m);
  assert.match(firstPrompt, /^Sender is branch staff: no$/m);

  const staffReply = { ...cutoffEmail, from: 'Luz <luz@example.com>', to: 'client@example.com', cc: 'branch@example.com' };
  assertUpdated(await app.request(staffReply), created.body.taskId);
  const context = JSON.parse(app.modelCalls[1].messages[1].content);
  assert.equal(context.senderIsTeamMember, true);
  assert.deepEqual(context.message.to, ['client@example.com']);
  assert.deepEqual(app.records.get(taskKey).latestThreadUpdate.to, ['client@example.com']);
  const [[, message]] = collectionRecords(app, 'taskEmailMessages');
  assert.deepEqual(message.to, ['client@example.com']);
  assert.deepEqual(message.cc, ['branch@example.com']);
});

const approvalRequest = {
  ...originalEmail, conversationId: 'approval-thread', messageId: 'approval-request',
  from: 'timecards.bolingbrookil@employbridge.com', to: 'manager@example.com', cc: 'branch@example.com',
  subject: 'Pay only approval', body: 'Hello @Manager, please approve pay only for modified duty.',
  receivedAt: '2026-09-14T17:24:09Z',
};
const teammateApproval = {
  ...approvalRequest, messageId: 'approval-reply', from: 'Manager <Manager@example.com>',
  to: 'timecards.bolingbrookil@employbridge.com', cc: 'branch@example.com',
  body: 'Approved!', receivedAt: '2026-09-14T17:26:12Z',
};
const approvalTaskVerdict = {
  actionRequired: true, title: 'Approve pay only for modified duty',
  detail: 'Payroll needs pay-only approval.', priority: 'normal', jobOrderRequest: null,
};
const approvalUpdateVerdict = {
  detail: 'Pay only for modified duty was approved.', summary: 'Staff replied to payroll: approved.',
  priority: 'normal', priorityReason: null, deadlineText: null, deadlineMissed: false,
};

test('a teammate reply copied to the shared inbox completes the task and later thanks keep it complete', async () => {
  const app = harness({ seeded: false, verdicts: [
    approvalTaskVerdict, approvalUpdateVerdict,
    { resolved: true, reason: 'The manager approved the requested pay.' },
    { ...approvalUpdateVerdict, summary: 'Payroll thanked the manager for the approval.' },
  ] });
  app.records.set('users/manager', { email: 'manager@example.com', name: 'Manager', branchIds: ['b1'] });

  const created = await app.request(approvalRequest);
  assert.equal(created.body.created, true, 'a timecards request addressed to a branch teammate is branch work');
  const taskKey = `tasks/${created.body.taskId}`;

  const approval = await app.request(teammateApproval);
  assertUpdated(approval, created.body.taskId);
  assert.equal(approval.body.closed, true);
  const closedTask = structuredClone(app.records.get(taskKey));
  assert.equal(closedTask.status, 'reply_closed');
  assert.equal(closedTask.completedAt, null);
  assert.equal(closedTask.closedByReply.byUserId, 'manager');
  assert.equal(closedTask.closedByReply.messageId, teammateApproval.messageId);
  assert.equal(closedTask.closedByReply.receivedAt, Date.parse(teammateApproval.receivedAt));
  assert.match(closedTask.closedByReply.excerpt, /Approved!/);
  assert.match(app.modelCalls[2].messages[0].content, /resolves ALL requested work/);

  const replay = await app.request(teammateApproval);
  assert.deepEqual(replay.body, approval.body);
  assert.equal(app.modelCalls.length, 3, 'an exact retry does not re-run the completion check');

  const thanks = await app.request({
    ...approvalRequest, messageId: 'payroll-thanks', body: 'Thank you', receivedAt: '2026-09-14T17:33:01Z',
  });
  assertUpdated(thanks, created.body.taskId);
  assert.equal(thanks.body.closed, undefined, 'client messages are never completion checks');
  const task = app.records.get(taskKey);
  assert.equal(task.status, 'reply_closed');
  assert.deepEqual(task.closedByReply, closedTask.closedByReply);
  assert.equal(task.threadUpdateCount, 2);
});

test('approvals from outside the branch roster, or unresolved team replies, only add context', async () => {
  const app = harness({ seeded: false, verdicts: [
    approvalTaskVerdict, approvalUpdateVerdict, approvalUpdateVerdict,
    { resolved: false, reason: 'The reply only says the manager will check.' },
  ] });
  app.records.set('users/manager', { email: 'manager@example.com', name: 'Manager', branchIds: ['b1'] });
  app.records.set('users/other-branch', { email: 'vp@example.com', name: 'VP', branchIds: ['b2'] });
  const created = await app.request(approvalRequest);
  const taskKey = `tasks/${created.body.taskId}`;

  const outside = await app.request({ ...teammateApproval, messageId: 'vp-approval', from: 'vp@example.com', body: 'Approved' });
  assertUpdated(outside, created.body.taskId);
  assert.equal(outside.body.closed, undefined);
  assert.equal(app.modelCalls.length, 2, 'no completion check for a non-member');

  const unresolved = await app.request({
    ...teammateApproval, messageId: 'manager-checking', body: 'I will check and get back to you.',
    receivedAt: '2026-09-14T17:40:00Z',
  });
  assertUpdated(unresolved, created.body.taskId);
  assert.equal(unresolved.body.closed, false);
  assert.match(unresolved.body.closeReason, /will check/);
  assert.equal(app.records.get(taskKey).status, 'open');
  assert.equal(app.records.get(taskKey).closedByReply, null);
});

function seedRoutingAccounts(app) {
  app.records.set('accounts/payroll-b1', { branchId: 'b1', name: 'Payroll', active: true });
  app.records.set('accounts/internal-b1', { branchId: 'b1', name: 'Internal', active: true });
  app.records.set('accounts/diageo', {
    branchId: 'b1', name: 'ProUnlimited/Diageo/Plainfield, IL', active: true, ownerId: 'owner-1',
  });
  app.records.set('users/owner-1', { email: 'owner@example.com', name: 'Owner', branchIds: ['b1'] });
}
const newThread = (overrides) => ({ ...originalEmail, conversationId: `thread-${overrides.messageId}`, ...overrides });
const withSuggestion = (accountSuggestion = null) => ({ ...createVerdict, accountSuggestion });
const createdTask = (app, result) => {
  assert.equal(result.body.created, true, JSON.stringify(result.body));
  return app.records.get(`tasks/${result.body.taskId}`);
};
const systemPrompt = (app, index) => app.modelCalls[index].messages.find((message) => message.role === 'system').content;
const timecardsSender = { from: 'timecards.bolingbrookil@employbridge.com', to: 'branch@example.com' };

test('timecards mail routes to Payroll and system inboxes route to Internal without an owner', async () => {
  const app = harness({ seeded: false, verdicts: [
    withSuggestion(),
    withSuggestion({ accountId: 'diageo', confidence: 'high', reason: 'Names Diageo.' }),
  ] });
  seedRoutingAccounts(app);

  const payroll = createdTask(app, await app.request(newThread({
    ...timecardsSender, messageId: 'timecards-hours', body: 'Please approve the attached hours.',
  })));
  assert.equal(payroll.accountId, 'payroll-b1');
  assert.equal(payroll.accountName, 'Payroll');
  assert.equal(payroll.needsAccountReview, false);
  assert.equal(payroll.assigneeId, null);
  assert.equal(payroll.accountSuggestion, null);
  assert.match(systemPrompt(app, 0), /"accountDirectory":\[\{"id":"diageo"/, 'a Payroll fallback may still name a client');
  assert.doesNotMatch(systemPrompt(app, 0), /"accountDirectory":\[[^\]]*"(payroll|internal)-b1"/);

  const internal = createdTask(app, await app.request(newThread({
    messageId: 'crt-notice', from: 'crt@employbridge.com', to: 'branch@example.com',
    subject: 'Action Needed', body: 'Correct the SSN for the Diageo background order.',
  })));
  assert.equal(internal.accountId, 'internal-b1');
  assert.equal(internal.needsAccountReview, false);
  assert.equal(internal.accountSuggestion, null, 'Internal senders are never re-routed by a suggestion');
  assert.match(systemPrompt(app, 1), /"accountDirectory":null/);
});

test('a client named on timecards mail or an unrouted email becomes a suggestion a manager confirms', async () => {
  const app = harness({ seeded: false, verdicts: [
    withSuggestion({ accountId: 'diageo', accountUnitId: null, confidence: 'high', reason: 'Names Diageo missed punches.' }),
    withSuggestion({ accountId: 'diageo', confidence: 'medium', reason: 'Mentions the Plainfield site.' }),
    withSuggestion({ accountId: 'payroll-b1', confidence: 'high', reason: 'Not a client.' }),
    withSuggestion({ accountId: 'diageo', confidence: 'medium', reason: 'Weak match.' }),
  ] });
  seedRoutingAccounts(app);

  const punches = createdTask(app, await app.request(newThread({
    ...timecardsSender, messageId: 'diageo-punches', subject: 'Diageo Missed Punches',
    body: 'Please correct the Diageo missed punches.',
  })));
  assert.equal(punches.accountId, 'diageo');
  assert.equal(punches.needsAccountReview, true);
  assert.equal(punches.assigneeId, null, 'a suggestion never assigns the account owner');
  assert.equal(punches.jobOrderId, null);
  assert.deepEqual(punches.accountSuggestion, {
    source: 'ai', accountId: 'diageo', accountUnitId: null, confidence: 'high', reason: 'Names Diageo missed punches.',
  });

  const client = createdTask(app, await app.request(newThread({ messageId: 'client-site', from: 'ops@client.com' })));
  assert.equal(client.accountId, 'diageo');
  assert.equal(client.needsAccountReview, true);
  assert.equal(client.accountSuggestion.confidence, 'medium');

  const reserved = createdTask(app, await app.request(newThread({ messageId: 'client-reserved', from: 'ops@client.com' })));
  assert.equal(reserved.accountId, null, 'reserved accounts cannot be suggested');
  assert.equal(reserved.needsAccountReview, true);
  assert.equal(reserved.accountSuggestion, null);

  const weak = createdTask(app, await app.request(newThread({ ...timecardsSender, messageId: 'payroll-weak' })));
  assert.equal(weak.accountId, 'payroll-b1', 'only a high-confidence client replaces Payroll');
  assert.equal(weak.needsAccountReview, false);
  assert.equal(weak.accountSuggestion, null);
});

test('a shared intake mailbox resolves the branch from recipients and skips branches that are not set up', async () => {
  const app = harness({ seeded: false, verdicts: [createVerdict] });
  app.records.set('branches/b9', { name: 'Other', mailboxAddresses: ['Other-Branch@example.com'] });
  const shared = { ...originalEmail, branchId: undefined, mailboxAddress: undefined };

  const resolved = await app.request({ ...shared, messageId: 'shared-to', to: 'intake@example.com;Branch@Example.com' });
  assert.equal(resolved.body.created, true, JSON.stringify(resolved.body));
  const task = app.records.get(`tasks/${resolved.body.taskId}`);
  assert.equal(task.branchId, 'b1');
  assert.equal(task.sourceEmail.mailboxAddress, 'branch@example.com');

  const copied = await app.request({
    ...shared, messageId: 'shared-cc', conversationId: 'cc-thread',
    to: 'intake@example.com', cc: 'branch@example.com',
  });
  assert.equal(copied.body.created, true, 'a branch that was only copied resolves from Cc');

  const unknown = await app.request({ ...shared, messageId: 'shared-none', to: 'intake@example.com;plx-notsetup@prologistix.com' });
  assert.deepEqual(unknown.body, {
    created: false, updated: false, reason: 'no configured branch for these recipients',
  });

  const both = await app.request({ ...shared, messageId: 'shared-both', to: 'branch@example.com;other-branch@example.com' });
  assert.equal(both.body.reason, 'recipients match more than one configured branch');

  const noRecipients = await app.request({ ...shared, messageId: 'shared-empty' });
  assert.equal(noRecipients.body.reason, 'no configured branch for these recipients');

  // A single-mailbox flow still has to send its own mailboxAddress.
  const missingMailbox = await app.request({ ...originalEmail, messageId: 'no-mailbox', mailboxAddress: undefined });
  assert.equal(missingMailbox.statusCode, 400);
  assert.match(missingMailbox.body.error, /mailboxAddress is required/);

  assert.equal(app.modelCalls.length, 2, 'skipped mail never reaches the model');
  assert.equal(collectionRecords(app, 'tasks').length, 2);
  assert.equal(collectionRecords(app, 'emailIngests').length, 2, 'skips leave no receipt to replay');
});
