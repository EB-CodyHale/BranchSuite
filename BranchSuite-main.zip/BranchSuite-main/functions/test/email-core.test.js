'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  InputError,
  accountSuggestionDirectory,
  applyAccountSuggestion,
  buildEmailJobOrder,
  canAutoCreateJobOrder,
  centralDateKey,
  dailyJobOrderId,
  dailyThreadId,
  eligibleOwnerId,
  emailDetailBody,
  ingestPayloadHash,
  ingestReceiptId,
  internalSenderKind,
  isUndirectedTimecardsEmail,
  normalizeIngestInput,
  normalizeReplyInput,
  parseJsonObject,
  planEmailJobOrderWrite,
  replyPayloadHash,
  replyReceiptId,
  replyResolutionContext,
  replyTaskFingerprint,
  resolveAccountRoute,
  resolveBranchByRecipients,
  routeInboundEmail,
  selectReplyCandidate,
  taskDayKey,
  topOfThread,
  validateBranchMailbox,
  validateClassification,
  validateJobOrderRequest,
  validateReplyVerdict,
} = require('../lib/email-core');

test('centralDateKey changes at Chicago midnight in winter and summer', () => {
  assert.equal(centralDateKey('2026-01-01T05:59:59.999Z'), '2025-12-31');
  assert.equal(centralDateKey('2026-01-01T06:00:00.000Z'), '2026-01-01');
  assert.equal(centralDateKey('2026-07-01T04:59:59.999Z'), '2026-06-30');
  assert.equal(centralDateKey('2026-07-01T05:00:00.000Z'), '2026-07-01');
});

test('normalizes ingest input and derives its Central board day from receivedAt', () => {
  const input = normalizeIngestInput({
    branchId: ' b1 ',
    conversationId: ' conversation-1 ',
    messageId: ' message-1 ',
    from: ' Client@Example.com ',
    subject: ' Coverage ',
    body: 'Body',
    mailboxAddress: 'Bolingbrook Board <BOARD@Example.com>',
    webLink: 'https://outlook.office.com/mail/id/1',
    receivedAt: '2026-09-10T04:30:00.000Z',
  });

  assert.equal(input.branchId, 'b1');
  assert.equal(input.conversationId, 'conversation-1');
  assert.equal(input.messageId, 'message-1');
  assert.equal(input.mailboxAddress, 'board@example.com');
  assert.equal(input.dayKey, '2026-09-09');
  assert.equal(input.receivedAtProvided, true);
});

test('mailbox binding is enforced once a branch has configured addresses', () => {
  assert.throws(
    () => validateBranchMailbox({}, 'board@example.com'),
    /configuration is missing or invalid/
  );
  assert.throws(
    () => validateBranchMailbox({ mailboxAddresses: [] }, 'board@example.com'),
    /configuration is missing or invalid/
  );
  assert.equal(
    validateBranchMailbox(
      { mailboxAddresses: [' Board@Example.com '] },
      'Branch Board <board@example.com>'
    ).mailboxAddress,
    'board@example.com'
  );
  assert.throws(
    () => validateBranchMailbox({ mailboxAddresses: ['board@example.com'] }, null),
    /required/
  );
  assert.throws(
    () => validateBranchMailbox(
      { mailboxAddresses: ['board@example.com'] },
      'other@example.com'
    ),
    /not configured/
  );
  assert.throws(
    () => validateBranchMailbox({ mailboxAddresses: 'board@example.com' }, 'board@example.com'),
    /configuration is missing or invalid/
  );
});

test('rejects malformed inbound fields before model or database work', () => {
  const valid = {
    branchId: 'b1',
    conversationId: 'c1',
    messageId: 'm1',
    mailboxAddress: 'board@example.com',
  };
  assert.throws(
    () => normalizeIngestInput({ ...valid, branchId: 'b1/b2' }),
    InputError
  );
  assert.throws(
    () => normalizeIngestInput({ ...valid, webLink: 'javascript:alert(1)' }),
    /http or https/
  );
  assert.throws(
    () => normalizeIngestInput({ ...valid, receivedAt: 'not-a-date' }),
    /timezone|valid date/
  );
  assert.throws(
    () => normalizeIngestInput({ ...valid, receivedAt: '2026-09-10T08:00:00' }),
    /timezone/
  );
  assert.throws(
    () => normalizeIngestInput({ ...valid, conversationId: 123 }),
    /conversationId/
  );
  assert.throws(
    () => normalizeIngestInput({ ...valid, messageId: '' }),
    /messageId/
  );
  assert.throws(
    () => normalizeIngestInput({ ...valid, mailboxAddress: 'not-an-email' }),
    /mailboxAddress/
  );
  // A shared intake mailbox omits both; the caller resolves them from recipients.
  const unresolved = normalizeIngestInput({ ...valid, branchId: undefined, mailboxAddress: undefined });
  assert.equal(unresolved.branchId, null);
  assert.equal(unresolved.mailboxAddress, null);
});

test('stable message IDs make retry receipts independent of day and content', () => {
  const first = normalizeIngestInput({
    branchId: 'b1',
    conversationId: 'c1',
    messageId: 'immutable-message-id',
    mailboxAddress: 'board@example.com',
    body: 'first representation',
    receivedAt: '2026-09-09T10:00:00Z',
  });
  const retry = normalizeIngestInput({
    branchId: 'b1',
    conversationId: 'c1',
    messageId: 'immutable-message-id',
    mailboxAddress: 'board@example.com',
    body: 'different conversion',
    receivedAt: '2026-09-10T10:00:00Z',
  });
  const otherBranch = { ...retry, branchId: 'b2' };

  assert.equal(ingestReceiptId(first), ingestReceiptId(retry));
  assert.notEqual(ingestPayloadHash(first), ingestPayloadHash(retry));
  assert.notEqual(ingestReceiptId(first), ingestReceiptId(otherBranch));
});

test('payload fingerprints match exact stable-ID retries', () => {
  const payload = {
    branchId: 'b1',
    conversationId: 'c1',
    messageId: 'm1',
    mailboxAddress: 'board@example.com',
    from: 'client@example.com',
    subject: 'Coverage',
    body: 'Need four people',
    receivedAt: '2026-09-10T12:00:00Z',
  };
  const first = normalizeIngestInput(payload, Date.parse('2026-09-10T12:01:00Z'));
  const retry = normalizeIngestInput(payload, Date.parse('2026-09-11T12:01:00Z'));
  assert.equal(ingestPayloadHash(first), ingestPayloadHash(retry));
});

test('mailbox binding participates in stable receipt and payload identity', () => {
  const payload = {
    branchId: 'b1',
    conversationId: 'c1',
    messageId: 'm1',
    mailboxAddress: 'first@example.com',
    from: 'client@example.com',
    subject: 'Coverage',
    body: 'Need four people',
  };
  const first = normalizeIngestInput(payload, Date.parse('2026-09-10T12:00:00Z'));
  const otherMailbox = normalizeIngestInput(
    { ...payload, mailboxAddress: 'second@example.com' },
    Date.parse('2026-09-10T12:00:00Z')
  );

  assert.notEqual(ingestReceiptId(first), ingestReceiptId(otherMailbox));
  assert.notEqual(ingestPayloadHash(first), ingestPayloadHash(otherMailbox));
});

test('daily task identity is branch- and Central-day-scoped', () => {
  const base = { branchId: 'b1', conversationId: 'c1', dayKey: '2026-09-10' };
  assert.equal(dailyThreadId(base), dailyThreadId({ ...base }));
  assert.notEqual(dailyThreadId(base), dailyThreadId({ ...base, branchId: 'b2' }));
  assert.notEqual(dailyThreadId(base), dailyThreadId({ ...base, dayKey: '2026-09-11' }));
});

test('model JSON and schemas are validated instead of silently defaulted', () => {
  assert.deepEqual(parseJsonObject('{"actionRequired":false}', 'classification'), {
    actionRequired: false,
  });
  assert.throws(() => parseJsonObject('[]', 'classification'), /JSON object/);
  assert.throws(() => validateClassification({ actionRequired: 'yes' }), /boolean/);
  assert.throws(
    () => validateClassification({ actionRequired: true, title: 'Do it', priority: 'urgent' }),
    /priority/
  );
  assert.deepEqual(validateClassification({
    actionRequired: true,
    title: '  Confirm coverage  ',
    detail: ' Four needed. ',
    priority: 'high',
    jobOrderRequest: null,
  }), {
    actionRequired: true,
    title: 'Confirm coverage',
    detail: 'Four needed.',
    priority: 'high',
    jobOrderRequest: null,
    accountSuggestion: null,
  });
  assert.deepEqual(validateClassification({ actionRequired: false }), {
    actionRequired: false,
    jobOrderRequest: null,
  });
  assert.throws(() => validateClassification({
    actionRequired: true,
    title: 'Need people',
    detail: null,
    priority: 'high',
    account: 'Model must not route this',
  }), /unsupported fields/);
  assert.throws(() => validateReplyVerdict({ resolved: 1 }), /boolean/);
  assert.deepEqual(validateReplyVerdict({ resolved: true, reason: ' Done. ' }), {
    resolved: true,
    reason: 'Done.',
  });
});

test('job order request validation accepts only bounded staffing facts', () => {
  assert.deepEqual(validateJobOrderRequest({
    headcount: 4,
    role: ' Reach operator ',
    shift: ' 2nd ',
    days: ' Monday-Friday ',
    hours: ' 2:30 PM-11 PM ',
    pay: 20.555,
  }), {
    headcount: 4,
    role: 'Reach operator',
    shift: '2nd',
    days: 'Monday-Friday',
    hours: '2:30 PM-11 PM',
    pay: 20.56,
  });
  assert.deepEqual(validateJobOrderRequest({ headcount: null }), {
    headcount: null,
    role: null,
    shift: null,
    days: null,
    hours: null,
    pay: null,
  });
  assert.throws(() => validateJobOrderRequest({ headcount: 0 }), /headcount/);
  assert.throws(() => validateJobOrderRequest({ headcount: 2.5 }), /headcount/);
  assert.throws(() => validateJobOrderRequest({ headcount: 201 }), /headcount/);
  assert.throws(() => validateJobOrderRequest({ headcount: 2, pay: '$20' }), /pay/);
  assert.throws(() => validateJobOrderRequest({
    headcount: 2,
    accountId: 'model-selected-account',
  }), /unsupported fields/);
});

test('staffing request survives on classification while account selection is absent', () => {
  const classification = validateClassification({
    actionRequired: true,
    title: 'Recruit four reach operators',
    detail: 'Second shift starts Monday.',
    priority: 'high',
    jobOrderRequest: {
      headcount: 4,
      role: 'Reach operator',
      shift: '2nd',
      days: 'M-F',
      hours: null,
      pay: 21,
    },
  });
  assert.equal(classification.jobOrderRequest.headcount, 4);
  assert.equal(Object.hasOwn(classification.jobOrderRequest, 'accountId'), false);

  assert.throws(() => validateClassification({
    actionRequired: false,
    jobOrderRequest: { headcount: 4 },
  }), /non-actionable/);
});

test('daily job order identity is stable per branch, thread, and Central day', () => {
  const base = {
    branchId: 'b2', dayKey: '2026-09-10', conversationId: 'thread-1', messageId: 'm1',
  };
  assert.equal(dailyJobOrderId(base), dailyJobOrderId({ ...base, messageId: 'm2' }));
  assert.notEqual(dailyJobOrderId(base), dailyJobOrderId({ ...base, branchId: 'b1' }));
  assert.notEqual(dailyJobOrderId(base), dailyJobOrderId({ ...base, dayKey: '2026-09-11' }));
  assert.notEqual(dailyJobOrderId(base), dailyJobOrderId({ ...base, conversationId: 'thread-2' }));
});

const jobOrderInput = {
  branchId: 'b2',
  dayKey: '2026-09-10',
  conversationId: 'thread-1',
  messageId: 'message-1',
  createdAt: 1_789_000_000_000,
};
const resolvedJobOrderRoute = {
  accountId: 'account-stable-id',
  accountName: 'GEODIS',
  accountUnitId: 'unit-stable-id',
  accountUnitName: 'Plainfield receiving',
  needsAccountReview: false,
};
const validatedJobOrderRequest = validateJobOrderRequest({
  headcount: 3,
  role: 'Reach operator',
  shift: '2nd',
  days: 'M-F',
  hours: '2:30 PM-11 PM',
  pay: 21,
});

test('automatic order eligibility requires a count and unambiguous stable account ID', () => {
  const classification = { actionRequired: true, jobOrderRequest: validatedJobOrderRequest };
  assert.equal(canAutoCreateJobOrder(classification, resolvedJobOrderRoute), true);
  assert.equal(canAutoCreateJobOrder(classification, {
    ...resolvedJobOrderRoute, needsAccountReview: true,
  }), false);
  assert.equal(canAutoCreateJobOrder(classification, {
    ...resolvedJobOrderRoute, accountId: null,
  }), false);
  assert.equal(canAutoCreateJobOrder({
    actionRequired: true,
    jobOrderRequest: { ...validatedJobOrderRequest, headcount: null },
  }, resolvedJobOrderRoute), false);
  assert.equal(canAutoCreateJobOrder({
    actionRequired: false,
    jobOrderRequest: validatedJobOrderRequest,
  }, resolvedJobOrderRoute), false);
});

test('email order uses deterministic IDs, links, slots, and eligible owner snapshots', () => {
  const order = buildEmailJobOrder({
    input: jobOrderInput,
    taskId: 'task-1',
    accountRoute: resolvedJobOrderRoute,
    jobOrderRequest: validatedJobOrderRequest,
    ownerId: 'user-1',
    ownerInitials: ' AB ',
    isPriority: true,
    recordedAt: 1_789_000_000_100,
  });
  assert.equal(order.accountId, 'account-stable-id');
  assert.equal(order.accountUnitId, 'unit-stable-id');
  assert.equal(order.account, 'GEODIS');
  assert.equal(order.site, 'Plainfield receiving');
  assert.equal(order.sourceTaskId, 'task-1');
  assert.equal(order.sourceMessageId, 'message-1');
  assert.equal(order.sourceConversationId, 'thread-1');
  assert.equal(order.sourceBoardDate, '2026-09-10');
  assert.equal(order.ownerId, 'user-1');
  assert.equal(order.owner, 'AB');
  assert.deepEqual(order.slots.map((slot) => slot.id), [
    'opening_001', 'opening_002', 'opening_003',
  ]);
  assert.equal(order.slots.every((slot) => slot.initials === null), true);
});

test('email order never retains initials without an eligible owner ID', () => {
  const order = buildEmailJobOrder({
    input: jobOrderInput,
    taskId: 'task-1',
    accountRoute: resolvedJobOrderRoute,
    jobOrderRequest: validatedJobOrderRequest,
    ownerId: null,
    ownerInitials: 'SHOULD-NOT-SURVIVE',
  });
  assert.equal(order.ownerId, null);
  assert.equal(order.owner, null);
});

test('matching deterministic email order is linked without overwriting human edits', () => {
  const desired = buildEmailJobOrder({
    input: jobOrderInput,
    taskId: 'task-1',
    accountRoute: resolvedJobOrderRoute,
    jobOrderRequest: { ...validatedJobOrderRequest, headcount: 2, role: null, pay: null },
    ownerId: null,
    ownerInitials: null,
    recordedAt: 200,
  });
  const existing = {
    ...buildEmailJobOrder({
      input: jobOrderInput,
      taskId: 'task-1',
      accountRoute: resolvedJobOrderRoute,
      jobOrderRequest: { ...validatedJobOrderRequest, headcount: 4 },
      ownerId: 'user-1',
      ownerInitials: 'AB',
      recordedAt: 100,
    }),
    role: 'Known role',
    rate: 22,
  };
  existing.slots[3] = { ...existing.slots[3], initials: 'CD' };

  const plan = planEmailJobOrderWrite(existing, desired);
  assert.deepEqual(plan, { kind: 'link_only' });
  assert.equal(existing.role, 'Known role');
  assert.equal(existing.rate, 22);
  assert.equal(existing.ownerId, 'user-1');
  assert.equal(existing.slots.length, 4);
  assert.equal(existing.slots[3].initials, 'CD');
  assert.equal(planEmailJobOrderWrite({
    ...existing,
    sourceMessageId: 'another-message',
  }, desired).kind, 'conflict');
});

test('email order planner creates once and refuses deterministic-ID conflicts', () => {
  const desired = buildEmailJobOrder({
    input: jobOrderInput,
    taskId: 'task-1',
    accountRoute: resolvedJobOrderRoute,
    jobOrderRequest: { ...validatedJobOrderRequest, headcount: 5 },
  });
  const creation = planEmailJobOrderWrite(null, desired);
  assert.equal(creation.kind, 'create');
  assert.equal(creation.data, desired);
  const existing = { ...desired, slots: desired.slots.slice(0, 2) };
  assert.deepEqual(planEmailJobOrderWrite(existing, desired), { kind: 'link_only' });
  assert.equal(planEmailJobOrderWrite({
    ...existing,
    sourceTaskId: 'unrelated-task',
  }, desired).kind, 'conflict');
});

test('reply input normalizes display-name email and requires usable reply text', () => {
  const input = normalizeReplyInput({
    branchId: 'b1',
    conversationId: 'c1',
    messageId: 'reply-1',
    from: 'Team Member <Person@Example.com>',
    body: 'This is complete.',
  }, Date.parse('2026-09-10T12:00:00Z'));
  assert.equal(input.from, 'person@example.com');
  assert.equal(input.dayKey, '2026-09-10');
  assert.throws(
    () => normalizeReplyInput({ conversationId: 'c1', from: 'person@example.com', body: ' ' }),
    /body/
  );
});

test('task day reads boardDate first and supports pre-migration timestamps', () => {
  assert.equal(taskDayKey({ boardDate: '2026-09-10', createdAt: 0 }), '2026-09-10');
  assert.equal(taskDayKey({ dayKey: '2026-09-09', createdAt: 0 }), '2026-09-09');
  assert.equal(taskDayKey({ createdAt: Date.parse('2026-09-10T04:59:59Z') }), '2026-09-09');
});

test('reply selection carries forward a sole open task and enforces branch membership', () => {
  const candidates = [
    { id: 'old', data: { branchId: 'b1', status: 'open', boardDate: '2026-09-09', createdAt: 1 } },
    { id: 'done', data: { branchId: 'b1', status: 'done', boardDate: '2026-09-10', createdAt: 2 } },
    { id: 'foreign', data: { branchId: 'b2', status: 'open', boardDate: '2026-09-10', createdAt: 3 } },
  ];
  const options = { branchId: 'b1', userBranchIds: ['b1'], dayKey: '2026-09-10' };
  const selected = selectReplyCandidate(candidates, options);
  assert.equal(selected.kind, 'open');
  assert.equal(selected.candidate.id, 'old');
  assert.equal(selectReplyCandidate(candidates, { ...options, branchId: 'b2' }).kind, 'none');
});

test('reply selection refuses ambiguous cross-branch or cross-day open tasks', () => {
  const crossBranch = selectReplyCandidate([
    { id: 'one', data: { branchId: 'b1', status: 'open', boardDate: '2026-09-09' } },
    { id: 'two', data: { branchId: 'b2', status: 'open', boardDate: '2026-09-10' } },
  ], {
    branchId: null, userBranchIds: ['b1', 'b2'], dayKey: '2026-09-10',
  });
  assert.equal(crossBranch.kind, 'ambiguous');

  for (const secondDay of ['2026-09-09', '2026-09-10']) {
    const duplicate = selectReplyCandidate([
      { id: 'one', data: { branchId: 'b1', status: 'open', boardDate: '2026-09-09' } },
      { id: 'two', data: { branchId: 'b1', status: 'open', boardDate: secondDay } },
    ], { branchId: 'b1', userBranchIds: ['b1'], dayKey: '2026-09-10' });
    assert.equal(duplicate.kind, 'ambiguous');
  }
});

test('reply selection identifies an exact prior reply before newer or reopened work', () => {
  for (const status of ['reply_closed', 'done', 'open']) {
    const selected = selectReplyCandidate([
      { id: 'old', data: {
        branchId: 'b1', status, boardDate: '2026-09-09',
        closedByReply: { messageId: 'reply-1' },
      } },
      { id: 'new', data: { branchId: 'b1', status: 'open', boardDate: '2026-09-10' } },
    ], {
      branchId: 'b1', userBranchIds: ['b1'], dayKey: '2026-09-10', messageId: 'reply-1',
    });
    assert.equal(selected.kind, 'already_processed');
    assert.equal(selected.candidate.id, 'old');
  }
  assert.equal(selectReplyCandidate([
    { id: 'closed', data: { branchId: 'b1', status: 'reply_closed', boardDate: '2026-09-10' } },
  ], { branchId: 'b1', userBranchIds: ['b1'], dayKey: '2026-09-10', messageId: 'new-reply' }).kind, 'none');
});

test('reply selection excludes future work, including later requests on the same day', () => {
  const options = {
    branchId: 'b1', userBranchIds: ['b1'], dayKey: '2026-09-10',
    createdAt: Date.parse('2026-09-10T15:00:00Z'),
  };
  for (const data of [
    { boardDate: '2026-09-11' },
    { boardDate: '2026-09-10', createdAt: Date.parse('2026-09-10T16:00:00Z') },
    { boardDate: '2026-09-10', sourceEmail: { receivedAt: Date.parse('2026-09-10T16:00:00Z') } },
    { createdAt: Date.parse('2026-09-11T16:00:00Z') },
  ]) {
    assert.equal(selectReplyCandidate([
      { id: 'future', data: { branchId: 'b1', status: 'open', ...data } },
    ], options).kind, 'none');
  }
});

test('reply selection supports older legacy tasks using their creation day', () => {
  const selected = selectReplyCandidate([
    { id: 'legacy', data: { branchId: 'b1', status: 'open', createdAt: 1 } },
  ], { branchId: 'b1', userBranchIds: ['b1'], dayKey: '2026-09-10' });
  assert.equal(selected.kind, 'open');
  assert.equal(selected.candidate.id, 'legacy');
});

test('reply message identity and payload hashes survive midnight retries', () => {
  const payload = {
    branchId: 'b1', conversationId: 'c1', from: 'Person@Example.com',
    messageId: 'reply-1', body: 'Done.',
  };
  const first = normalizeReplyInput(payload, Date.parse('2026-09-10T04:59:59Z'));
  const retry = normalizeReplyInput(payload, Date.parse('2026-09-10T05:00:01Z'));
  assert.equal(replyReceiptId(first), replyReceiptId(retry));
  assert.equal(replyPayloadHash(first), replyPayloadHash(retry));
  assert.notEqual(replyPayloadHash(first), replyPayloadHash({ ...retry, body: 'Still pending.' }));
  assert.throws(() => normalizeReplyInput({ ...payload, messageId: undefined }), /messageId/);
});

test('reply context includes the full request, summary and reply beyond its audit excerpt', () => {
  const task = {
    branchId: 'b1', boardDate: '2026-09-09', title: 'Confirm coverage',
    detail: 'Four associates plus a lead.', updatedAt: 1,
    sourceEmail: { subject: 'Coverage request', from: 'client@example.com', conversationId: 'c1' },
  };
  const detail = { bodyText: 'Need four associates and one lead.', isTruncated: false };
  const input = { from: 'person@example.com', body: 'Intro. '.repeat(80) + 'The lead is still unconfirmed.' };
  const context = replyResolutionContext(task, detail, input);
  assert.equal(context.task.originalRequest, detail.bodyText);
  assert.equal(context.task.summary, task.detail);
  assert.match(context.reply.body, /lead is still unconfirmed/);
  assert.equal(context.reply.truncated, false);
  assert.equal(replyResolutionContext(task, detail, { ...input, body: 'x'.repeat(6100) }).reply.truncated, true);
  assert.equal(replyResolutionContext(task, { ...detail, isTruncated: true }, input).task.requestTruncated, true);
  assert.notEqual(replyTaskFingerprint(task, detail, input), replyTaskFingerprint({ ...task, detail: 'Changed' }, detail, input));
  assert.notEqual(replyTaskFingerprint(task, detail, input), replyTaskFingerprint(task, { ...detail, bodyText: 'Changed request' }, input));
});

test('topOfThread removes quoted history and caps model input', () => {
  const current = 'We have this handled and coverage is confirmed.';
  assert.equal(
    topOfThread(`${current}\n\n-----Original Message-----\nFrom: Client`),
    current
  );
  assert.equal(topOfThread('x'.repeat(7000)).length, 6000);
});

test('email detail is sanitized plaintext, newest-message-only, and capped', () => {
  const detail = emailDetailBody(
    '<p>Need 4 &amp; a lead.</p><script>doBadThing()</script>'
      + '\n-----Original Message-----\nFrom: Someone'
  );
  assert.equal(detail.bodyText, 'Need 4 & a lead.');
  assert.equal(detail.isTruncated, false);
  assert.equal(detail.originalLength, detail.bodyText.length);

  const long = emailDetailBody('x'.repeat(25000));
  assert.equal(long.bodyText.length, 24000);
  assert.equal(long.originalLength, 25000);
  assert.equal(long.isTruncated, true);
});

const directory = {
  accounts: [
    {
      id: 'geodis', name: 'GEODIS', aliases: ['GEODIS operation'],
      domains: ['geodis.com'], ownerId: 'parent-owner', active: true,
    },
    {
      id: 'acme', name: 'Acme', aliases: ['shared alias'],
      domains: ['acme.com'], ownerId: 'acme-owner', active: true,
    },
    {
      id: 'other', name: 'Other', aliases: ['shared alias'],
      domains: ['other.com'], ownerId: 'other-owner', active: true,
    },
  ],
  accountUnits: [
    {
      id: 'plainfield', accountId: 'geodis', name: 'Plainfield Receiving',
      aliases: ['Plainfield'], ownerId: 'unit-owner', active: true,
    },
    {
      id: 'joliet', accountId: 'geodis', name: 'Joliet Shipping',
      aliases: ['Joliet'], ownerId: null, active: true,
    },
  ],
  accountContacts: [
    {
      id: 'global', accountId: 'geodis', accountUnitIds: [],
      emailLower: 'global@geodis.com', scope: 'account', active: true,
    },
    {
      id: 'site', accountId: 'geodis', accountUnitIds: ['plainfield'],
      emailLower: 'site@geodis.com', scope: 'unit', active: true,
    },
  ],
};

test('exact unit contact wins and uses the unit owner override', () => {
  const route = resolveAccountRoute({
    ...directory,
    from: 'Site Lead <site@geodis.com>',
    subject: 'Joliet mentioned incidentally',
  });
  assert.equal(route.accountId, 'geodis');
  assert.equal(route.accountUnitId, 'plainfield');
  assert.equal(route.ownerId, 'unit-owner');
  assert.equal(route.needsAccountReview, false);
});

test('account-wide contact uses unique location context but never guesses without it', () => {
  const contextual = resolveAccountRoute({
    ...directory,
    from: 'global@geodis.com',
    subject: 'Coverage at Joliet',
  });
  assert.equal(contextual.accountId, 'geodis');
  assert.equal(contextual.accountUnitId, 'joliet');
  assert.equal(contextual.ownerId, 'parent-owner');
  assert.equal(contextual.needsAccountReview, false);

  const ambiguous = resolveAccountRoute({
    ...directory,
    from: 'global@geodis.com',
    subject: 'Coverage needed',
  });
  assert.equal(ambiguous.accountId, 'geodis');
  assert.equal(ambiguous.accountUnitId, null);
  assert.equal(ambiguous.needsAccountReview, true);
  assert.equal(ambiguous.ownerId, null);
  assert.deepEqual(ambiguous.accountUnitCandidateIds, ['joliet', 'plainfield']);
});

test('a unique domain identifies only the parent and stays unassigned when units are ambiguous', () => {
  const route = resolveAccountRoute({
    ...directory,
    from: 'unknown@geodis.com',
    subject: 'Need help',
  });
  assert.equal(route.accountId, 'geodis');
  assert.equal(route.accountUnitId, null);
  assert.equal(route.needsAccountReview, true);
  assert.equal(route.ownerId, null);
});

test('unique unit context resolves a sender without a known contact or domain', () => {
  const route = resolveAccountRoute({
    ...directory,
    from: 'forwarder@example.net',
    subject: 'Plainfield coverage request',
  });
  assert.equal(route.accountId, 'geodis');
  assert.equal(route.accountUnitId, 'plainfield');
  assert.equal(route.ownerId, 'unit-owner');
  assert.equal(route.needsAccountReview, false);
});

test('colliding parent aliases produce review candidates instead of a guessed account', () => {
  const route = resolveAccountRoute({
    ...directory,
    from: 'unknown@example.net',
    subject: 'Shared alias request',
  });
  assert.equal(route.accountId, null);
  assert.equal(route.accountUnitId, null);
  assert.equal(route.ownerId, null);
  assert.equal(route.needsAccountReview, true);
  assert.deepEqual(route.accountCandidateIds, ['acme', 'other']);
});

test('unit ownership inherits from the closest configured ancestor', () => {
  const route = resolveAccountRoute({
    accounts: [{ id: 'parent-account', name: 'Parent account', ownerId: 'account-owner' }],
    accountUnits: [
      {
        id: 'region', accountId: 'parent-account', name: 'Region',
        ownerId: 'region-owner', active: true,
      },
      {
        id: 'dock', accountId: 'parent-account', name: 'Dock 12',
        aliases: ['dock twelve'], parentUnitId: 'region', ownerId: null, active: true,
      },
    ],
    subject: 'Need coverage at dock twelve',
  });
  assert.equal(route.accountUnitId, 'dock');
  assert.equal(route.ownerId, 'region-owner');
});

test('unit owner inheritance is cycle-safe and falls back to the account owner', () => {
  const route = resolveAccountRoute({
    accounts: [{ id: 'parent-account', name: 'Parent account', ownerId: 'account-owner' }],
    accountUnits: [
      {
        id: 'one', accountId: 'parent-account', name: 'Cycle target',
        parentUnitId: 'two', ownerId: null, active: true,
      },
      {
        id: 'two', accountId: 'parent-account', name: 'Other unit',
        parentUnitId: 'one', ownerId: null, active: true,
      },
    ],
    subject: 'Cycle target needs coverage',
  });
  assert.equal(route.accountUnitId, 'one');
  assert.equal(route.ownerId, 'account-owner');
});

test('resolved ownership is accepted only for an active user in the task branch', () => {
  const owner = { id: 'owner', branchIds: ['b1', 'b2'], active: true };
  assert.equal(eligibleOwnerId('owner', owner, 'b2'), 'owner');
  assert.equal(eligibleOwnerId('owner', { ...owner, active: false }, 'b2'), null);
  assert.equal(eligibleOwnerId('owner', { ...owner, active: 'yes' }, 'b2'), null);
  assert.equal(eligibleOwnerId('owner', { id: 'owner', branchIds: ['b2'] }, 'b2'), 'owner');
  assert.equal(eligibleOwnerId('owner', { ...owner, branchIds: ['b1'] }, 'b2'), null);
  assert.equal(eligibleOwnerId('owner', { ...owner, id: 'different-user' }, 'b2'), null);
  assert.equal(eligibleOwnerId('missing', null, 'b2'), null);
});

const recipientBase = {
  branchId: 'b2', conversationId: 'c1', messageId: 'm1', mailboxAddress: 'board@example.com',
};

test('recipients parse Outlook strings and arrays while unknown stays distinct from empty', () => {
  const input = normalizeIngestInput({
    ...recipientBase,
    to: 'Board@Example.com; "Ortiz, Iovana" <iovana@example.com>;board@example.com',
    cc: ['client@client.com.'],
  });
  assert.deepEqual(input.to, ['board@example.com', 'iovana@example.com']);
  assert.deepEqual(input.cc, ['client@client.com']);

  const unknown = normalizeIngestInput(recipientBase);
  assert.equal(unknown.to, null);
  assert.equal(unknown.cc, null);
  assert.deepEqual(normalizeIngestInput({ ...recipientBase, cc: '' }).cc, []);
  assert.throws(() => normalizeIngestInput({ ...recipientBase, to: 7 }), /to must be/);
  assert.equal(ingestPayloadHash(input), ingestPayloadHash(unknown), 'recipients stay out of retry identity');

  const reply = normalizeReplyInput({
    conversationId: 'c1', messageId: 'r1', from: 'luz@example.com', body: 'Sent.', to: 'client@client.com',
  });
  assert.deepEqual(reply.to, ['client@client.com']);
  assert.equal(reply.cc, null);
});

test('timecards mail is skipped only when no branch mailbox is on the To line', () => {
  const branch = { mailboxAddresses: ['board@example.com', 'Alias@Example.com'] };
  const email = (overrides = {}) => normalizeIngestInput({
    ...recipientBase,
    from: 'Timecards Bolingbrook <timecards.bolingbrookil@employbridge.com>',
    to: 'payroll@employbridge.com',
    cc: 'board@example.com',
    ...overrides,
  });

  assert.equal(isUndirectedTimecardsEmail(email(), branch), true, 'a Cc copy is not branch work');
  assert.equal(isUndirectedTimecardsEmail(email({ from: 'timcards.edwardsvilleil@employbridge.com' }), branch), true);
  assert.equal(isUndirectedTimecardsEmail(email({ from: 'TIMECARDS@EmployBridge.com' }), branch), true);
  assert.equal(isUndirectedTimecardsEmail(email({ to: '' }), branch), true);

  assert.equal(isUndirectedTimecardsEmail(email({ to: 'payroll@employbridge.com; Board@example.com' }), branch), false);
  assert.equal(isUndirectedTimecardsEmail(email({ to: 'alias@example.com' }), branch), false, 'configured aliases count');
  assert.equal(isUndirectedTimecardsEmail(email({ to: 'Market.Manager@example.com' }), branch, ['market.manager@example.com']),
    false, 'a branch team member on the To line counts');
  assert.equal(isUndirectedTimecardsEmail(email(), branch, ['market.manager@example.com']), true);
  assert.equal(isUndirectedTimecardsEmail(email({ to: undefined }), branch), false, 'unknown recipients are triaged');
  for (const from of ['client@client.com', 'timecards@client.com', 'luz@employbridge.com']) {
    assert.equal(isUndirectedTimecardsEmail(email({ from }), branch), false, from);
  }
});

const routingDirectory = {
  accounts: [
    { id: 'payroll-b2', branchId: 'b2', name: 'Payroll', active: true },
    { id: 'internal-b2', branchId: 'b2', name: 'Internal', active: true },
    { id: 'diageo', branchId: 'b2', name: 'Diageo', ownerId: 'diageo-owner', active: true },
    { id: 'archived', branchId: 'b2', name: 'Archived Client', active: false },
  ],
  accountUnits: [
    { id: 'lincolnway', branchId: 'b2', accountId: 'diageo', name: 'Lincolnway', active: true },
  ],
  accountContacts: [],
};
const routeEmail = (overrides) => routeInboundEmail({
  ...routingDirectory, subject: 'Hours', body: 'Please approve.', ...overrides,
});

test('EmployBridge timecards and system inboxes are internal senders; people are not', () => {
  assert.equal(internalSenderKind('Timecards <timecards.bolingbrookil@employbridge.com>'), 'payroll');
  assert.equal(internalSenderKind('timcards.edwardsvilleil@employbridge.com'), 'payroll');
  for (const from of ['crt@employbridge.com', 'BackgroundChecks@EmployBridge.com', 'talentsupportteam@employbridge.com']) {
    assert.equal(internalSenderKind(from), 'internal', from);
  }
  for (const from of ['sarah.vazquez@employbridge.com', 'crt@client.com', 'ops@geodis.com', 'not an address']) {
    assert.equal(internalSenderKind(from), null, from);
  }
  assert.equal(internalSenderKind('luz@employbridge.com', ['Luz@employbridge.com']), null, 'board teammates are people');
});

test('reserved accounts are assigned only by sender and never matched from message text', () => {
  const payroll = routeEmail({ from: 'timecards.bolingbrookil@employbridge.com' });
  assert.equal(payroll.accountId, 'payroll-b2');
  assert.equal(payroll.needsAccountReview, false);
  assert.equal(payroll.internalAccount, 'payroll');
  assert.equal(payroll.ownerId, null);

  const client = routeEmail({ from: 'timecards.bolingbrookil@employbridge.com', body: 'Missed punches at Lincolnway.' });
  assert.equal(client.accountId, 'diageo', 'a timecards email keeps an unambiguous client');
  assert.equal(client.accountUnitId, 'lincolnway');
  assert.equal(client.needsAccountReview, false);
  assert.equal(client.internalAccount, null);

  const internal = routeEmail({ from: 'crt@employbridge.com', body: 'Background order for Lincolnway.' });
  assert.equal(internal.accountId, 'internal-b2', 'system inboxes are Internal even when a client is named');
  assert.equal(internal.internalAccount, 'internal');

  const mentions = routeEmail({ from: 'ops@client.com', subject: 'Payroll question', body: 'Internal payroll review needed.' });
  assert.equal(mentions.accountId, null);
  assert.equal(mentions.needsAccountReview, true);
  assert.deepEqual(mentions.accountCandidateIds, []);

  const missing = routeEmail({ accounts: routingDirectory.accounts.slice(2), from: 'crt@employbridge.com' });
  assert.equal(missing.accountId, null, 'branches without reserved accounts fall back to normal routing');
  assert.equal(missing.internalAccount, null);

  assert.equal(canAutoCreateJobOrder(
    { actionRequired: true, jobOrderRequest: { headcount: 2 } }, payroll
  ), false, 'reserved accounts never get job orders');
});

test('AI account suggestions are validated against the directory and always need review', () => {
  const unresolved = routeEmail({ from: 'ops@client.com', body: 'Need help.' });
  const payroll = routeEmail({ from: 'timecards.bolingbrookil@employbridge.com' });
  const internal = routeEmail({ from: 'crt@employbridge.com' });
  const resolved = routeEmail({ from: 'ops@client.com', body: 'At Lincolnway.' });
  const suggestion = (overrides = {}) => ({
    accountId: 'diageo', accountUnitId: 'lincolnway', confidence: 'medium', reason: 'Mentions Lincolnway.', ...overrides,
  });

  const applied = applyAccountSuggestion(unresolved, suggestion(), routingDirectory);
  assert.equal(applied.route.accountId, 'diageo');
  assert.equal(applied.route.accountUnitName, 'Lincolnway');
  assert.equal(applied.route.needsAccountReview, true);
  assert.equal(applied.route.ownerId, null, 'a suggestion never assigns the account owner');
  assert.deepEqual(applied.route.accountCandidateIds, ['diageo']);
  assert.deepEqual(applied.accountSuggestion, {
    source: 'ai', accountId: 'diageo', accountUnitId: 'lincolnway', confidence: 'medium', reason: 'Mentions Lincolnway.',
  });
  assert.equal(applyAccountSuggestion(unresolved, suggestion({ accountUnitId: 'not-a-unit' }), routingDirectory).route.accountUnitId, null);

  for (const accountId of ['payroll-b2', 'internal-b2', 'archived', 'invented']) {
    assert.deepEqual(applyAccountSuggestion(unresolved, suggestion({ accountId }), routingDirectory),
      { route: unresolved, accountSuggestion: null }, accountId);
  }
  assert.equal(applyAccountSuggestion(payroll, suggestion(), routingDirectory).route, payroll, 'medium confidence keeps Payroll');
  const highOnPayroll = applyAccountSuggestion(payroll, suggestion({ confidence: 'high' }), routingDirectory);
  assert.equal(highOnPayroll.route.accountId, 'diageo');
  assert.equal(highOnPayroll.route.needsAccountReview, true);
  assert.equal(highOnPayroll.route.internalAccount, null);
  assert.equal(applyAccountSuggestion(internal, suggestion({ confidence: 'high' }), routingDirectory).route, internal);
  assert.equal(applyAccountSuggestion(resolved, suggestion({ confidence: 'high' }), routingDirectory).route, resolved);

  assert.deepEqual(accountSuggestionDirectory(routingDirectory), [
    { id: 'diageo', name: 'Diageo', units: [{ id: 'lincolnway', name: 'Lincolnway' }] },
  ]);
});

test('classification keeps a well-formed account suggestion and drops a malformed one', () => {
  const base = { actionRequired: true, title: 'Fix punches', detail: null, priority: 'normal', jobOrderRequest: null };
  assert.deepEqual(validateClassification({
    ...base, accountSuggestion: { accountId: 'diageo', accountUnitId: null, confidence: 'high', reason: ' Names Diageo. ' },
  }).accountSuggestion, { accountId: 'diageo', accountUnitId: null, confidence: 'high', reason: 'Names Diageo.' });
  for (const accountSuggestion of [
    { accountId: 'diageo', confidence: 'certain' },
    { accountId: '', confidence: 'high' },
    { accountId: 'diageo', confidence: 'high', ownerId: 'someone' },
    'diageo',
  ]) {
    assert.equal(validateClassification({ ...base, accountSuggestion }).accountSuggestion, null);
  }
  assert.equal(validateClassification({
    actionRequired: false, accountSuggestion: { accountId: 'diageo', confidence: 'high' },
  }).accountSuggestion, undefined);
});

test('a shared intake mailbox resolves one branch from To, then Cc, and refuses ambiguity', () => {
  const branches = [
    { id: 'branch-30086', mailboxAddresses: ['RMFG-FentonMO@resourcemfg.com'] },
    { id: 'branch-81052', mailboxAddresses: ['plx-aurorail@prologistix.com', 'rmfg-aurorail@resourcemfg.com'] },
    { id: 'branch-duplicate', mailboxAddresses: ['rmfg-fentonmo@resourcemfg.com'] },
    { id: 'branch-unbound' },
  ];
  const resolve = (options) => resolveBranchByRecipients({ branches: branches.slice(0, 2), ...options });

  assert.deepEqual(resolve({ to: ['intake@example.com', 'rmfg-fentonmo@resourcemfg.com'] }),
    { kind: 'branch', branchId: 'branch-30086', mailboxAddress: 'rmfg-fentonmo@resourcemfg.com' });
  assert.deepEqual(resolve({ to: ['intake@example.com'], cc: ['RMFG-FentonMO@resourcemfg.com'] }),
    { kind: 'branch', branchId: 'branch-30086', mailboxAddress: 'rmfg-fentonmo@resourcemfg.com' });
  assert.equal(resolve({
    to: ['rmfg-fentonmo@resourcemfg.com'], cc: ['plx-aurorail@prologistix.com'],
  }).branchId, 'branch-30086', 'the To line decides even when another branch is copied');
  assert.deepEqual(resolve({ to: ['rmfg-aurorail@resourcemfg.com', 'plx-aurorail@prologistix.com'] }),
    { kind: 'branch', branchId: 'branch-81052', mailboxAddress: 'plx-aurorail@prologistix.com' },
    'one branch with two brand mailboxes stays one branch, with a stable pick');

  assert.equal(resolve({ to: ['rmfg-fentonmo@resourcemfg.com', 'plx-aurorail@prologistix.com'] }).kind, 'ambiguous');
  assert.match(resolveBranchByRecipients({ branches, to: ['rmfg-fentonmo@resourcemfg.com'] }).reason,
    /more than one branch/, 'an address bound to two branches is a misconfiguration, not a guess');
  assert.equal(resolve({ to: ['intake@example.com'] }).kind, 'none');
  assert.equal(resolve({}).kind, 'none');
  assert.equal(resolveBranchByRecipients().kind, 'none');
});
