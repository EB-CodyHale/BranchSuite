'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { BoardUserError, createBoardUser, deleteBoardUser } = require('../lib/board-users');

const newPerson = {
  name: ' New Person ', email: ' New.Person@Example.com ', initials: 'np',
  role: 'member', marker: 'teal', branchIds: ['b2', 'b2'],
};

// In-memory Firestore and Auth boundaries. No credentials or live accounts.
function fakes({ records: seeded = {}, authUsers = {}, failRosterWrite = false } = {}) {
  const records = new Map(Object.entries({
    'users/admin-1': { email: 'admin@example.com', role: 'admin', branchIds: ['b1', 'b2'] },
    'users/manager-1': { email: 'manager@example.com', role: 'manager', branchIds: ['b2'] },
    'branches/b1': { name: 'One' },
    'branches/b2': { name: 'Two' },
    ...seeded,
  }));
  const accounts = new Map(Object.entries(authUsers));
  const calls = { created: [], deleted: [] };
  const snapshot = (key) => ({ exists: records.has(key), data: () => structuredClone(records.get(key)) });
  const db = {
    collection: (name) => ({
      doc: (id) => ({
        path: `${name}/${id}`,
        get: async () => snapshot(`${name}/${id}`),
        delete: async () => { records.delete(`${name}/${id}`); },
      }),
      where: (field, operator, value) => {
        assert.equal(operator, '==');
        return {
          limit: () => ({
            get: async () => {
              const docs = [...records].filter(([key, data]) => key.startsWith(`${name}/`) && data[field] === value);
              return { empty: !docs.length, docs };
            },
          }),
        };
      },
    }),
    runTransaction: async (callback) => {
      const writes = [];
      await callback({
        get: (reference) => reference.get(),
        create: (reference, data) => writes.push([reference.path, data]),
      });
      if (failRosterWrite) throw new Error('firestore unavailable');
      for (const [key, data] of writes) {
        assert.equal(records.has(key), false, 'roster documents are never overwritten');
        records.set(key, structuredClone(data));
      }
    },
  };
  const auth = {
    createUser: async (properties) => {
      if (accounts.has(properties.email)) {
        throw Object.assign(new Error('exists'), { code: 'auth/email-already-exists' });
      }
      const uid = `uid-${calls.created.length + 1}`;
      accounts.set(properties.email, uid);
      calls.created.push(properties);
      return { uid };
    },
    getUserByEmail: async (email) => ({ uid: accounts.get(email) }),
    deleteUser: async (uid) => {
      const entry = [...accounts].find(([, id]) => id === uid);
      if (!entry) throw Object.assign(new Error('no such user'), { code: 'auth/user-not-found' });
      calls.deleted.push(uid);
      accounts.delete(entry[0]);
    },
  };
  return { db, auth, records, accounts, calls };
}

const run = (app, options = {}) => createBoardUser({
  db: app.db, auth: app.auth, callerUid: 'admin-1', data: newPerson, ...options,
});
const codeIs = (code) => (error) => error instanceof BoardUserError && error.code === code;

test('an admin creates the sign-in and roster document under the same UID', async () => {
  const app = fakes();
  assert.deepEqual(await run(app), { uid: 'uid-1', reusedSignIn: false });
  assert.deepEqual(app.records.get('users/uid-1'), {
    name: 'New Person', email: 'new.person@example.com', initials: 'NP',
    role: 'member', marker: 'teal', branchIds: ['b2'], outToday: false, outDate: null,
  });
  const [properties] = app.calls.created;
  assert.equal(properties.email, 'new.person@example.com');
  assert.equal(properties.displayName, 'New Person');
  assert.ok(properties.password.length >= 32, 'a random starter password nobody is told');
});

test('only an active admin or manager can add people, and nothing is created otherwise', async () => {
  for (const [callerUid, code] of [
    [undefined, 'unauthenticated'],
    ['not-on-roster', 'permission-denied'],
    ['member-1', 'permission-denied'],
    ['inactive-admin', 'permission-denied'],
    ['inactive-manager', 'permission-denied'],
  ]) {
    const app = fakes({ records: {
      'users/inactive-admin': { email: 'old@example.com', role: 'admin', active: false, branchIds: ['b1'] },
      'users/inactive-manager': { email: 'former@example.com', role: 'manager', active: false, branchIds: ['b2'] },
      'users/member-1': { email: 'member@example.com', role: 'member', branchIds: ['b2'] },
    } });
    await assert.rejects(run(app, { callerUid }), codeIs(code), String(callerUid));
    assert.equal(app.calls.created.length, 0);
    assert.equal(app.records.size, 7);
  }
});

test('a manager adds people to their own branches only, and never an admin', async () => {
  const manager = { callerUid: 'manager-1' };
  const app = fakes();
  assert.deepEqual(await run(app, manager), { uid: 'uid-1', reusedSignIn: false });
  assert.deepEqual(app.records.get('users/uid-1').branchIds, ['b2']);

  const asManagerRole = fakes();
  await run(asManagerRole, { ...manager, data: { ...newPerson, role: 'manager' } });
  assert.equal(asManagerRole.records.get('users/uid-1').role, 'manager');

  for (const [data, pattern] of [
    [{ ...newPerson, role: 'admin' }, /Only an admin can add an admin/],
    [{ ...newPerson, branchIds: ['b1'] }, /your own branches/],
    [{ ...newPerson, branchIds: ['b2', 'b1'] }, /your own branches/],
  ]) {
    const denied = fakes();
    await assert.rejects(run(denied, { ...manager, data }), codeIs('permission-denied'));
    assert.equal(denied.calls.created.length, 0);
  }
});

test('new person details are validated before any sign-in is created', async () => {
  for (const [data, pattern] of [
    [null, /object/],
    [{ ...newPerson, name: ' ' }, /Name is required/],
    [{ ...newPerson, email: 'not-an-email' }, /complete email/],
    [{ ...newPerson, initials: 'TOOLONG' }, /Initials must be 4/],
    [{ ...newPerson, role: 'owner' }, /valid role/],
    [{ ...newPerson, marker: 'pink' }, /valid marker/],
    [{ ...newPerson, branchIds: [] }, /at least one branch/],
    [{ ...newPerson, branchIds: ['b1/other'] }, /valid branches/],
    [{ ...newPerson, branchIds: ['b9'] }, /no longer exists/],
  ]) {
    const app = fakes();
    await assert.rejects(run(app, { data }), (error) => codeIs('invalid-argument')(error) && pattern.test(error.message));
    assert.equal(app.calls.created.length, 0);
  }
});

test('an email already on the roster is refused without touching Auth', async () => {
  const app = fakes({ records: {
    'users/existing': { email: 'new.person@example.com', role: 'member', branchIds: ['b2'] },
  } });
  await assert.rejects(run(app), codeIs('already-exists'));
  assert.equal(app.calls.created.length, 0);

  const takenUid = fakes({ authUsers: { 'new.person@example.com': 'admin-1' } });
  await assert.rejects(run(takenUid), codeIs('already-exists'));
  assert.deepEqual(takenUid.calls.deleted, [], 'a reused sign-in is never deleted');
  assert.equal(takenUid.records.get('users/admin-1').email, 'admin@example.com');
});

test('a console-created sign-in without a roster entry is reused, not replaced', async () => {
  const app = fakes({ authUsers: { 'new.person@example.com': 'console-uid' } });
  assert.deepEqual(await run(app), { uid: 'console-uid', reusedSignIn: true });
  assert.equal(app.records.get('users/console-uid').email, 'new.person@example.com');
  assert.deepEqual(app.calls.deleted, []);
});

const memberRecord = { 'users/member-1': { email: 'member@example.com', role: 'member', branchIds: ['b2'] } };
const remove = (app, options = {}) => deleteBoardUser({
  db: app.db, auth: app.auth, callerUid: 'admin-1', data: { uid: 'member-1' }, ...options,
});

test('an admin removes the sign-in and the roster record together', async () => {
  const app = fakes({ records: memberRecord, authUsers: { 'member@example.com': 'member-1' } });
  assert.deepEqual(await remove(app), { uid: 'member-1', signInDeleted: true });
  assert.equal(app.records.has('users/member-1'), false);
  assert.deepEqual(app.calls.deleted, ['member-1']);

  // A roster record whose sign-in is already gone still comes off.
  const orphan = fakes({ records: memberRecord });
  assert.deepEqual(await remove(orphan), { uid: 'member-1', signInDeleted: false });
  assert.equal(orphan.records.has('users/member-1'), false);
});

test('removal is refused for managers, for yourself, and for people not on the roster', async () => {
  for (const [options, code] of [
    [{ callerUid: undefined }, 'unauthenticated'],
    [{ callerUid: 'manager-1' }, 'permission-denied'],
    [{ callerUid: 'member-1' }, 'permission-denied'],
    [{ data: { uid: 'admin-1' } }, 'failed-precondition'],
    [{ data: { uid: 'not-a-person' } }, 'failed-precondition'],
    [{ data: {} }, 'invalid-argument'],
  ]) {
    const app = fakes({ records: memberRecord, authUsers: { 'member@example.com': 'member-1' } });
    await assert.rejects(remove(app, options), codeIs(code), JSON.stringify(options));
    assert.equal(app.records.has('users/member-1'), true, 'a refused removal changes nothing');
    assert.deepEqual(app.calls.deleted, []);
  }
});

test('a failed roster write removes only a sign-in this request created', async () => {
  const created = fakes({ failRosterWrite: true });
  await assert.rejects(run(created), /firestore unavailable/);
  assert.deepEqual(created.calls.deleted, ['uid-1']);
  assert.equal(created.accounts.size, 0);

  const reused = fakes({ failRosterWrite: true, authUsers: { 'new.person@example.com': 'console-uid' } });
  await assert.rejects(run(reused), /firestore unavailable/);
  assert.deepEqual(reused.calls.deleted, []);
  assert.equal(reused.accounts.get('new.person@example.com'), 'console-uid');
});
