# BranchSuite

Two shared boards for a staffing branch, in one app.

**Day board** is the team to-do list. Client email that needs action lands on it
automatically and anyone can clear a card. Every task is stamped with an
`America/Chicago` day. At midnight Central the active board advances and keeps
all unfinished tasks from earlier days, with their original date, owner, and
email links. Tasks cleared today remain in today’s Cleared tray. Earlier days
retain their original tasks and tasks completed on that date; these are dated
records, not historical snapshots of every intervening day. There is no close-out
button, snapshot step, or bulk deletion. Managers assigned to more than one
branch get an aggregate view with a branch label on every task. Any team member
can claim an unassigned task in one click, and opening an email task loads the
retained request text without adding that text to the live board query.

Queue view groups active work into **Client Communication**, **Associate
Management**, and **Branch Operations** columns. Tasks start with an automatic
category inferred from their title, email subject, detail, and order metadata.
On today's board, any active branch member can drag an open task's title into
another column. The saved category survives refreshes, carryover, and email
replies without changing ownership, priority, or completion. The task drawer's
Category selector supports keyboard/mobile changes and restoring Automatic.
Completed tasks and historical boards cannot be recategorized. Cleared work
remains available through its filter and a compact tray.

Wall view is a room display with the same three categories, a slim branch/date
bar, and no app navigation, metric band, search, or editing toolbar. Large task
titles, owner names/colors, ages, and HOT markers use the reclaimed space.
On wide displays, each category automatically uses two tasks per row when its
one-card rows would exceed the available screen height. Lighter columns stay
wide; density recalculates as tasks arrive, finish, or the display resizes.
Narrow two-card rows use owner initials and a shorter age label; full names
and elapsed times remain available in accessible labels and task details.
Wall always shows all open work for the selected branches and day, priority
first; Queue's search, filters, and sort are restored when returning to Queue.
The branch selector, fullscreen toggle, and Back to Queue stay accessible.
Saved days are labeled and include a Return to today action. Full context and
actions stay in the task drawer.

**Job orders** replaces the job order whiteboard. Orders now link to the same
parent accounts and locations/departments used for email routing. An opening is
still a line and initials on a line still mean the slot is spoken for, but the
board can now sort by need, tell a committed candidate from one who actually
started, and surface a start date before the morning it happens.

Both boards share the same users, branches, accounts, and marker colors.
Production is served by Firebase Hosting at
[`suite.ebtools.pro`](https://suite.ebtools.pro).

## Run it

```bash
nvm use
npm install
npm run dev
```

That works on a fresh clone with no Firebase project. The app falls back to
local mode: state goes to `localStorage`, and instead of signing in you pick a
person from a list. Good enough to click through the UI, not shared between
machines.

## How the email side works

```
one configured branch mailbox
       |
Power Automate  (sends the mailbox address and a stable message ID)
       |
POST /ingestEmail --> mailbox guard --> idempotency gate --> task + email detail
                                                        \-> optional job order
```

Account routing is deterministic. Exact configured contacts can select a parent
account and location/department; aliases in the message can narrow that match;
and a customer domain can identify only the parent account. Ambiguous matches
stay visibly marked for manager review rather than letting the model guess.
OpenAI decides whether the message needs action, writes the title, summary, and
priority, and extracts a narrowly validated staffing request. When the email
states one exact headcount and the account/location route is unambiguous, the
same transaction creates a linked job order with that many blank openings. A
range, vague count, multi-role request, or unresolved route stays on the task as
a reviewable staffing draft and does not create an order by guessing.

Assignment and the order's owner badge inherit from the selected sub-account or
parent account owner only when that person is active in the branch. If no one
owns the account, the order is explicitly unowned and every opening remains
blank; account ownership is never copied into a candidate slot.

The function rejects a request unless `branchId` and `mailboxAddress` match the
branch's configured mailbox list. Exact Power Automate retries replay the first result instead of classifying or
writing again. A new message on an existing conversation updates its single
open task, including work carried from a prior day. It retains the message,
refreshes the task context, and escalates priority for deadlines or unanswered
client requests. The original date, owner, account, and linked order are preserved.
Completed same-day tasks retain new context without being automatically reopened.
When no open task remains, that conversation can become new work on a later day. Reusing a `messageId` with different message content is treated as
a configuration error and returns HTTP 409 instead of replaying a mismatched
result.

The `handleReply` endpoint can complete the single open task matching a team
reply’s branch and conversation, including unfinished work from earlier days.
It checks the original request and reply for resolution; acknowledgements and
partial updates leave the task open. A closed task appears under **Cleared**
with **Completed by reply**, and its drawer shows the sender, time, excerpt,
and reason. It can be reopened. Stable reply IDs protect retries, including
after reopening. Multiple open tasks in a thread require manual review. Non-resolving team
replies are also retained as context; the task stays open. Completion checks
include the latest client updates so the original request cannot hide newer work.

The documented inbound flow still stops after `ingestEmail`; it does not
capture outbound team replies. Automatic completion requires a separate tested
sent-mail capture path. See [reply setup and verification](POWER-AUTOMATE.md#reply-completion-setup-and-verification).

## Data model

| Collection | Fields |
| --- | --- |
| `branches` | `name`, `code`, `mailboxAddresses[]` |
| `users` | `name`, `email`, `initials`, `role`, `branchIds[]`, `marker`, `outToday` |
| `userPreferences` | private per-user `theme`, `updatedAt` |
| `accounts` | `branchId`, `name`, `aliases[]`, `domains[]`, `ownerId`, `isPriority`, `active` |
| `accountUnits` | nested location/department records with `accountId`, optional `parentUnitId`, aliases, and owner |
| `accountContacts` | manager-only contact records with exact email and parent/unit scope |
| `tasks` | `branchId`, `boardDate`, title/summary, stable account IDs and snapshots, review candidates, assignee, priority/status, compact email metadata, optional `jobOrderRequest` and `jobOrderId` |
| `taskEmailDetails` | original sanitized request, loaded only when an authorized user opens a task |
| `taskEmailMessages` | one immutable inbound/outbound follow-up per message, loaded on demand for its task |
| `orders` | stable account/unit IDs and snapshots, nullable owner ID/initials, role/shift/schedule/rate, status, blank-or-filled `slots[]`, and email/task provenance when automated |
| `emailIngests`, `emailThreadDays`, `emailReplies` | private idempotency receipts; never read or written by the browser |

`boardDate` is a `YYYY-MM-DD` value calculated in `America/Chicago`, including
daylight-saving changes, and remains the original task date during carryover.
Task `status` is `open`, `done` (completed manually), or `reply_closed`
(completed by the reply handler). Manual completion uses `completedAt`; reply
completion uses `closedByReply.at`. Both completed states count as Cleared. Order
`status` is `active` or `paused`. A slot is
`{ id, initials, startDate, status, writtenBy }` where slot status is
`committed` or `started`.

### Roles

| Role | Can do |
| --- | --- |
| `admin` | manager capabilities, plus branches, roles, and branch access |
| `manager` | aggregate assigned branches; edit routing, owners, priority, task assignment, and job orders |
| `member` | add or claim a task, mark work complete, and fill a job order slot |

Writing an opening on the job order board is a manager action, the same as
owning an account. Filling a slot is not. Anyone in the branch can put
initials on a line, which is the whole point of the board, so `firestore.rules`
lets a member change an order's `slots` and nothing else.

Branch scoping is enforced in `firestore.rules`, not in the UI. A user only reads
documents whose `branchId` is in their own `branchIds`. A manager attached to
multiple branches starts in **All assigned branches** and can narrow to one
branch. Every aggregate task carries its branch name and code.

### Appearance

The profile menu offers **Daylight**, **Soft Slate**, and **Night**. The choice
is cached immediately on the device and, when signed in, saved to the user's
private `userPreferences` document so it follows them to another display.

### Marker colors

Each user gets a whiteboard marker color, matching what Bolingbrook already does
on the wall. The dense day board uses that color as a compact owner marker and
as the rail on each wall-view tile. On job orders, initials and the account's
left edge carry the same color. Priority and received age are also printed as
text, so the board never relies on color alone.

## Firebase setup

See [SETUP.md](SETUP.md). It is the ordered version, from creating the project
through the first working email, including turning on email sign-in and what
breaks first when a step is missed.

The short version:

```bash
firebase login
firebase use --add                    # pick or create the project
cp .env.example .env.local            # fill from the console web app config

firebase functions:secrets:set OPENAI_API_KEY
firebase functions:secrets:set BOARD_INGEST_KEY   # any long random string

cd functions && npm install && cd ..
npm run build
firebase deploy --only firestore:rules,firestore:indexes,functions,hosting

node scripts/seed.mjs --uid <auth-uid> --email you@company.com \
  --name "Your Name" --initials YN \
  --b1-mailbox plx-edwardsvilleil@prologistix.com \
  --b2-mailbox plx-bolingbrook@prologistix.com
```

The second-generation functions target Node.js 24 in both `firebase.json` and
`functions/package.json`. Use a current Firebase CLI; this repo was verified
with Firebase CLI 15.24.0. See the
[Cloud Run functions runtime schedule](https://docs.cloud.google.com/functions/docs/runtime-support).

The seed script writes the branches, optional mailbox bindings, and the first admin user document. The
user document ID has to be the Firebase Auth UID exactly, which is the reason
the script exists rather than a console instruction.

Sign in is email and password. Self sign-up is turned off. An admin, or a
manager for their own branches, adds each person from **Setup, People and
markers**; the `createBoardUser` callable
function verifies the caller is an active admin, creates the Auth sign-in and
the `users` document under the same UID, and the new person receives a
password setup email. The Setup tab also edits existing people. The Setup workspace adds and edits parent accounts, nested locations
or departments, exact-email contacts, aliases, domains, and owners. Account and
contact records are archived instead of hard-deleted so historical tasks keep
stable references. Keep a location/department path to five records or fewer
(the selected unit plus at most four ancestors); client-written orders fail
closed beyond that bound so Firestore can validate the whole path atomically.

## Power Automate

Run exactly one supervised inbound flow for each mailbox/branch pair, with its
`branchId` hard coded. Do not make two enabled copies that watch the same
mailbox: both triggers receive every message and can route it to the wrong
branch. If one mailbox serves multiple branches, build one routing flow instead
of cloning the flow.

The shape is below. [POWER-AUTOMATE.md](POWER-AUTOMATE.md) is the click by
click build, including the premium licence requirement and the HTML body
conversion that this summary leaves out.

1. **Trigger** — When a new email arrives in a shared mailbox (V2), pointed at
   that branch's Inbox.
2. **Condition, is this noise** — skip if the subject starts with
   `Automatic reply` or `Undeliverable`, or the sender is a no-reply address.
   Cheap string checks only. Anything ambiguous goes through, the model is the
   real filter.
3. **Ingest** — HTTP POST every remaining message to `ingestEmail`. Include a
   stable trigger message ID so retries are idempotent:

   ```json
   {
     "branchId": "b2",
     "mailboxAddress": "plx-bolingbrook@prologistix.com",
     "messageId": "@{if(empty(triggerOutputs()?['body/internetMessageId']), triggerOutputs()?['body/id'], triggerOutputs()?['body/internetMessageId'])}",
     "from": "@{triggerOutputs()?['body/from']}",
     "subject": "@{triggerOutputs()?['body/subject']}",
     "body": "@{body('Html_to_text')}",
     "conversationId": "@{triggerOutputs()?['body/conversationId']}",
     "webLink": "@{triggerOutputs()?['body/webLink']}",
     "receivedAt": "@{triggerOutputs()?['body/receivedDateTime']}"
   }
   ```

   `mailboxAddress` is the exact shared-mailbox SMTP address entered in the
   trigger and configured on that branch. Prefer Outlook's `internetMessageId`; fall back to the trigger's `id` only
   when it is unavailable. Never generate a fresh ID inside the flow, and never
   transform it between retry attempts.

4. **Stop after the response.** `created: true` means a task was written;
   `jobOrderCreated: true` means the same atomic write also added its order;
   `no action required` means the classifier intentionally skipped a new thread;
   `created: false`, `updated: true` means a follow-up refreshed an existing task
   and was retained in its email history. The endpoint also replays the original response
   for an exact message retry. None of those cases should call `handleReply`.
   HTTP 409 with `messageId was already used for different message content`
   means the flow reused an ID while changing its payload; fail the run and fix
   the mapping rather than generating a replacement ID.

The HTTP request needs the header `x-board-key` set to `BOARD_INGEST_KEY`. Store
it in a solution environment variable, not inline in the flow.

The generic HTTP action is a premium connector, so the POST needs a Power
Automate Premium or Process licence. The standard `Send an HTTP request to`
actions only reach Microsoft 365 endpoints and cannot call the function.

Use `body` rather than `bodyPreview`. The preview truncates around 255
characters. The function strips quoted history before the model sees it.

## Storage

`src/lib/store.js` is the seam between the UI and the backend, with Firebase
and local-storage adapters behind one `useBoard` hook.

With Firebase configured, both boards read Firestore live through `onSnapshot`
and write per document. Without it they fall back to localStorage against the
`SEED` constants, so `npm run dev` still works on a fresh clone with no
project.

The day board subscribes only to the selected Central date and uses narrow
document helpers for task creates, claims, patches, and bulk reassignment. Account,
sub-account, and contact records use archival instead of destructive deletion.
Those operations send only fields that actually changed, so a stale screen
cannot replace an entire task with an older copy. All board writes use
document-scoped helpers. Job-order slot edits re-read the order in a transaction
before calculating the new slot array, so a stale screen cannot replace another
person's simultaneous update. The manager fallback in an expanded staffing task
also creates its deterministic order and links the task in one transaction.

This also keeps the Firestore rules satisfiable. A member may update a task's
allowed status fields and nothing else, and the rule checks the affected keys.

Local-preview limitations:

1. **One roster, not two.** In Firestore there is a single `users` collection,
   and the job order board reads it through a `people` alias. The two `SEED`
   rosters are still separate, so local mode shows different people on each
   board. Candidate lines use initials; linked account owners use user IDs.
2. **Preview data still ships.** The `SEED` constants at the top of each component
   are fictional click-through data. None is used once Firebase is configured.
3. **The fictional datasets remain separate.** A converted task order crosses
   the local tab boundary through a small local order inbox, so it appears in
   Job orders just as it does with Firestore. The unrelated sample rosters and
   historical orders are still intentionally independent.

## Pilot

Run one mailbox/branch first, with one supervised flow and reply handling off.
Send uniquely tagged actionable and non-actionable messages, then retry the
same trigger payload and verify that it never creates a second task. Check the
board immediately before and after midnight Central to confirm the active date
advances while the prior day's records remain available. Add another branch
only after its mailbox and `branchId` mapping are unambiguous.

Personal Mode adds owner-only email tasks, Branch / Personal / Combined views,
and guided Outlook flow setup. See [Personal Mode setup and readiness](docs/personal-mode.md).
The starter import package still needs validation in the target Power Automate tenant.
