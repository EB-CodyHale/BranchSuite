# Account preload

`scripts/import-accounts.mjs` loads reviewed JSON with Application Default Credentials. It defaults to a dry run. Keep source exports, reviewed JSON, inventories and audit output outside Git.

```sh
node scripts/import-accounts.mjs --project branchsuite --input /private/path/reviewed.json --admin-id AUTH_UID
node scripts/import-accounts.mjs --project branchsuite --input /private/path/reviewed.json --admin-id AUTH_UID --apply
```

Input shape (identifiers must be strings):

```json
{
  "branches": [{"code": "30088", "name": "St. Louis, MO"}],
  "accounts": [{
    "branchCode": "30088",
    "name": "Example Customer",
    "accountNumber": "001234",
    "sourceAccountId": "crm-record-id",
    "sourceBranchName": "St. Louis, MO - PLX"
  }]
}
```

Map source branch labels to the reviewed branch numbers explicitly. An optional `parentAccountId` imports a location under an existing active parent in that branch. Use optional `existingId` only for a reviewed match to an existing account or location; otherwise identity, account number, and exact name/alias matches are checked automatically. Ambiguous matches and conflicting identities fail the entire plan. Distinct source records are never merged just because company names resemble one another.

New branches use `branch-NUMBER`; existing branch IDs are retained. Creating a branch also adds the specified existing admin to its memberships. New accounts are active, have no owner, no email domains and normal priority. Source supervisor labels and national-account flags do not automatically become board assignments or priority settings. Existing names, ownership, archived state, routing and priorities are preserved. Source numbers and branch labels remain on account/location records. The workbook itself is not changed.

Application writes use one atomic batch with create/update preconditions. Repeating an unchanged import produces no writes. Run the dry run again after applying to confirm this. This importer deliberately supports at most 450 writes per run.

Admins can also create branches directly from **Day Board → Board setup → Branches** and grant team memberships from **People and access**. Branch creation grants the creating admin access; mailbox ingestion is configured separately.
