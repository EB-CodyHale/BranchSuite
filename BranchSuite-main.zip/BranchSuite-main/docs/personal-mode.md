# Personal Mode

Personal Mode adds private tasks from a user's work Outlook inbox. The header dropdown offers Branch, Personal,
and Combined in Queue and Wall. Personal settings live in Settings → Personal. Combined changes only the
signed-in user's view; personal tasks and their email contents are not shared with
branch coworkers, managers, or other admins through the application.

## Current readiness

Deployed to Firebase project `branchsuite` on September 18, 2026: personal
ingestion, per-user keys, Firestore access rules, view preferences, the header
dropdown, Settings → Personal, and the corrected Power Automate import package.
The site is available at https://suite.ebtools.pro and https://branchsuite.web.app.
Deployment does not connect a mailbox or enable a Power Automate flow. The
package's structure and references are checked locally; **successful import and
execution in an actual Power Automate tenant are not yet verified**. The reported
Compose security-setting import error has been corrected.

The first release handles incoming messages and follow-ups. Completion is manual;
it does not monitor Sent Items, auto-close tasks from replies, or create shared
job orders from private email. It uses the existing email normalization, body
sanitization, classification validation, and GPT-5.6 Luna (`gpt-5.6-luna`) with
`reasoning_effort: none` and JSON output. Original request context is
retained while later messages are stored separately and can raise urgency.

## No BranchSuite Entra app registration

Users import a non-solution flow package and select their own existing or new
Office 365 Outlook connection in Power Automate. BranchSuite does not acquire
Microsoft OAuth tokens, need an Azure subscription, or register an Entra app.
Microsoft's Outlook connection still uses the user's work sign-in and is subject
to their organization's consent, connector, environment, and data policies.

Microsoft documents that package import requires Environment Maker access:
[Import a non-solution flow](https://learn.microsoft.com/en-us/power-automate/export-import-flow-non-solution).
The generic HTTP action requires suitable Power Automate premium entitlement;
Microsoft 365 alone should not be assumed sufficient. See
[Power Automate licensing](https://learn.microsoft.com/en-us/power-platform/admin/power-automate-licensing/faqs).
This is guided import, not a silent one-click flow installation.

## Deployment

After local review, deploy the rules and new functions before the frontend:

```sh
firebase deploy --only firestore:rules,functions:managePersonalEmail,functions:ingestPersonalEmail
npm run build
firebase deploy --only hosting
```

The functions use the existing `OPENAI_API_KEY` secret and default `us-central1`
region. No shared branch ingestion key is exposed to personal users. The Settings
endpoint is derived from the configured Firebase project. No extra indexes are
needed: personal tasks are queried within each user's collection by board date,
completion time, and open status.

## User setup

1. Open Day board → Settings → Personal → Connect personal email. This generates a
   revocable personal key for the work email on the signed-in user's roster record;
   it does not authenticate to Outlook. The UI says Waiting for first email.
2. Download `public/power-automate/BranchSuite-Personal-Mode.zip` using the Settings
   button. In Power Automate choose My flows → Import → Import Package (Legacy).
   Select Create as new and bind Office 365 Outlook to **your own** work account.
3. Keep the imported flow off. Edit its three Compose actions: BranchSuite endpoint,
   Mailbox address, and Personal key. Copy their values from Settings. A replacement
   key immediately invalidates the previous one and must be pasted into the flow.
4. Keep **Secure Inputs** enabled for the Personal key Compose action. Compose does
   not support a separate Secure Outputs setting; Secure Inputs also hides its
   output in run history. Keep both **Secure Inputs** and **Secure Outputs** enabled
   for the Send to BranchSuite HTTP action. The trigger also protects its captured
   content. Review the Inbox trigger, then
   save and enable the flow when ready to process mail. The shipped package contains
   placeholders, a stopped-state setting, and a guard that skips HTTP until configured.
   Confirm the imported flow is off regardless of the importer’s state handling.
5. After the next incoming email, confirm a successful run and Email received in
   BranchSuite. Informational email can produce a successful run with no task.
   Confirm an actionable email creates a private task and a repeated delivery does
   not duplicate it. Then confirm the separate Personal and Combined views.
6. Disconnect in Settings revokes intake immediately and keeps existing tasks.
   Also turn off the flow in Power Automate to stop failed delivery attempts.

The template reads only new Inbox email, without attachment content or historical
backfill. Full email body HTML is delivered and normalized to text server-side;
`bodyPreview` is intentionally not used. Email bodies are sent to the configured
AI provider for classification. Outlook may skip protected or oversized email;
see [Office 365 Outlook connector](https://learn.microsoft.com/en-us/connectors/office365/).
An email copied to both a shared mailbox and a personal mailbox remains separate
work in each privacy scope; there is no automatic publishing or cross-scope dedupe.

## Storage and authorization

- `personalBoards/{uid}`: owner-readable connection status, server-written only.
- `personalBoards/{uid}/preferences/view`: owner-only source-view preference.
- `personalBoards/{uid}/tasks/{id}`: server-created private tasks; owner can complete,
  reopen, and categorize them. Task identity, scope, and ownership are immutable.
- `personalBoards/{uid}/details/{id}` and `tasks/{id}/messages/{messageId}`: private
  original message and follow-ups; only the owner can read them.
- `personalBoards/{uid}/receipts` and `/threads`: server-only delivery/thread records.
- `personalIngestCredentials/{uid}`: server-only SHA-256 digest of a random 256-bit
  key, mailbox address, and revocation state. No plaintext key is stored in Firestore.

The intake key identifies the owner; request-supplied user or branch IDs cannot
redirect writes. The roster account must still exist and be active, with the same
email address. Credential and roster checks run again in the write transaction
so key replacement, disconnection, or deactivation during AI classification stops
pending writes. Repeated message IDs replay receipts; changed content conflicts.
Open threads carry forward; same-day completed tasks are never automatically
reopened. Shared team bulk actions never include private work.

## Maintaining the package

```sh
python3 scripts/build-personal-flow.py
```

The builder regenerates both reviewable JSON under
`integrations/power-automate/personal-mode/` and the downloadable ZIP. It contains
no deployment URL, mailbox address, or credential. Package layout follows the
[Microsoft OfficeDev sample exports](https://github.com/OfficeDev/Microsoft-Teams-Shifts-Power-Automate-Templates/tree/master/templates/AutoApproveRequests/AutoApproveOpenShiftRequestwithEmailNotification).
After a successful tenant import, re-export the working flow as Create as new with
placeholders restored and the flow off to establish a tenant-validated baseline.

If a tenant rejects the generated import, the equivalent flow has only an Office
365 Outlook “When a new email arrives (V3)” trigger, three Compose configuration
actions, a configuration guard, and one generic HTTP POST. The reviewable JSON
contains the exact field mappings. Do not label onboarding complete until an
actual imported flow successfully delivers mail.

## Validation

```sh
npm --prefix functions test
node --test src/lib/*.test.js scripts/lib/*.test.mjs
npm run build
git diff --check
```

With an isolated Firestore emulator running on port 8189 for project
`demo-personal-mode` and loading `firestore.rules`:

```sh
FIRESTORE_EMULATOR_HOST=127.0.0.1:8189 node scripts/test-personal-rules.mjs
```

The rules test refuses non-loopback hosts. It exercises owner, other-user/admin,
unauthenticated, disabled-user, credential, email-detail, preference, immutable
identity, completion, and reopening access. Browser QA uses local preview data,
not live mail or Microsoft credentials.
