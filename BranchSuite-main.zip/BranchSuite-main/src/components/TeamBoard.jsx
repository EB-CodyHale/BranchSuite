import { usePersonalBoard } from '../lib/usePersonalBoard';
import { PERSONAL_BRANCH, selectBoardTasks } from '../lib/personalMode';
import PersonalSettings from './PersonalSettings';
import React, { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  AlertTriangle, ArrowLeft, ArrowRight, Briefcase, Building2, Check, ChevronDown,
  ChevronRight, Circle, Columns3, ExternalLink, LayoutList, Maximize2, Minimize2, Plus,
  RefreshCw, Search, Settings, Star, Users, X,
} from 'lucide-react';
import { useBoard } from '../lib/store';
import { isConfigured } from '../lib/firebaseApp';
import { createBoardUser, createBoardUserMessage, deleteBoardUser } from '../lib/boardUsers';
import {
  CENTRAL_TIME_ZONE, centralDateKey, formatCentralDate, formatCentralTime, shiftDateKey,
} from '../lib/centralTime';
import { classifyTaskCategory, planTaskCategoryChange, TASK_CATEGORY_IDS } from '../lib/taskCategory';
import { dateForTask, isTaskComplete, isTaskOnBoard } from '../lib/taskLifecycle';

const STORE_KEY = 'day-board-v5';
const ALL_BRANCHES = 'all';
const EMPTY_MAP = new Map();
const MAX_ACTIVE_UNIT_PATH_RECORDS = 5;

const MARKERS = {
  none: { label: 'Slate', color: '#8798a5' },
  blue: { label: 'Blue', color: '#4ca3ef' },
  green: { label: 'Green', color: '#43c58a' },
  red: { label: 'Red', color: '#ff6266' },
  purple: { label: 'Purple', color: '#a987ed' },
  orange: { label: 'Orange', color: '#ffad52' },
  teal: { label: 'Teal', color: '#40c7c0' },
};

const PRIORITIES = {
  high: { label: 'Hot', className: 'is-hot' },
  normal: { label: 'Normal', className: 'is-normal' },
  low: { label: 'Low', className: 'is-low' },
};

const TASK_CATEGORIES = [
  {
    id: TASK_CATEGORY_IDS.CLIENT_COMMUNICATION,
    label: 'Client Communication',
    description: 'Acknowledgments, answers, and client updates',
  },
  {
    id: TASK_CATEGORY_IDS.ASSOCIATE_MANAGEMENT,
    label: 'Associate Management',
    description: 'Attendance, coaching, and associate support',
  },
  {
    id: TASK_CATEGORY_IDS.BRANCH_OPERATIONS,
    label: 'Branch Operations',
    description: 'Orders, payroll, audits, and internal work',
  },
];

const ROLES = { admin: 'Admin', manager: 'Manager', member: 'Member' };

function normalizeEmail(value) {
  return String(value || '').trim().toLocaleLowerCase();
}

/** Bare address from `Name <address>` or a plain address. */
function emailAddressOf(value) {
  const match = String(value || '').trim().match(/<([^<>]+)>\s*$/);
  return normalizeEmail(match ? match[1] : value);
}

function recipientLabels(addresses, rosterByEmail) {
  if (!Array.isArray(addresses)) return null;
  return addresses.map((address) => {
    const person = rosterByEmail.get(normalizeEmail(address));
    return person ? `${person.name} <${address}>` : address;
  }).join(', ');
}

function normalizeDomain(value) {
  return String(value || '').trim().toLocaleLowerCase().replace(/^@/, '');
}

function parseList(value, normalizer = (item) => item.trim()) {
  return [...new Set(String(value || '').split(',').map((item) => normalizer(item)).filter(Boolean))];
}

function accountLabel(task, accountById, unitById) {
  const accountName = task.accountName || accountById.get(task.accountId)?.name || task.account || null;
  const unitName = task.accountUnitName || unitById.get(task.accountUnitId)?.name || null;
  if (accountName && unitName && !String(accountName).includes(unitName)) return `${accountName} · ${unitName}`;
  return accountName || unitName || 'No account';
}

function inheritedAccountOwnerId(account, unit, unitById = EMPTY_MAP) {
  const visited = new Set();
  let current = unit;
  while (current?.id && !visited.has(current.id)) {
    visited.add(current.id);
    if (current.ownerId) return current.ownerId;
    if (!current.parentUnitId) break;
    const parent = unitById.get(current.parentUnitId);
    if (!parent || parent.accountId !== account?.id) break;
    current = parent;
  }
  return account?.ownerId || null;
}

function activeUnitPath(unit, unitById = EMPTY_MAP) {
  if (!unit?.id) return false;
  const visited = new Set();
  const { accountId, branchId } = unit;
  let current = unit;
  let records = 0;

  while (current?.id) {
    if (visited.has(current.id)
      || current.active === false
      || current.accountId !== accountId
      || current.branchId !== branchId) return false;
    visited.add(current.id);
    records += 1;
    if (!current.parentUnitId) return true;
    if (records >= MAX_ACTIVE_UNIT_PATH_RECORDS) return false;
    current = unitById.get(current.parentUnitId);
  }
  return false;
}

function safeCentralTime(value, fallback = 'Unknown', options = {}) {
  if (value === null || value === undefined || value === '') return fallback;
  try { return formatCentralTime(value, options); } catch { return fallback; }
}

function safeExternalUrl(value) {
  try {
    const url = new URL(String(value || ''));
    return url.protocol === 'https:' || url.protocol === 'http:' ? url.href : null;
  } catch { return null; }
}

function makeId() {
  return globalThis.crypto?.randomUUID?.()
    || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

const seedNow = Date.now();
const minutesAgo = (minutes) => seedNow - (minutes * 60_000);
const seedDate = centralDateKey(seedNow);

const DEMO_TASKS = [
  ['Second shift short 4 pickers Thursday', 'Northstar Logistics', 'u2', 'high', 326, 'email'],
  ['Badge reconciliation mismatch, 6 records', 'Harbor Distribution', 'u3', 'high', 243, 'email'],
  ['Orientation sign-offs missing for 3 starts', 'Summit Manufacturing', null, 'normal', 197, 'email'],
  ['Client asking for updated headcount before 2 PM', 'Northstar Logistics', 'u2', 'normal', 151, 'email'],
  ['Confirm weekend headcount for sort aisle', 'Atlas Fulfillment', 'u4', 'high', 132, 'manual'],
  ['Timecard exceptions need approval', 'Harbor Distribution', 'u3', 'normal', 119, 'email'],
  ['Reschedule the safety walk to Wednesday', 'Summit Manufacturing', 'u4', 'normal', 104, 'email'],
  ['New req opened for 8 material handlers', 'Northstar Logistics', null, 'high', 89, 'email'],
  ['Reprint badges for 4 new starts', 'Atlas Fulfillment', 'u5', 'low', 73, 'manual'],
  ['Update arrival instructions for first shift', 'Prairie Foods', 'u5', 'normal', 62, 'email'],
  ['Confirm forklift certification list', 'Harbor Distribution', 'u3', 'normal', 49, 'email'],
  ['Send corrected invoice detail to AP', 'Summit Manufacturing', 'u4', 'normal', 36, 'email'],
  ['Coverage plan sent to client', 'Northstar Logistics', 'u2', 'normal', 25, 'email', 'done'],
  ['New-start roster shared with security', 'Atlas Fulfillment', 'u5', 'normal', 18, 'manual', 'done'],
];

const DEMO_B2_TASKS = [
  {
    id: 'demo-b2-geodis-plainfield', branchId: 'b2', boardDate: seedDate,
    title: 'Confirm tonight’s Plainfield shipping headcount', account: 'GEODIS',
    accountId: 'a6', accountName: 'GEODIS', accountUnitId: 'au1', accountUnitName: 'Plainfield shipping',
    needsAccountReview: false, accountCandidateIds: ['a6'], accountUnitCandidateIds: ['au1'],
    detail: 'The client needs a confirmed headcount and arrival list before the second-shift check-in.',
    assigneeId: 'u6', priority: 'high', status: 'open', source: 'email',
    sourceEmail: {
      from: 'alex.morgan@geodis.com', subject: 'Plainfield second shift coverage',
      conversationId: 'demo-b2-conversation-1', messageId: 'demo-b2-message-1',
      receivedAt: minutesAgo(44), hasDetails: true, webLink: null,
    },
    createdAt: minutesAgo(44), updatedAt: minutesAgo(41), completedAt: null,
  },
  {
    id: 'demo-b2-geodis-review', branchId: 'b2', boardDate: seedDate,
    title: 'Review GEODIS weekend staffing request', account: 'GEODIS',
    accountId: 'a6', accountName: 'GEODIS', accountUnitId: null, accountUnitName: null,
    needsAccountReview: true, accountCandidateIds: ['a6'], accountUnitCandidateIds: ['au1', 'au2'],
    jobOrderId: null,
    jobOrderRequest: {
      headcount: 6, role: 'Warehouse associate', shift: 'Weekend',
      days: 'Saturday-Sunday', hours: null, pay: null,
    },
    detail: 'The sender supports multiple GEODIS operations and did not identify a location clearly.',
    assigneeId: null, priority: 'normal', status: 'open', source: 'email',
    sourceEmail: {
      from: 'regional.operations@geodis.com', subject: 'Weekend additions',
      conversationId: 'demo-b2-conversation-2', messageId: 'demo-b2-message-2',
      receivedAt: minutesAgo(31), hasDetails: true, webLink: null,
    },
    createdAt: minutesAgo(31), updatedAt: minutesAgo(29), completedAt: null,
  },
  {
    id: 'demo-b2-weathertech', branchId: 'b2', boardDate: seedDate,
    title: 'Post the WeatherTech machine-operator opening', account: 'WeatherTech',
    accountId: 'a7', accountName: 'WeatherTech', accountUnitId: 'au3', accountUnitName: 'Machine operators',
    needsAccountReview: false, accountCandidateIds: [], accountUnitCandidateIds: [],
    detail: 'Second shift needs three operators. Confirm the start window with the account before posting.',
    assigneeId: 'u7', priority: 'normal', status: 'open', source: 'manual', sourceEmail: null,
    createdAt: minutesAgo(22), updatedAt: minutesAgo(22), completedAt: null,
  },
  {
    id: 'demo-b2-former-owner', branchId: 'b2', boardDate: seedDate,
    title: 'Recover ownership of the badge audit', account: 'GEODIS',
    accountId: 'a6', accountName: 'GEODIS', accountUnitId: 'au2', accountUnitName: 'Bolingbrook receiving',
    needsAccountReview: false, accountCandidateIds: [], accountUnitCandidateIds: [],
    detail: 'This sample intentionally points to a former roster owner so the recovery lane can be tested.',
    assigneeId: 'former-user', priority: 'low', status: 'open', source: 'manual', sourceEmail: null,
    createdAt: minutesAgo(15), updatedAt: minutesAgo(15), completedAt: null,
  },
];

const DEMO_EMAIL_DETAILS = [
  {
    id: 'demo-b2-geodis-plainfield', taskId: 'demo-b2-geodis-plainfield', branchId: 'b2',
    from: 'alex.morgan@geodis.com', to: ['bolingbrook.board@example.com'], cc: [],
    subject: 'Plainfield second shift coverage', receivedAt: minutesAgo(44),
    bodyText: 'Team,\n\nPlease confirm that all 12 associates are covered for tonight in Plainfield and send the arrival list before 2:30 PM. We are still short four names on the copy I received.\n\nThank you,\nAlex',
    isTruncated: false, originalLength: 213,
  },
  {
    id: 'demo-b2-geodis-review', taskId: 'demo-b2-geodis-review', branchId: 'b2',
    from: 'regional.operations@geodis.com', subject: 'Weekend additions', receivedAt: minutesAgo(31),
    bodyText: 'Can you add six people for the weekend launch and let me know who is confirmed? Please use the usual Saturday start time. I support both local operations, so call if the location is not clear from the thread.',
    isTruncated: false, originalLength: 198,
  },
];

const SEED = {
  branches: [
    { id: 'b1', name: 'Granite City', code: '30080' },
    { id: 'b2', name: 'Bolingbrook', code: '20062' },
  ],
  users: [
    { id: 'u1', name: 'Cody Hale', email: 'cody@example.com', initials: 'CH', role: 'admin', branchIds: ['b1', 'b2'], marker: 'blue', outToday: false },
    { id: 'u2', name: 'Jae', email: 'jae@example.com', initials: 'JA', role: 'manager', branchIds: ['b1'], marker: 'purple', outToday: false },
    { id: 'u3', name: 'Greg', email: 'greg@example.com', initials: 'GR', role: 'member', branchIds: ['b1'], marker: 'green', outToday: false },
    { id: 'u4', name: 'Ronda', email: 'ronda@example.com', initials: 'RO', role: 'member', branchIds: ['b1'], marker: 'orange', outToday: false },
    { id: 'u5', name: 'Shantez', email: 'shantez@example.com', initials: 'SH', role: 'manager', branchIds: ['b1', 'b2'], marker: 'red', outToday: false },
    { id: 'u6', name: 'Luz', email: 'luz@example.com', initials: 'LZ', role: 'member', branchIds: ['b2'], marker: 'teal', outToday: false },
    { id: 'u7', name: 'J. G.', email: 'jg@example.com', initials: 'JG', role: 'member', branchIds: ['b2'], marker: 'orange', outToday: false },
  ],
  accounts: [
    { id: 'a1', branchId: 'b1', name: 'Northstar Logistics', ownerId: 'u2', isPriority: true },
    { id: 'a2', branchId: 'b1', name: 'Harbor Distribution', ownerId: 'u3', isPriority: false },
    { id: 'a3', branchId: 'b1', name: 'Summit Manufacturing', ownerId: 'u4', isPriority: false },
    { id: 'a4', branchId: 'b1', name: 'Atlas Fulfillment', ownerId: 'u5', isPriority: true },
    { id: 'a5', branchId: 'b1', name: 'Prairie Foods', ownerId: null, isPriority: false },
    { id: 'a6', branchId: 'b2', name: 'GEODIS', aliases: ['Geodis operations'], domains: ['geodis.com'], ownerId: 'u5', isPriority: true, active: true },
    { id: 'a7', branchId: 'b2', name: 'WeatherTech', aliases: ['Weather Tech'], domains: ['weathertech.com'], ownerId: 'u7', isPriority: false, active: true },
  ],
  accountUnits: [
    { id: 'au1', branchId: 'b2', accountId: 'a6', name: 'Plainfield shipping', aliases: ['Plainfield', 'shipping'], ownerId: 'u6', parentUnitId: null, active: true },
    { id: 'au2', branchId: 'b2', accountId: 'a6', name: 'Bolingbrook receiving', aliases: ['Bolingbrook', 'receiving'], ownerId: 'u7', parentUnitId: null, active: true },
    { id: 'au3', branchId: 'b2', accountId: 'a7', name: 'Machine operators', aliases: ['machine ops'], ownerId: 'u7', parentUnitId: null, active: true },
  ],
  accountContacts: [
    { id: 'ac1', branchId: 'b2', accountId: 'a6', accountUnitIds: ['au1'], name: 'Alex Morgan', email: 'alex.morgan@geodis.com', emailLower: 'alex.morgan@geodis.com', scope: 'unit', active: true },
    { id: 'ac2', branchId: 'b2', accountId: 'a6', accountUnitIds: [], name: 'Regional Operations', email: 'regional.operations@geodis.com', emailLower: 'regional.operations@geodis.com', scope: 'account', active: true },
  ],
  taskEmailDetails: DEMO_EMAIL_DETAILS,
  taskEmailMessages: [{
    id: 'demo-b2-luz-reply', taskId: 'demo-b2-geodis-plainfield', branchId: 'b2',
    conversationId: 'demo-b2-conversation-1', messageId: 'demo-b2-message-1-reply', direction: 'inbound',
    from: 'Luz <luz@example.com>', to: ['alex.morgan@geodis.com'], cc: ['bolingbrook.board@example.com'],
    subject: 'RE: Plainfield second shift coverage', receivedAt: minutesAgo(41),
    bodyText: 'Alex, eight of the twelve are confirmed. I will send the remaining four names by 2 PM.',
    isTruncated: false, recordedAt: minutesAgo(41),
  }],
  tasks: [
    ...DEMO_TASKS.map(([title, account, assigneeId, priority, age, source, status = 'open'], index) => ({
      id: `demo-task-${String(index + 1).padStart(2, '0')}`,
      branchId: 'b1', boardDate: seedDate, title, account,
      detail: index % 3 === 0 ? 'Client-facing item. Confirm ownership and send an update before the next check-in.' : null,
      assigneeId, priority, status, source,
      sourceEmail: source === 'email' ? {
        from: `operations${index + 1}@example.com`, subject: title,
        conversationId: `demo-conversation-${index + 1}`, webLink: null,
      } : null,
      createdAt: minutesAgo(age), updatedAt: minutesAgo(Math.max(1, age - 4)),
      completedAt: status === 'done' ? minutesAgo(Math.max(1, age - 8)) : null,
    })),
    ...DEMO_B2_TASKS,
  ],
  orders: [],
};

function useCentralClock() {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const refresh = () => setNow(Date.now());
    let interval = null;
    const timeout = window.setTimeout(() => {
      refresh();
      interval = window.setInterval(refresh, 60_000);
    }, (60_000 - (Date.now() % 60_000)) + 25);
    document.addEventListener('visibilitychange', refresh);
    return () => {
      window.clearTimeout(timeout);
      if (interval) window.clearInterval(interval);
      document.removeEventListener('visibilitychange', refresh);
    };
  }, []);
  return { now, todayKey: centralDateKey(now) };
}

function isOutToday(person, todayKey) {
  return Boolean(person?.outToday && person?.outDate === todayKey);
}

function userMarker(person) {
  return MARKERS[person?.marker]?.color || MARKERS.none.color;
}

function isValidTaskOwner(person, branchId) {
  return Boolean(person && person.active !== false && (branchId === PERSONAL_BRANCH || person.branchIds?.includes(branchId)));
}

function personInitials(person) {
  if (!person) return '';
  return (String(person.initials || '').trim()
    || String(person.name || '').split(/\s+/).map((part) => part[0]).join(''))
    .slice(0, 3)
    .toLocaleUpperCase();
}

function effectivePriority(task, accounts, accountById = EMPTY_MAP) {
  if (task.priority === 'high') return 'high';
  const account = accountById.get(task.accountId)
    || accounts.find((item) => item.name === (task.accountName || task.account) && item.branchId === task.branchId);
  return account?.isPriority ? 'high' : (task.priority || 'normal');
}

function taskAge(task, now) {
  const elapsed = Math.max(0, now - Number(task.createdAt || now));
  const minutes = Math.floor(elapsed / 60_000);
  if (minutes < 1) return 'Now';
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ${minutes % 60}m`;
  return `${Math.floor(hours / 24)}d ${hours % 24}h`;
}

function jobOrderRouteForTask(task, accountById, unitById) {
  if (task?.needsAccountReview !== false || typeof task.accountId !== 'string' || !task.accountId) return null;
  const account = accountById.get(task.accountId);
  if (!account || account.branchId !== task.branchId || account.active === false || !account.name) return null;
  if (!task.accountUnitId) return { account, unit: null };
  const unit = unitById.get(task.accountUnitId);
  if (!unit
    || unit.branchId !== task.branchId
    || unit.accountId !== account.id
    || !activeUnitPath(unit, unitById)
    || !unit.name) return null;
  return { account, unit };
}

function eligibleJobOrderOwner(account, unit, unitById, roster, branchId) {
  const configuredOwnerId = inheritedAccountOwnerId(account, unit, unitById);
  if (!configuredOwnerId) return null;
  const owner = roster.find((person) => person.id === configuredOwnerId);
  const initials = typeof owner?.initials === 'string' ? owner.initials.trim().slice(0, 20) : '';
  return owner?.active !== false && owner?.branchIds?.includes(branchId) && initials
    ? { id: owner.id, initials }
    : null;
}

function buildTaskJobOrder(task, accountById, unitById, roster) {
  const route = jobOrderRouteForTask(task, accountById, unitById);
  const request = task?.jobOrderRequest;
  const headcount = request?.headcount;
  const sourceEmail = task?.sourceEmail;
  const createdAt = Number(task?.createdAt);
  if (!route
    || task.source !== 'email'
    || !sourceEmail
    || typeof sourceEmail.messageId !== 'string'
    || !sourceEmail.messageId
    || typeof sourceEmail.conversationId !== 'string'
    || !sourceEmail.conversationId
    || !Number.isInteger(headcount)
    || headcount < 1
    || headcount > 200
    || !Number.isInteger(createdAt)) return null;

  const owner = eligibleJobOrderOwner(route.account, route.unit, unitById, roster, task.branchId);
  return {
    branchId: task.branchId,
    account: route.account.name,
    site: route.unit?.name || null,
    accountId: route.account.id,
    accountName: route.account.name,
    accountUnitId: route.unit?.id || null,
    accountUnitName: route.unit?.name || null,
    role: request.role || null,
    shift: request.shift || null,
    days: request.days || null,
    hours: request.hours || null,
    rate: typeof request.pay === 'number' && Number.isFinite(request.pay) ? request.pay : null,
    ownerId: owner?.id || null,
    owner: owner?.initials || null,
    isPriority: route.account.isPriority === true,
    status: 'active',
    slots: Array.from({ length: headcount }, (_, index) => ({
      id: `opening_${String(index + 1).padStart(3, '0')}`,
      initials: null,
      startDate: null,
      status: 'committed',
    })),
    source: 'email',
    sourceTaskId: task.id,
    sourceMessageId: sourceEmail.messageId,
    sourceConversationId: sourceEmail.conversationId,
    sourceBoardDate: task.boardDate,
    createdAt,
    updatedAt: Math.max(Date.now(), createdAt),
  };
}

export default function TeamBoard({ layout, onLayoutChange, onOpenJobOrders, headerControlsTarget }) {
  const { now, todayKey } = useCentralClock();
  const previousToday = useRef(todayKey);
  const [selectedDate, setSelectedDate] = useState(todayKey);
  const [branchFilter, setBranchFilter] = useState(null);
  const [view, setView] = useState('board');
  const [adding, setAdding] = useState(false);
  const [teamOpen, setTeamOpen] = useState(false);

  useEffect(() => {
    // Queue's sticky layout switch is reachable midway down a long board.
    // Enter either layout at its first row so urgent work is visible.
    window.scrollTo(0, 0);
  }, [layout]);

  const board = useBoard(STORE_KEY, SEED, { taskDate: selectedDate, todayKey });
  const {
    db, meId, loading, err, setErr, syncing, createDoc, deleteDoc,
    updateDoc: updateRecord, bulkUpdateDocs, mutateDoc, linkTaskJobOrder, getDoc, getTaskMessages,
    pickMe, pull, createBranch,
  } = board;

  useEffect(() => {
    if (previousToday.current === todayKey) return;
    const oldToday = previousToday.current;
    previousToday.current = todayKey;
    setAdding(false);
    setSelectedDate((current) => (current === oldToday ? todayKey : current));
  }, [todayKey]);

  const personal = usePersonalBoard(meId, selectedDate, todayKey);
  const me = db?.users?.find((person) => person.id === meId) || null;
  useEffect(() => {
    if (!loading && !me && layout === 'wall') onLayoutChange('queue');
  }, [layout, loading, me, onLayoutChange]);
  const isAdmin = me?.role === 'admin';
  const canManage = me?.role === 'admin' || me?.role === 'manager';
  const myBranches = useMemo(
    () => (db?.branches || []).filter((branch) => me?.branchIds?.includes(branch.id)),
    [db?.branches, me?.branchIds],
  );

  const canAggregateBranches = canManage && myBranches.length > 1;
  const activeBranchFilter = canAggregateBranches && (branchFilter === null || branchFilter === ALL_BRANCHES)
    ? ALL_BRANCHES
    : (myBranches.some((branch) => branch.id === branchFilter) ? branchFilter : (myBranches[0]?.id || null));
  const aggregateMode = activeBranchFilter === ALL_BRANCHES;

  const visibleBranchIds = useMemo(
    () => (aggregateMode ? myBranches.map((branch) => branch.id) : (activeBranchFilter ? [activeBranchFilter] : [])),
    [activeBranchFilter, aggregateMode, myBranches],
  );
  const branchTasks = useMemo(
    () => (db?.tasks || []).filter((task) => visibleBranchIds.includes(task.branchId)),
    [db?.tasks, visibleBranchIds],
  );
  const tasks = selectBoardTasks(branchTasks, personal.tasks, personal.mode, meId);
  const personalOnly = personal.mode === 'personal';
  const displayBranches = [...myBranches, { id: PERSONAL_BRANCH, name: 'Personal · Only you', code: 'Personal' }];
  const accounts = useMemo(
    () => (db?.accounts || []).filter((account) => visibleBranchIds.includes(account.branchId)),
    [db?.accounts, visibleBranchIds],
  );
  const accountUnits = useMemo(
    () => (db?.accountUnits || []).filter((unit) => visibleBranchIds.includes(unit.branchId)),
    [db?.accountUnits, visibleBranchIds],
  );
  const roster = useMemo(
    () => (db?.users || []).filter((person) => person.id === meId || person.branchIds?.some((branchId) => visibleBranchIds.includes(branchId))),
    [db?.users, meId, visibleBranchIds],
  );

  const save = useCallback(async (work) => {
    try {
      return await work();
    } catch (error) {
      console.error(error);
      setErr('That change did not save. Refresh the board and try again.');
      return false;
    }
  }, [setErr]);

  const mutateBoardTask = useCallback((id, change) => id.startsWith('personal_')
    ? personal.mutateTask(id, change) : mutateDoc('tasks', id, change), [mutateDoc, personal.mutateTask]);

  const patchTask = useCallback((id, fields) => save(() => mutateBoardTask(id, (fresh) => ({
    ...fresh,
    ...fields,
    updatedAt: Math.max(Date.now(), Number(fresh.updatedAt || 0) + 1),
  }))), [mutateBoardTask, save]);

  const toggleTask = useCallback((task) => {
    const done = isTaskComplete(task);
    return patchTask(task.id, done ? {
      status: 'open', completedAt: null, completedBy: null, closedByReply: null,
    } : { status: 'done', completedAt: Date.now(), completedBy: meId });
  }, [meId, patchTask]);

  const changeTaskCategory = useCallback((task, category) => save(() => mutateBoardTask(task.id,
    (fresh) => planTaskCategoryChange(fresh, category, {
      user: me, selectedDate, todayKey, now: Date.now(),
    }) ?? fresh)), [me, mutateBoardTask, save, selectedDate, todayKey]);

  const addTask = useCallback(async (values) => {
    const account = values.accountId
      ? db.accounts.find((item) => item.id === values.accountId)
      : db.accounts.find((item) => item.branchId === values.branchId && item.name === values.account);
    const unit = values.accountUnitId
      ? (db.accountUnits || []).find((item) => item.id === values.accountUnitId)
      : null;
    const unitById = new Map((db.accountUnits || []).map((item) => [item.id, item]));
    const configuredAssigneeId = values.assigneeId === undefined
      ? inheritedAccountOwnerId(account, unit, unitById)
      : values.assigneeId;
    const assigneeId = configuredAssigneeId && db.users.some((person) => person.id === configuredAssigneeId
      && person.active !== false && person.branchIds?.includes(values.branchId))
      ? configuredAssigneeId
      : null;
    const created = values.createdAt;
    const result = await save(() => createDoc('tasks', {
      branchId: values.branchId, boardDate: selectedDate, title: values.title.trim(),
      account: values.account || null, accountId: account?.id || null,
      accountName: account?.name || values.accountName || values.account || null,
      accountUnitId: unit?.id || null, accountUnitName: unit?.name || values.accountUnitName || null,
      needsAccountReview: false, accountCandidateIds: [], accountUnitCandidateIds: [],
      detail: values.detail?.trim() || null, assigneeId,
      priority: values.priority || 'normal', status: 'open', source: 'manual', sourceEmail: null,
      createdAt: created, updatedAt: created, completedAt: null, completedBy: null, closedByReply: null,
    }, values.id));
    if (result !== false && result !== null) setAdding(false);
    return result;
  }, [createDoc, db?.accountUnits, db?.accounts, save, selectedDate]);

  const claimTask = useCallback(async (task) => {
    if (selectedDate !== todayKey || !isTaskOnBoard(task, selectedDate, todayKey)) {
      setErr('Only tasks on today’s board can be claimed.');
      return false;
    }
    if (task.status !== 'open' || task.assigneeId) {
      setErr(task.assigneeId ? 'Someone else has already claimed this task.' : 'Only open tasks can be claimed.');
      return false;
    }
    let refusal = 'Someone else changed this task before it could be claimed.';
    const claimed = await mutateDoc('tasks', task.id, (fresh) => {
      if (!isTaskOnBoard(fresh, selectedDate, todayKey)) { refusal = 'Only tasks on today’s board can be claimed.'; return null; }
      if (fresh.status !== 'open') { refusal = 'This task is no longer open.'; return null; }
      if (fresh.assigneeId) { refusal = 'Someone else claimed this task first.'; return null; }
      if (!me?.branchIds?.includes(fresh.branchId)) { refusal = 'You are not assigned to this task’s branch.'; return null; }
      return {
        ...fresh,
        assigneeId: meId,
        updatedAt: Math.max(Date.now(), Number(fresh.updatedAt || 0) + 1),
      };
    });
    if (!claimed) setErr(refusal);
    return claimed;
  }, [me?.branchIds, meId, mutateDoc, selectedDate, setErr, todayKey]);

  const getTaskEmailDetails = useCallback(
    (taskId) => taskId.startsWith('personal_') ? personal.loadEmail(taskId) : getDoc('taskEmailDetails', taskId),
    [getDoc, personal.loadEmail],
  );

  const loadTaskMessages = useCallback((taskId, branchId) => taskId.startsWith('personal_')
    ? personal.loadMessages(taskId) : getTaskMessages(taskId, branchId), [getTaskMessages, personal.loadMessages]);

  const addJobOrderFromTask = useCallback(async (task) => {
    if (!canManage || selectedDate !== todayKey || !isTaskOnBoard(task, selectedDate, todayKey) || task.jobOrderId) {
      setErr('Only an unlinked staffing request on today’s board can be added.');
      return false;
    }
    const accountById = new Map((db?.accounts || []).map((account) => [account.id, account]));
    const unitById = new Map((db?.accountUnits || []).map((unit) => [unit.id, unit]));
    const order = buildTaskJobOrder(task, accountById, unitById, db?.users || []);
    if (!order) {
      setErr('This staffing request no longer has valid account routing, headcount, or email provenance.');
      return false;
    }
    return linkTaskJobOrder(task.id, `task_order_${task.id}`, order);
  }, [canManage, db?.accounts, db?.accountUnits, db?.users, linkTaskJobOrder, selectedDate, setErr, todayKey]);

  const markOut = useCallback(async (person) => {
    const goingOut = !isOutToday(person, todayKey);
    const userSaved = await save(() => updateRecord('users', person.id, {
      outToday: goingOut, outDate: goingOut ? todayKey : null,
    }));
    if (!userSaved || !goingOut) return;
    const updates = branchTasks
      .filter((task) => task.assigneeId === person.id && !isTaskComplete(task))
      .map((task) => ({
        id: task.id,
        fields: { assigneeId: null, updatedAt: Math.max(Date.now(), Number(task.updatedAt || 0) + 1) },
      }));
    if (updates.length) await save(() => bulkUpdateDocs('tasks', updates));
  }, [bulkUpdateDocs, save, branchTasks, todayKey, updateRecord]);

  const bulkReassign = useCallback(async (from, to, branchId) => {
    if (!visibleBranchIds.includes(branchId)) {
      setErr('Choose a branch before moving work.');
      return false;
    }
    const target = to ? db.users.find((person) => person.id === to) : null;
    if (target && !target.branchIds?.includes(branchId)) {
      setErr('The new owner is not assigned to that branch.');
      return false;
    }
    const updates = branchTasks
      .filter((task) => task.branchId === branchId && task.assigneeId === from && !isTaskComplete(task))
      .map((task) => ({
        id: task.id,
        fields: { assigneeId: to || null, updatedAt: Math.max(Date.now(), Number(task.updatedAt || 0) + 1) },
      }));
    if (updates.length) await save(() => bulkUpdateDocs('tasks', updates));
    return true;
  }, [bulkUpdateDocs, db?.users, save, setErr, branchTasks, visibleBranchIds]);

  if (loading) return <BoardLoading />;
  if (!me) return <RosterGate db={db} meId={meId} pickMe={pickMe} />;

  const branchLabel = aggregateMode
    ? 'All assigned branches'
    : (myBranches.find((branch) => branch.id === activeBranchFilter)?.name || 'My branch');

  return (
    <main className={`day-board-shell${layout === 'wall' ? ' is-wall' : ''}`}>
      {err ? <ErrorBanner message={err} onDismiss={() => setErr(null)} /> : null}
      {personal.error ? <p className="personal-error" role="alert">{personal.error}</p> : null}
      {layout !== 'wall' && headerControlsTarget ? createPortal(
        <BoardHeaderControls mode={personal.mode} onMode={personal.chooseMode}
          onSetup={() => setView('setup')} settingsOpen={view === 'setup'} />, headerControlsTarget
      ) : null}
      {view === 'setup' ? (
        <SetupPanel key={meId} db={db} me={me} isAdmin={isAdmin} canManage={canManage} personal={personal} visibleBranchIds={visibleBranchIds}
          createRecord={createDoc} updateRecord={updateRecord} deleteRecord={deleteDoc} createBranch={createBranch}
          onBack={() => setView('board')} />
      ) : (
        <>
          {layout === 'wall' ? <WallHeading selectedDate={selectedDate} todayKey={todayKey} now={now}
            myBranches={personalOnly ? displayBranches.filter((branch) => branch.id === PERSONAL_BRANCH) : myBranches}
            branchFilter={personalOnly ? PERSONAL_BRANCH : activeBranchFilter || ''} canAggregateBranches={canAggregateBranches && !personalOnly}
            onBranch={setBranchFilter} onDate={setSelectedDate} onQueue={() => onLayoutChange('queue')}
            mode={personal.mode} onMode={personal.chooseMode} onSetup={() => setView('setup')} />
            : <BoardHeading selectedDate={selectedDate} todayKey={todayKey} now={now}
            branchLabel={personalOnly ? 'Personal · Only you' : personal.mode === 'combined' ? `${branchLabel} + Personal` : branchLabel} myBranches={myBranches} branchFilter={activeBranchFilter || ''}
            syncing={syncing} canAggregateBranches={canAggregateBranches} onBranch={setBranchFilter}
            onDate={setSelectedDate} onRefresh={() => pull(false)} onAdd={() => setAdding(true)}
            onSetup={() => setView('setup')} personalOnly={personalOnly} mode={personal.mode} onMode={personal.chooseMode} />}
          <BoardSurface tasks={tasks} accounts={accounts} accountUnits={accountUnits} roster={roster} me={me}
            branches={displayBranches} aggregateMode={aggregateMode || personal.mode !== 'branch'}
            canManage={canManage && !personalOnly} now={now} selectedDate={selectedDate} todayKey={todayKey}
            layout={layout} onLayoutChange={onLayoutChange}
            teamOpen={teamOpen} onTeamOpen={() => setTeamOpen((open) => !open)}
            onToggle={toggleTask} onPatch={patchTask} onClaim={claimTask} onCategoryChange={changeTaskCategory}
            onLoadEmail={getTaskEmailDetails}
            onLoadMessages={loadTaskMessages}
            onAddJobOrder={addJobOrderFromTask}
            onOpenJobOrders={onOpenJobOrders}
            onMarkOut={markOut} onBulk={bulkReassign} onSwitchPerson={() => pickMe(null)} />
        </>
      )}
      {adding ? <AddTaskDialog db={db} visibleBranchIds={visibleBranchIds} selectedDate={selectedDate}
        onClose={() => setAdding(false)} onSave={addTask} /> : null}
    </main>
  );
}

function BoardLoading() {
  return <div className="board-loading" role="status"><RefreshCw className="spin" size={18} /> Loading today’s board</div>;
}

function RosterGate({ db, meId, pickMe }) {
  if (isConfigured) {
    return <div className="roster-gate"><div><h1>Your account is not on the board yet</h1>
      <p>An admin needs to add your sign-in UID to the team roster before branch data can load.</p><code>{meId}</code></div></div>;
  }
  return (
    <div className="roster-gate"><div className="roster-picker"><h1>Preview the day board</h1>
      <p>Local mode uses the sample roster below. The hosted board uses Firebase sign-in.</p>
      {(db?.users || []).map((person) => <button key={person.id} type="button" onClick={() => pickMe(person.id)}>
        <span className="owner-mark" style={{ '--owner-color': userMarker(person) }} />
        <span><strong>{person.name}</strong><small>{ROLES[person.role]}</small></span></button>)}</div></div>
  );
}

function ErrorBanner({ message, onDismiss }) {
  return <div className="board-error" role="alert"><AlertTriangle size={16} /><span>{message}</span>
    <button type="button" onClick={onDismiss} aria-label="Dismiss error"><X size={16} /></button></div>;
}

function BoardHeaderControls({ mode, onMode, onSetup, settingsOpen = false }) {
  return <>
    <label className="task-source-select" title="Personal tasks stay visible only to you">
      <span className="sr-only">Task source</span>
      <select value={mode} onChange={(event) => onMode(event.target.value)}>
        <option value="branch">Branch</option>
        <option value="personal">Personal</option>
        <option value="combined">Combined</option>
      </select><ChevronDown size={14} aria-hidden="true" />
    </label>
    <button type="button" className="board-settings-button" onClick={onSetup}
      title="Settings" aria-label="Settings" aria-pressed={settingsOpen}><Settings size={17} /></button>
  </>;
}

function BoardHeading({
  selectedDate, todayKey, now, branchLabel, myBranches, branchFilter, syncing,
  canAggregateBranches, onBranch, onDate, onRefresh, onAdd, onSetup, personalOnly, mode, onMode,
}) {
  const isToday = selectedDate === todayKey;
  return (
    <section className="board-heading">
      <div className="board-date-title"><span className="board-eyebrow">Day board</span>
        <h1>{formatCentralDate(selectedDate, { weekday: 'long', month: 'long', day: 'numeric' })}</h1>
        <div className="board-clock">{isToday ? formatCentralTime(now) : 'Saved day'}<span>·</span>
          <span>{CENTRAL_TIME_ZONE.replace('_', ' ')}</span></div></div>
      <div className="board-heading-actions">
        <div className="date-stepper" aria-label="Choose board date">
          <button type="button" onClick={() => onDate(shiftDateKey(selectedDate, -1))} aria-label="Previous day"><ArrowLeft size={17} /></button>
          <button type="button" aria-current={isToday ? 'date' : undefined} className={isToday ? 'is-current' : ''} onClick={() => onDate(todayKey)}>Today</button>
          <button type="button" onClick={() => onDate(shiftDateKey(selectedDate, 1))} disabled={isToday} aria-label="Next day"><ArrowRight size={17} /></button>
        </div>
        {!personalOnly && <label className="board-select-control"><Building2 size={15} /><span className="sr-only">Branch</span>
          <select value={branchFilter} onChange={(event) => onBranch(event.target.value)}>
            {canAggregateBranches ? <option value={ALL_BRANCHES}>All assigned branches</option> : null}
            {myBranches.map((branch) => <option key={branch.id} value={branch.id}>{branch.name}</option>)}
          </select><ChevronDown size={14} /></label>}
        {isConfigured
          ? <span className="icon-control sync-indicator" title="Changes sync automatically" aria-label="Automatic sync"><RefreshCw size={17} /></span>
          : <button className="icon-control" type="button" onClick={onRefresh} title="Refresh local preview" aria-label="Refresh local preview"><RefreshCw className={syncing ? 'spin' : ''} size={17} /></button>}
        <FullscreenButton />
        <div className="board-fullscreen-controls"><BoardHeaderControls mode={mode} onMode={onMode} onSetup={onSetup} /></div>
        {personalOnly && isToday ? null : isToday
          ? <button className="primary-control" type="button" onClick={onAdd}><Plus size={17} /> Add task</button>
          : <button className="primary-control" type="button" onClick={() => onDate(todayKey)}><ArrowRight size={17} /> Return to today</button>}
      </div>
      <div className="branch-context"><span className="live-pulse" /> {branchLabel} · {isConfigured ? 'automatic sync' : 'local preview data'}</div>
    </section>
  );
}

function FullscreenButton() {
  const [active, setActive] = useState(Boolean(document.fullscreenElement));
  useEffect(() => {
    const update = () => setActive(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', update);
    return () => document.removeEventListener('fullscreenchange', update);
  }, []);
  async function toggle() {
    try {
      if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
      else await document.exitFullscreen();
    } catch { /* Browser or display policy can block fullscreen. */ }
  }
  const label = active ? 'Exit full screen' : 'Full screen';
  return <button className="icon-control" type="button" onClick={toggle} title={label} aria-label={label}>
    {active ? <Minimize2 size={17} /> : <Maximize2 size={17} />}
  </button>;
}

function WallHeading({ selectedDate, todayKey, now, myBranches, branchFilter, canAggregateBranches, onBranch, onDate, onQueue, mode, onMode, onSetup }) {
  const isToday = selectedDate === todayKey;
  async function returnToQueue() {
    if (document.fullscreenElement) {
      try { await document.exitFullscreen(); } catch { /* Queue remains accessible if the browser refuses. */ }
    }
    onQueue();
  }
  return (
    <header className="wall-heading" aria-label="Wall display controls">
      <h1 className="wall-mode-label"><Columns3 size={18} /> Wall<span>All open work</span></h1>
      <div className="wall-source-controls"><BoardHeaderControls mode={mode} onMode={onMode} onSetup={onSetup} /></div>
      <label className="wall-branch"><span className="sr-only">Branch</span>
          <select value={branchFilter} onChange={(event) => onBranch(event.target.value)}>
            {canAggregateBranches ? <option value={ALL_BRANCHES}>All assigned branches</option> : null}
            {myBranches.map((branch) => <option key={branch.id} value={branch.id}>{branch.code} · {branch.name}</option>)}
          </select><ChevronDown size={14} /></label>
      <div className={`wall-date${isToday ? '' : ' is-history'}`}>
        <time dateTime={selectedDate}>{!isToday ? 'Saved day · ' : ''}{formatCentralDate(selectedDate, { month: 'short', day: 'numeric' })}</time>
        {isToday ? <span>{formatCentralTime(now)}</span>
          : <button type="button" onClick={() => onDate(todayKey)}>Return to today</button>}
      </div>
      {!isConfigured ? <span className="wall-preview-label">Local preview</span> : null}
      <div className="wall-heading-actions"><button className="wall-exit" type="button" onClick={returnToQueue}>
        <LayoutList size={17} /><span>Back to Queue</span></button><FullscreenButton /></div>
    </header>
  );
}

function BoardSurface({
  tasks, accounts, accountUnits, roster, branches, aggregateMode, me, canManage, now,
  selectedDate, todayKey, layout, onLayoutChange, teamOpen, onTeamOpen, onToggle, onPatch,
  onClaim, onCategoryChange, onLoadEmail, onLoadMessages, onAddJobOrder, onOpenJobOrders, onMarkOut, onBulk, onSwitchPerson,
}) {
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('priority');
  const [selectedTaskId, setSelectedTaskId] = useState(null);
  const closeTask = useCallback(() => setSelectedTaskId(null), []);
  const readOnly = selectedDate !== todayKey;
  const branchById = useMemo(() => new Map(branches.map((branch) => [branch.id, branch])), [branches]);
  const accountById = useMemo(() => new Map(accounts.map((account) => [account.id, account])), [accounts]);
  const unitById = useMemo(() => new Map(accountUnits.map((unit) => [unit.id, unit])), [accountUnits]);
  const personById = useMemo(() => new Map(roster.map((person) => [person.id, person])), [roster]);
  const priorityOf = useCallback(
    (task) => effectivePriority(task, accounts, accountById),
    [accountById, accounts],
  );
  const counts = useMemo(() => {
    const result = { open: 0, hot: 0, unassigned: 0, cleared: 0 };
    tasks.forEach((task) => {
      if (isTaskComplete(task)) { result.cleared += 1; return; }
      result.open += 1;
      if (!task.assigneeId) result.unassigned += 1;
      if (priorityOf(task) === 'high') result.hot += 1;
    });
    return result;
  }, [priorityOf, tasks]);
  const selectedTask = selectedTaskId ? tasks.find((task) => task.id === selectedTaskId) : null;
  // Queue search, filters, and sort stay local to Queue. The room display always
  // shows all open work for the selected branches/day, with urgent work first.
  const wallTasks = useMemo(() => {
    const rank = { high: 0, normal: 1, low: 2 };
    return tasks.filter((task) => !isTaskComplete(task)).sort((a, b) =>
      rank[priorityOf(a)] - rank[priorityOf(b)] || Number(a.createdAt || 0) - Number(b.createdAt || 0));
  }, [priorityOf, tasks]);

  const shown = useMemo(() => {
    const needle = search.trim().toLocaleLowerCase();
    const filtered = tasks.filter((task) => {
      if (filter === 'mine' && task.assigneeId !== me.id) return false;
      if (filter === 'unassigned' && (task.assigneeId || isTaskComplete(task))) return false;
      if (filter === 'hot' && (priorityOf(task) !== 'high' || isTaskComplete(task))) return false;
      if (filter === 'cleared' && !isTaskComplete(task)) return false;
      if (!needle) return true;
      const owner = personById.get(task.assigneeId)?.name || '';
      const branch = branchById.get(task.branchId);
      return [task.title, accountLabel(task, accountById, unitById), task.detail,
        task.sourceEmail?.from, task.latestThreadUpdate?.from,
        ...(task.sourceEmail?.to || []), ...(task.latestThreadUpdate?.to || []),
        task.latestThreadUpdate?.excerpt, task.latestThreadUpdate?.deadlineText,
        owner, branch?.name, branch?.code]
        .filter(Boolean).some((value) => String(value).toLocaleLowerCase().includes(needle));
    });
    const rank = { high: 0, normal: 1, low: 2 };
    return [...filtered].sort((a, b) => {
      if (sort === 'oldest') return Number(a.createdAt || 0) - Number(b.createdAt || 0);
      if (sort === 'newest') return Number(b.createdAt || 0) - Number(a.createdAt || 0);
      if (sort === 'account') return accountLabel(a, accountById, unitById)
        .localeCompare(accountLabel(b, accountById, unitById));
      const priorityDelta = rank[priorityOf(a)] - rank[priorityOf(b)];
      return priorityDelta || (Number(a.createdAt || 0) - Number(b.createdAt || 0));
    });
  }, [accountById, branchById, filter, me.id, personById, priorityOf, search, sort, tasks, unitById]);

  const filters = [
    ['all', 'All work', tasks.length], ['mine', 'Mine', tasks.filter((task) => task.assigneeId === me.id).length],
    ['unassigned', 'Unassigned', counts.unassigned], ['hot', 'Hot', counts.hot], ['cleared', 'Cleared', counts.cleared],
  ];

  return (
    <section className="board-surface">
      {layout === 'queue' && <><div className="board-metrics" aria-label="Board totals"><Metric value={counts.open} label="Open" tone="blue" />
        <Metric value={counts.hot} label="Hot" tone="red" /><Metric value={counts.unassigned} label="Unassigned" tone="amber" />
        <Metric value={counts.cleared} label="Cleared" tone="green" /></div>
      <div className="board-toolbar">
        <div className="filter-tabs" role="group" aria-label="Filter tasks">{filters.map(([id, label, count]) => (
          <button key={id} type="button" aria-pressed={filter === id} className={filter === id ? 'is-active' : ''} onClick={() => setFilter(id)}>{label}<span>{count}</span></button>
        ))}</div>
        <label className="board-search"><Search size={15} /><span className="sr-only">Search tasks</span>
          <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search tasks" />
          {search ? <button type="button" onClick={() => setSearch('')} aria-label="Clear search"><X size={14} /></button> : null}</label>
        <select className="board-sort" value={sort} onChange={(event) => setSort(event.target.value)} aria-label="Sort tasks">
          <option value="priority">Priority first</option><option value="oldest">Oldest first</option>
          <option value="newest">Newest first</option><option value="account">Account A–Z</option></select>
        <div className="layout-toggle" role="group" aria-label="Board layout">
          <button type="button" aria-pressed className="is-active" onClick={() => onLayoutChange('queue')} title="Queue view"><LayoutList size={16} /><span>Queue</span></button>
          <button type="button" aria-pressed={false} onClick={() => onLayoutChange('wall')} title="Wall view"><Columns3 size={16} /><span>Wall</span></button>
        </div>
        {canManage && !readOnly ? <button type="button" className={`team-toggle${teamOpen ? ' is-active' : ''}`} onClick={onTeamOpen} aria-expanded={teamOpen}><Users size={16} /> Team</button> : null}
      </div>
      {teamOpen && canManage && !readOnly ? <TeamControls roster={roster} branches={branches.filter((branch) => branch.id !== PERSONAL_BRANCH)} todayKey={todayKey} selectedDate={selectedDate}
        onMarkOut={onMarkOut} onBulk={onBulk} onSwitchPerson={onSwitchPerson} /> : null}</>}
      {layout === 'queue' ? <QueueView tasks={shown} accountById={accountById} unitById={unitById}
        personById={personById} branchById={branchById} aggregateMode={aggregateMode}
        readOnly={readOnly} showAllCleared={filter === 'cleared'} now={now} selectedDate={selectedDate}
        onToggle={onToggle} onClaim={onClaim} onCategoryChange={onCategoryChange} onOpenTask={setSelectedTaskId} />
        : <WallView tasks={wallTasks} accounts={accounts} accountById={accountById}
          roster={roster} branchById={branchById} aggregateMode={aggregateMode} now={now}
          onOpenTask={setSelectedTaskId} />}
      {selectedTask ? <TaskDetailDrawer task={selectedTask} accountById={accountById} unitById={unitById}
        branchById={branchById} roster={roster} me={me} canManage={canManage && selectedTask.scope !== 'personal'} readOnly={readOnly}
        onClose={closeTask} onLoadEmail={onLoadEmail} onLoadMessages={onLoadMessages} onClaim={onClaim}
        onPatch={onPatch} onToggle={onToggle} onCategoryChange={onCategoryChange} onAddJobOrder={onAddJobOrder}
        onOpenJobOrders={onOpenJobOrders} /> : null}
    </section>
  );
}

function Metric({ value, label, tone }) {
  return <div className={`board-metric is-${tone}`}><strong>{value}</strong><span>{label}</span></div>;
}

function QueueView({
  tasks, accountById, unitById, personById, branchById, aggregateMode,
  readOnly, showAllCleared, now, selectedDate, onToggle, onClaim, onOpenTask, onCategoryChange,
}) {
  const [clearedOpen, setClearedOpen] = useState(showAllCleared);
  const dragRef = useRef(null);
  const lastDragEnd = useRef(0);
  const [draggedId, setDraggedId] = useState(null);
  const [dropCategory, setDropCategory] = useState(null);
  const [savingId, setSavingId] = useState(null);
  const [moveFeedback, setMoveFeedback] = useState('');
  const activeColumns = useMemo(() => TASK_CATEGORIES.map((category) => ({
    ...category,
    tasks: tasks.filter((task) => !isTaskComplete(task) && classifyTaskCategory(task) === category.id),
  })), [tasks]);
  const clearedColumns = useMemo(() => TASK_CATEGORIES.map((category) => ({
    ...category,
    tasks: tasks.filter((task) => isTaskComplete(task) && classifyTaskCategory(task) === category.id),
  })), [tasks]);
  const clearedCount = clearedColumns.reduce((total, category) => total + category.tasks.length, 0);

  useEffect(() => setClearedOpen(showAllCleared), [showAllCleared]);

  const endDrag = useCallback(() => {
    dragRef.current = null;
    lastDragEnd.current = Date.now();
    setDraggedId(null); setDropCategory(null);
  }, []);
  useEffect(() => {
    dragRef.current = null;
    setDraggedId(null); setDropCategory(null); setMoveFeedback('');
  }, [readOnly, selectedDate]);

  function startDrag(event, task) {
    if (readOnly || task.status !== 'open' || savingId) { event.preventDefault(); return; }
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('application/x-branchsuite-task', task.id);
    dragRef.current = task.id;
    setDraggedId(task.id); setMoveFeedback('');
  }
  function taskForDrop(category) {
    const task = tasks.find((item) => item.id === dragRef.current);
    return !readOnly && !savingId && task?.status === 'open'
      && classifyTaskCategory(task) !== category.id ? task : null;
  }
  function dragOver(event, category) {
    if (!taskForDrop(category)) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
    setDropCategory(category.id);
  }
  async function drop(event, category) {
    const task = taskForDrop(category);
    if (!task || event.dataTransfer.getData('application/x-branchsuite-task') !== task.id) return;
    event.preventDefault(); event.stopPropagation(); endDrag();
    setSavingId(task.id); setMoveFeedback(`Moving to ${category.label}…`);
    try {
      const saved = await onCategoryChange(task, category.id);
      setMoveFeedback(saved ? `Moved “${task.title}” to ${category.label}.` : 'The category did not save. Try again.');
    } catch { setMoveFeedback('The category did not save. Try again.'); }
    finally { setSavingId(null); }
  }
  function openTask(id) {
    if (dragRef.current || Date.now() - lastDragEnd.current < 250) return;
    onOpenTask(id);
  }

  if (!tasks.length) return <EmptyBoard selectedDate={selectedDate} />;

  const sharedTaskProps = {
    accountById,
    unitById,
    personById,
    branchById,
    aggregateMode,
    readOnly,
    now,
    selectedDate,
    onToggle,
    onClaim,
    onOpenTask: openTask,
    onDragStart: startDrag,
    onDragEnd: endDrag,
    draggedId,
    savingId,
  };

  return (
    <div className={`queue-viewport${showAllCleared ? ' is-cleared-filter' : ''}`} aria-label="Day board tasks">
      {!readOnly && !showAllCleared ? <p className="queue-move-help" id="queue-move-help">Drag an open task to another category, or choose Category in its details.</p> : null}
      <p className="category-move-feedback" role="status" aria-live="polite">{moveFeedback}</p>
      <div className="queue-category-grid">
        {activeColumns.map((category) => <QueueCategory key={category.id} category={category}
          taskProps={sharedTaskProps} emptyLabel="No matching active tasks" dropActive={dropCategory === category.id}
          onDragOver={(event) => dragOver(event, category)} onDrop={(event) => drop(event, category)}
          onDragLeave={(event) => { if (!event.currentTarget.contains(event.relatedTarget)) setDropCategory(null); }} />)}
      </div>

      <section className={`queue-cleared-tray${clearedOpen ? ' is-open' : ''}`} aria-labelledby="queue-cleared-heading">
        <button type="button" className="queue-cleared-toggle" onClick={() => setClearedOpen((open) => !open)}
          aria-expanded={clearedOpen} disabled={!clearedCount}>
          {clearedOpen ? <ChevronDown size={17} /> : <ChevronRight size={17} />}
          <span className="queue-cleared-label" id="queue-cleared-heading">Cleared</span>
          <strong>{clearedCount}</strong><small>Completed tasks from this board</small>
        </button>
        {clearedOpen && clearedCount ? <div className="queue-cleared-body">
          <div className="queue-category-grid is-cleared">
            {clearedColumns.map((category) => <QueueCategory key={category.id} category={category}
              taskProps={sharedTaskProps} emptyLabel="No cleared tasks" compact />)}
          </div>
        </div> : null}
      </section>
    </div>
  );
}

function QueueCategory({ category, taskProps, emptyLabel, compact = false, dropActive, onDragOver, onDragLeave, onDrop }) {
  const headingId = `queue-${compact ? 'cleared-' : ''}${category.id}-heading`;
  return <section className={`queue-category is-${category.id}${compact ? ' is-cleared' : ''}${dropActive ? ' is-drop-target' : ''}`} aria-labelledby={headingId}
    data-category={category.id} onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop}>
    <header className="queue-category-header">
      <div className="queue-category-copy"><h2 id={headingId}>{category.label}</h2>
        <p>{category.description}</p></div>
      <strong className="queue-category-count">{category.tasks.length}<span> tasks</span></strong>
    </header>
    <div className="queue-category-list">
      {category.tasks.map((task) => <TaskRow key={task.id} task={task} {...taskProps} />)}
      {!category.tasks.length ? <p className="queue-category-empty">{emptyLabel}</p> : null}
    </div>
  </section>;
}

function ClaimButton({ task, onClaim, className = 'task-claim', children = 'Claim' }) {
  const [busy, setBusy] = useState(false);
  async function claim() {
    if (busy) return;
    setBusy(true);
    const claimed = await onClaim(task);
    if (!claimed) setBusy(false);
  }
  return <button type="button" className={className} disabled={busy} onClick={claim}>{busy ? 'Claiming…' : children}</button>;
}

const TaskRow = memo(function TaskRow({
  task, accountById, unitById, personById, branchById, aggregateMode, readOnly, now, selectedDate,
  onToggle, onClaim, onOpenTask, onDragStart, onDragEnd, draggedId, savingId,
}) {
  const owner = personById.get(task.assigneeId);
  const account = accountById.get(task.accountId);
  const priority = task.priority === 'high' || account?.isPriority ? 'high' : (task.priority || 'normal');
  const completed = isTaskComplete(task);
  const originalDate = dateForTask(task);
  const carried = originalDate && originalDate < selectedDate;
  const branch = branchById.get(task.branchId);
  const canClaim = !readOnly && task.status === 'open' && !task.assigneeId;
  const validOwner = isValidTaskOwner(owner, task.branchId);
  const formerOwner = Boolean(task.assigneeId && !validOwner);
  const initials = validOwner ? personInitials(owner) : null;
  const age = readOnly
    ? safeCentralTime(task.createdAt, 'Unknown')
    : taskAge(task, now);
  const createdAt = Number(task.createdAt);
  const dateTime = Number.isFinite(createdAt) ? new Date(createdAt).toISOString() : undefined;
  const latestUpdate = task.latestThreadUpdate;
  const threadPreview = latestUpdate?.excerpt || latestUpdate?.summary;
  const threadLabel = latestUpdate?.deadlineMissed
    ? `Deadline missed${latestUpdate.deadlineText ? `: ${latestUpdate.deadlineText}` : ''}`
    : latestUpdate?.deadlineText ? `Due: ${latestUpdate.deadlineText}`
      : `Reply ${safeCentralTime(latestUpdate?.receivedAt, '')}`.trim();
  return (
    <article data-task-id={task.id} aria-busy={savingId === task.id}
      className={`queue-task is-${priority}${completed ? ' is-complete' : ''}${task.status === 'reply_closed' ? ' is-reply' : ''}${task.needsAccountReview ? ' needs-review' : ''}${draggedId === task.id ? ' is-dragging' : ''}`}>
      <button type="button" className="queue-task-check" disabled={readOnly} onClick={() => onToggle(task)} aria-label={completed ? `Reopen ${task.title}` : `Complete ${task.title}`}>
        {completed ? <Check size={15} /> : <Circle size={17} />}</button>
      <button type="button" className="queue-task-main" onClick={() => onOpenTask(task.id)} aria-haspopup="dialog"
        draggable={!readOnly && task.status === 'open' && !savingId} onDragStart={(event) => onDragStart(event, task)} onDragEnd={onDragEnd}
        aria-describedby={!readOnly && task.status === 'open' ? 'queue-move-help' : undefined}
        title={!readOnly && task.status === 'open' ? 'Drag to move category. Click to view details.' : undefined}
        aria-label={`View details for ${task.title}`}>
        <strong className="queue-task-title">{task.title}</strong>
        <span className="queue-task-context">
          {aggregateMode ? <span className="queue-task-branch" title={branch?.name || task.branchId}>
            {branch?.code || task.branchId}</span> : null}
          <span className="queue-task-account">{task.scope === 'personal' ? 'Only you' : accountLabel(task, accountById, unitById)}</span>
        </span>
        {latestUpdate ? <span className={`queue-thread-preview${latestUpdate.deadlineMissed ? ' is-missed' : ''}`}
          title={[threadLabel, latestUpdate.from, latestUpdate.to?.length ? `to ${latestUpdate.to.join(', ')}` : null,
            threadPreview, latestUpdate.priorityReason].filter(Boolean).join(' · ')}>
          <strong>{threadLabel}</strong>{threadPreview ? <span> · {threadPreview}</span> : null}
        </span> : null}
      </button>
      <div className="queue-task-owner">{canClaim
        ? <ClaimButton task={task} onClaim={onClaim} className="queue-task-claim" />
        : <span className={`queue-owner-badge${formerOwner ? ' is-former' : ''}${!task.assigneeId ? ' is-open' : ''}`}
            style={{ '--owner-color': validOwner ? userMarker(owner) : MARKERS.none.color }}
            title={validOwner ? owner.name : formerOwner ? 'Former owner' : 'Unassigned'}>
          {initials || (formerOwner ? 'FMR' : 'Open')}
        </span>}</div>
      <time className="queue-task-age" dateTime={dateTime} title={safeCentralTime(task.createdAt)}>{age}</time>
      <div className="queue-task-flags">
        {priority === 'high' ? <span className="queue-task-flag is-hot">Hot</span> : null}
        {task.threadUpdateCount > 0 ? <span className="queue-task-flag is-update"
          title={`${task.threadUpdateCount} email ${task.threadUpdateCount === 1 ? 'reply' : 'replies'} received`}>
          {task.threadUpdateCount} {task.threadUpdateCount === 1 ? 'reply' : 'replies'}</span> : null}
        {carried ? <span className="queue-task-flag" title={`Originally on ${formatCentralDate(originalDate)}`}>Carried</span> : null}
        {task.status === 'reply_closed' ? <span className="queue-task-flag is-reply" title="Completed by reply">Reply done</span> : null}
        {task.needsAccountReview ? <span className="queue-task-flag is-review">Review</span> : null}
      </div>
    </article>
  );
});

function TaskDetailDrawer({
  task, accountById, unitById, branchById, roster, me, canManage, readOnly,
  onClose, onLoadEmail, onLoadMessages, onClaim, onPatch, onToggle, onCategoryChange, onAddJobOrder, onOpenJobOrders,
}) {
  const drawerRef = useRef(null);
  const [emailDetails, setEmailDetails] = useState(null);
  const [emailState, setEmailState] = useState('idle');
  const [messageResult, setMessageResult] = useState({ taskId: null, messages: [], state: 'idle' });
  const [feedback, setFeedback] = useState('');
  const [claiming, setClaiming] = useState(false);
  const [changingCategory, setChangingCategory] = useState(false);
  const [routingAccountId, setRoutingAccountId] = useState(task.accountId || '');
  const [routingUnitId, setRoutingUnitId] = useState(task.accountUnitId || '');
  const branch = branchById.get(task.branchId);
  const branchAccounts = useMemo(
    () => [...accountById.values()].filter((account) => account.branchId === task.branchId
      && (account.active !== false || account.id === task.accountId)),
    [accountById, task.accountId, task.branchId],
  );
  const branchUnits = useMemo(
    () => [...unitById.values()].filter((unit) => unit.branchId === task.branchId
      && unit.accountId === routingAccountId
      && activeUnitPath(unit, unitById)),
    [routingAccountId, task.branchId, unitById],
  );
  const unavailableRoutingUnit = routingUnitId
    && !branchUnits.some((unit) => unit.id === routingUnitId)
    ? unitById.get(routingUnitId) || { name: task.accountUnitName || 'Unavailable sub-account' }
    : null;
  const eligibleOwners = useMemo(
    () => roster.filter((person) => person.active !== false && person.branchIds?.includes(task.branchId)),
    [roster, task.branchId],
  );
  const owner = eligibleOwners.find((person) => person.id === task.assigneeId)
    || roster.find((person) => person.id === task.assigneeId);
  const taskPriority = task.priority === 'high' || accountById.get(task.accountId)?.isPriority
    ? 'high' : (task.priority || 'normal');
  const isEmailTask = task.source === 'email' || Boolean(task.sourceEmail);
  const canClaim = !readOnly && task.status === 'open' && !task.assigneeId;
  const outlookUrl = safeExternalUrl(task.sourceEmail?.webLink);
  const currentEligibleOwnerId = eligibleOwners.some((person) => person.id === task.assigneeId)
    ? task.assigneeId
    : null;
  const routingChanged = routingAccountId !== (task.accountId || '')
    || routingUnitId !== (task.accountUnitId || '')
    || task.needsAccountReview;

  useEffect(() => {
    const previous = document.activeElement;
    const drawer = drawerRef.current;
    drawer?.focus();
    const onKeyDown = (event) => {
      if (event.key === 'Escape') { event.preventDefault(); onClose(); return; }
      if (event.key !== 'Tab' || !drawer) return;
      const focusable = [...drawer.querySelectorAll('button:not(:disabled), a[href], select:not(:disabled), input:not(:disabled), textarea:not(:disabled), [tabindex="0"]')];
      if (!focusable.length) { event.preventDefault(); drawer.focus(); return; }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', onKeyDown);
    return () => { document.removeEventListener('keydown', onKeyDown); previous?.focus?.(); };
  }, [onClose]);

  useEffect(() => {
    let active = true;
    setEmailDetails(null);
    setFeedback('');
    if (!isEmailTask) { setEmailState('idle'); return () => { active = false; }; }
    setEmailState('loading');
    Promise.resolve(onLoadEmail(task.id)).then((result) => {
      if (!active) return;
      setEmailDetails(result);
      setEmailState(result ? 'ready' : 'missing');
    }).catch((error) => {
      console.error(error);
      if (active) setEmailState('error');
    });
    return () => { active = false; };
  }, [isEmailTask, onLoadEmail, task.id]);

  useEffect(() => {
    let active = true;
    if (!isEmailTask) return () => { active = false; };
    setMessageResult((current) => ({
      taskId: task.id,
      messages: current.taskId === task.id ? current.messages : [],
      state: 'loading',
    }));
    Promise.resolve(onLoadMessages(task.id, task.branchId)).then((messages) => {
      if (active) setMessageResult({ taskId: task.id, messages, state: 'ready' });
    }).catch((error) => {
      console.error('Could not load task email replies', error);
      if (active) setMessageResult((current) => ({ ...current, state: 'error' }));
    });
    return () => { active = false; };
  }, [isEmailTask, onLoadMessages, task.branchId, task.id, task.threadUpdateCount, task.lastThreadMessageAt]);

  useEffect(() => {
    setRoutingAccountId(task.accountId || '');
    setRoutingUnitId(task.accountUnitId || '');
  }, [task.accountId, task.accountUnitId, task.id]);

  async function claim() {
    if (claiming) return;
    setClaiming(true);
    const claimed = await onClaim(task);
    setFeedback(claimed ? 'Task assigned to you.' : 'This task could not be claimed. Refresh and check its current owner.');
    setClaiming(false);
  }

  async function confirmRouting() {
    const account = branchAccounts.find((item) => item.id === routingAccountId) || null;
    const unit = branchUnits.find((item) => item.id === routingUnitId) || null;
    if (routingUnitId && !unit) {
      setFeedback('That sub-account is archived, has an archived parent, or is no longer available. Choose another route.');
      return;
    }
    const inheritedOwner = inheritedAccountOwnerId(account, unit, unitById);
    const eligibleInheritedOwner = eligibleOwners.some((person) => person.id === inheritedOwner)
      ? inheritedOwner
      : null;
    const saved = await onPatch(task.id, {
      account: account?.name || null,
      accountId: account?.id || null,
      accountName: account?.name || null,
      accountUnitId: unit?.id || null,
      accountUnitName: unit?.name || null,
      needsAccountReview: false,
      accountCandidateIds: [],
      accountUnitCandidateIds: [],
      assigneeId: currentEligibleOwnerId || eligibleInheritedOwner,
    });
    setFeedback(saved
      ? (account ? `Routing set to ${account.name}${unit ? ` · ${unit.name}` : ''}.` : 'Account routing cleared.')
      : 'Account routing did not save.');
  }

  const rosterByEmail = useMemo(
    () => new Map(roster.filter((person) => person.email).map((person) => [normalizeEmail(person.email), person])),
    [roster],
  );
  const emailFrom = emailDetails?.from || task.sourceEmail?.from || 'Unknown sender';
  const emailTo = emailDetails?.to ?? task.sourceEmail?.to ?? null;
  const emailCc = emailDetails?.cc ?? task.sourceEmail?.cc ?? null;
  const emailSubject = emailDetails?.subject || task.sourceEmail?.subject || task.title;
  const receivedAt = emailDetails?.receivedAt || task.sourceEmail?.receivedAt || task.createdAt;
  const bodyText = emailDetails?.bodyText || task.sourceEmail?.bodyText || '';
  const originalDate = dateForTask(task);
  const replyAuthor = roster.find((person) => person.id === task.closedByReply?.byUserId);
  const latestUpdate = task.latestThreadUpdate;
  const threadMessages = messageResult.taskId === task.id ? messageResult.messages : [];
  const messageState = messageResult.taskId === task.id ? messageResult.state : 'loading';
  const chronologicalMessages = [...threadMessages].reverse();

  return <div className="task-detail-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
    <aside ref={drawerRef} className="task-detail-drawer" role="dialog" aria-modal="true" aria-labelledby="task-detail-title" tabIndex={-1}>
      <header className="task-detail-header"><div>
        <span className="task-detail-branch"><Building2 size={14} /> {branch?.code || task.branchId} · {branch?.name || 'Unknown branch'}</span>
        <h2 id="task-detail-title">{task.title}</h2>
        <p>{accountLabel(task, accountById, unitById)}</p>
        <div className="task-detail-meta"><span className={`priority-label ${PRIORITIES[taskPriority]?.className || PRIORITIES.normal.className}`}>
          <i />{PRIORITIES[taskPriority]?.label || PRIORITIES.normal.label} priority</span><span>Owner: {owner?.name || 'Unassigned'}</span></div>
      </div><button type="button" onClick={onClose} aria-label="Close task details"><X size={20} /></button></header>

      <div className="task-detail-scroll">
        <label className="task-category-control"><span>Category</span>
          <select aria-label="Category" value={task.category || ''} disabled={readOnly || task.status !== 'open' || changingCategory}
            onChange={async (event) => {
              const category = event.target.value || null;
              setChangingCategory(true);
              try {
                const saved = await onCategoryChange(task, category);
                setFeedback(saved ? 'Category saved.' : 'The category did not save. Try again.');
              } catch { setFeedback('The category did not save. Try again.'); }
              finally { setChangingCategory(false); }
            }}>
            <option value="">Automatic · {TASK_CATEGORIES.find((item) => item.id === classifyTaskCategory({ ...task, category: null }))?.label}</option>
            {TASK_CATEGORIES.map((category) => <option key={category.id} value={category.id}>{category.label}</option>)}
          </select>
        </label>
        {task.needsAccountReview ? <div className="task-account-review" role="status"><AlertTriangle size={16} />
          <span>{task.accountSuggestion?.accountId && task.accountSuggestion.accountId === task.accountId
            ? <><strong>Suggested account: {accountLabel(task, accountById, unitById)}</strong>
              {task.accountSuggestion.reason || 'Suggested from the email.'} A manager confirms or changes it before it is assigned.</>
            : <><strong>Needs account review</strong>{task.accountCandidateIds?.length
              ? 'The sender or message matched more than one account or location.'
              : 'No account matched the sender or message. Choose one to route this task.'}</>}</span></div> : null}
        <section className="task-detail-summary" aria-labelledby="task-summary-heading">
          <h3 id="task-summary-heading">Summary</h3>
          <p>{task.detail || 'No additional summary was provided.'}</p>
          {originalDate ? <p>Originally on {formatCentralDate(originalDate)}.</p> : null}
        </section>

        {latestUpdate ? <section className={`task-thread-update${latestUpdate.deadlineMissed ? ' is-missed' : ''}`}
          aria-labelledby="task-thread-update-heading">
          <h3 id="task-thread-update-heading">Latest email update</h3>
          <p className="task-thread-update-meta">{latestUpdate.from || 'Unknown sender'}
            {latestUpdate.to?.length ? ` to ${recipientLabels(latestUpdate.to, rosterByEmail)}` : ''}{' · '}{safeCentralTime(latestUpdate.receivedAt, 'Unknown', { dateStyle: 'medium', timeStyle: 'short' })}</p>
          {latestUpdate.deadlineText || latestUpdate.deadlineMissed ? <p className="task-thread-deadline">
            <AlertTriangle size={15} /><strong>{latestUpdate.deadlineMissed ? 'Deadline missed' : 'Deadline'}{latestUpdate.deadlineText ? `: ${latestUpdate.deadlineText}` : ''}</strong>
          </p> : null}
          {latestUpdate.summary || latestUpdate.excerpt ? <p>{latestUpdate.summary || latestUpdate.excerpt}</p> : null}
          {latestUpdate.priorityReason ? <p className="task-thread-priority">{latestUpdate.priorityReason}</p> : null}
          <p className="task-thread-update-meta">{isTaskComplete(task) ? 'Task is complete.' : 'Task remains open.'}</p>
        </section> : null}

        {task.status === 'reply_closed' && task.closedByReply ? <section className="task-email-detail" aria-labelledby="task-reply-heading">
          <h3 id="task-reply-heading">Completed by reply</h3>
          <dl><div><dt>Team member</dt><dd>{replyAuthor?.name || 'Board team member'}</dd></div>
            <div><dt>Completed</dt><dd>{safeCentralTime(task.closedByReply.at, 'Unknown', { dateStyle: 'medium', timeStyle: 'short' })}</dd></div></dl>
          <p>{task.closedByReply.reason || 'The reply was detected as resolving this task.'}</p>
          {task.closedByReply.excerpt ? <div className="task-email-body"><pre>{task.closedByReply.excerpt}</pre></div> : null}
        </section> : null}

        {task.jobOrderRequest || task.jobOrderId
          ? <TaskStaffingStatus task={task} accountById={accountById} unitById={unitById}
              roster={roster} canManage={canManage} readOnly={readOnly}
              onAddJobOrder={onAddJobOrder} onOpenJobOrders={onOpenJobOrders} />
          : null}

        {canManage && !readOnly && !task.jobOrderId ? <section className="task-routing-editor" aria-labelledby="task-routing-heading">
          <h3 id="task-routing-heading">Account routing</h3>
          <div className="task-manager-controls">
            <label><span>Account</span><select value={routingAccountId} onChange={(event) => {
              setRoutingAccountId(event.target.value); setRoutingUnitId(''); setFeedback('');
            }}>
              <option value="">No account</option>{branchAccounts.map((account) => <option key={account.id} value={account.id}>
                {account.name}{account.active === false ? ' · archived' : ''}</option>)}</select></label>
            <label><span>Sub-account</span><select value={routingUnitId} disabled={!routingAccountId} onChange={(event) => {
              setRoutingUnitId(event.target.value); setFeedback('');
            }}>
              <option value="">{branchUnits.length ? 'Parent account' : 'No active sub-accounts'}</option>
              {unavailableRoutingUnit ? <option value={routingUnitId} disabled>{unavailableRoutingUnit.name} · unavailable</option> : null}
              {branchUnits.map((unit) => <option key={unit.id} value={unit.id}>{unit.name}</option>)}</select></label>
            <button type="button" disabled={!routingChanged} onClick={confirmRouting}>Confirm routing</button>
          </div>
        </section> : null}

        {isEmailTask ? <section className="task-email-detail" aria-labelledby="task-email-heading">
          <div className="task-email-heading"><h3 id="task-email-heading">Original email request</h3>
            {outlookUrl ? <a href={outlookUrl} target="_blank" rel="noreferrer">Open in Outlook <ExternalLink size={14} /></a> : null}</div>
          <dl><EmailAddressRows from={emailFrom} to={emailTo} cc={emailCc} rosterByEmail={rosterByEmail} />
            <div><dt>Subject</dt><dd>{emailSubject}</dd></div>
            <div><dt>Received</dt><dd>{safeCentralTime(receivedAt, 'Unknown', { dateStyle: 'medium', timeStyle: 'short' })}</dd></div></dl>
          {emailState === 'loading' ? <p className="task-email-loading" role="status"><RefreshCw className="spin" size={15} /> Loading email contents…</p> : null}
          {emailState === 'error' ? <p className="task-email-error" role="alert">Email contents could not be loaded. The Outlook link is still available.</p> : null}
          {emailState === 'missing' && !bodyText ? <p className="task-email-missing">Email contents were not retained for this task.</p> : null}
          {bodyText ? <div className="task-email-body"><pre>{bodyText}</pre>
            {emailDetails?.isTruncated ? <p>Message shortened for the board. Open Outlook to read the complete email.</p> : null}</div> : null}
        </section> : null}

        {isEmailTask ? <section className="task-email-detail task-thread-messages" aria-labelledby="task-thread-heading">
          <h3 id="task-thread-heading">Email replies{task.threadUpdateCount > 0 ? ` (${task.threadUpdateCount})` : ''}</h3>
          {messageState === 'loading' ? <p className="task-email-loading" role="status"><RefreshCw className="spin" size={15} /> Loading email replies…</p> : null}
          {messageState === 'error' ? <p className="task-email-error" role="alert">Email replies could not be loaded. Close and reopen this task to try again.</p> : null}
          {messageState === 'ready' && !threadMessages.length ? <p className="task-email-missing">No email replies have been captured for this task.</p> : null}
          {threadMessages.length >= 100 ? <p className="task-email-missing">Showing the latest 100 replies, oldest first. Open Outlook for the complete conversation.</p> : null}
          {chronologicalMessages.map((message) => <TaskEmailMessage key={message.id} message={message} rosterByEmail={rosterByEmail} />)}
        </section> : null}
      </div>

      <footer className="task-detail-controls">
        <div className="task-detail-primary-actions">
          {canClaim ? <button type="button" className="task-claim is-primary" disabled={claiming} onClick={claim}>{claiming ? 'Claiming…' : 'Claim task'}</button> : null}
          <button type="button" disabled={readOnly} onClick={() => onToggle(task)}>{isTaskComplete(task) ? 'Reopen task' : 'Mark complete'}</button>
          {feedback ? <span className="task-action-feedback" role="status">{feedback}</span> : null}
        </div>
        {canManage && !readOnly ? <div className="task-manager-controls">
          <label><span>Owner</span><select value={task.assigneeId || ''} onChange={(event) => onPatch(task.id, {
            assigneeId: event.target.value || null,
          })}><option value="">Unassigned</option>{task.assigneeId && !eligibleOwners.some((person) => person.id === task.assigneeId)
              ? <option value={task.assigneeId} disabled>{owner?.name || 'Current owner'} · not in branch</option> : null}
            {eligibleOwners.map((person) => <option key={person.id} value={person.id}>{person.name}</option>)}</select></label>
          <label><span>Priority</span><select value={task.priority || 'normal'} onChange={(event) => onPatch(task.id, { priority: event.target.value })}>
            {Object.entries(PRIORITIES).map(([id, item]) => <option key={id} value={id}>{item.label}</option>)}</select></label>
        </div> : <div className="task-owner-summary"><span className="owner-mark" style={{ '--owner-color': userMarker(owner) }} />
          <span>{owner?.name || 'Unassigned'}</span></div>}
      </footer>
    </aside>
  </div>;
}

/** From/To/Cc rows. A teammate's message always shows who it went to. */
function EmailAddressRows({ from, to, cc, rosterByEmail }) {
  const fromTeam = rosterByEmail.has(emailAddressOf(from));
  const toLabel = recipientLabels(to, rosterByEmail);
  const ccLabel = recipientLabels(cc, rosterByEmail);
  return <>
    <div><dt>From</dt><dd>{from || 'Unknown sender'}{fromTeam ? <span className="task-email-team-tag">Team</span> : null}</dd></div>
    {toLabel !== null || fromTeam ? <div className={fromTeam ? 'is-team-recipients' : undefined}><dt>To</dt>
      <dd>{toLabel === null ? 'Not captured' : toLabel || 'No To recipients'}</dd></div> : null}
    {ccLabel ? <div><dt>Cc</dt><dd>{ccLabel}</dd></div> : null}
  </>;
}

function TaskEmailMessage({ message, rosterByEmail }) {
  const outlookUrl = safeExternalUrl(message.webLink);
  const fromTeam = message.direction === 'outbound' || rosterByEmail.has(emailAddressOf(message.from));
  return <article className="task-thread-message">
    <div className="task-email-heading"><h4>{fromTeam ? 'Team reply' : 'Incoming reply'}</h4>
      {outlookUrl ? <a href={outlookUrl} target="_blank" rel="noreferrer">Open in Outlook <ExternalLink size={14} /></a> : null}</div>
    <dl><EmailAddressRows from={message.from} to={message.to} cc={message.cc} rosterByEmail={rosterByEmail} />
      <div><dt>Subject</dt><dd>{message.subject || '(No subject)'}</dd></div>
      <div><dt>{message.direction === 'outbound' ? 'Sent' : 'Received'}</dt><dd>{safeCentralTime(message.receivedAt, 'Unknown', { dateStyle: 'medium', timeStyle: 'short' })}</dd></div></dl>
    {message.bodyText ? <div className="task-email-body"><pre>{message.bodyText}</pre>
      {message.isTruncated ? <p>Message shortened for the board. Open Outlook to read the complete email.</p> : null}</div>
      : <p className="task-email-missing">Message contents were not retained.</p>}
  </article>;
}

function TaskStaffingStatus({
  task, accountById, unitById, roster, canManage, readOnly, onAddJobOrder, onOpenJobOrders,
}) {
  const [addState, setAddState] = useState('idle');
  const request = task.jobOrderRequest && typeof task.jobOrderRequest === 'object'
    ? task.jobOrderRequest
    : null;
  const exactHeadcount = Number.isInteger(request?.headcount)
    && request.headcount >= 1
    && request.headcount <= 200;
  const route = jobOrderRouteForTask(task, accountById, unitById);
  const routingReady = Boolean(route);
  const emailProvenanceReady = task.source === 'email'
    && typeof task.sourceEmail?.messageId === 'string'
    && Boolean(task.sourceEmail.messageId)
    && typeof task.sourceEmail?.conversationId === 'string'
    && Boolean(task.sourceEmail.conversationId);
  const canAdd = canManage && !readOnly && !task.jobOrderId
    && exactHeadcount && routingReady && emailProvenanceReady && Boolean(onAddJobOrder);
  const facts = request ? [
    ['Headcount', exactHeadcount ? `${request.headcount} opening${request.headcount === 1 ? '' : 's'}` : 'Not stated exactly'],
    ['Role', request.role || 'Not provided'],
    ['Shift', request.shift || 'Not provided'],
    ['Days', request.days || 'Not provided'],
    ['Hours', request.hours || 'Not provided'],
    ['Pay', typeof request.pay === 'number' && Number.isFinite(request.pay)
      ? `$${request.pay.toFixed(2)} / hr`
      : 'Not provided'],
  ] : [];

  useEffect(() => setAddState('idle'), [task.id]);

  async function addOpenings() {
    if (!canAdd || addState === 'adding' || addState === 'saved') return;
    setAddState('adding');
    const added = await onAddJobOrder(task);
    setAddState(added ? 'saved' : 'error');
  }

  let pendingMessage = '';
  if (!routingReady && !exactHeadcount) {
    pendingMessage = 'No order was created because account routing is unresolved and the email did not state one exact headcount.';
  } else if (!routingReady) {
    pendingMessage = task.needsAccountReview
      ? 'No order was created because the account or location still needs routing review.'
      : 'No order was created because the task is not linked to an exact account.';
  } else if (!exactHeadcount) {
    pendingMessage = 'No order was created because the email did not state one exact headcount.';
  } else if (!emailProvenanceReady) {
    pendingMessage = 'Account routing and headcount are complete, but the source email identifiers needed for a safe link are missing.';
  } else if (canAdd) {
    pendingMessage = 'Account routing and headcount are ready for a safe fallback.';
  } else {
    pendingMessage = 'The account and headcount appear complete, but ingest did not record a linked job order.';
  }

  return <section className="task-staffing-status" aria-labelledby="task-staffing-heading">
    <div className="task-staffing-heading"><h3 id="task-staffing-heading">Staffing request</h3><Briefcase size={16} /></div>
    {facts.length ? <dl className="task-staffing-facts">{facts.map(([label, value]) => <div key={label}>
      <dt>{label}</dt><dd>{value}</dd>
    </div>)}</dl> : null}
    {task.jobOrderId ? <div className="task-staffing-result is-linked">
      <div><strong>Added to Job orders</strong><span>Account routing is locked so this task stays aligned with its linked order.</span></div>
      {onOpenJobOrders ? <button type="button" onClick={onOpenJobOrders}><Briefcase size={14} /> View Job orders</button> : null}
    </div> : <div className="task-staffing-result is-pending"><AlertTriangle size={16} />
      <div><strong>Not added automatically</strong><span>{pendingMessage}</span></div>
      {canAdd ? <button type="button" disabled={addState === 'adding' || addState === 'saved'} onClick={addOpenings}>
        <Plus size={14} /> {addState === 'adding' ? 'Adding…' : addState === 'saved' ? 'Added · syncing…'
          : `Add ${request.headcount} opening${request.headcount === 1 ? '' : 's'}`}
      </button> : null}
      {addState === 'error' ? <span className="task-staffing-error" role="alert">Could not add the openings. Refresh and try again.</span> : null}
    </div>}
  </section>;
}

function WallView({
  tasks, accounts, accountById, roster, branchById, aggregateMode, now,
  onOpenTask,
}) {
  const rosterById = new Map(roster.map((person) => [person.id, person]));
  const categories = TASK_CATEGORIES.map((category) => ({
    ...category, tasks: tasks.filter((task) => classifyTaskCategory(task) === category.id),
  }));

  return <div className="wall-viewport" aria-label="Active tasks">
    <div className="wall-category-grid">{categories.map((category) => <WallCategory key={category.id} category={category}>
      {category.tasks.map((task) => {
      const priority = effectivePriority(task, accounts, accountById);
      const branch = branchById.get(task.branchId);
      const rosterOwner = rosterById.get(task.assigneeId);
      const validOwner = isValidTaskOwner(rosterOwner, task.branchId);
      const formerOwner = Boolean(task.assigneeId && !validOwner);
      const unassigned = !task.assigneeId;
      const age = taskAge(task, now);
      const createdAt = Number(task.createdAt);
      const dateTime = Number.isFinite(createdAt) ? new Date(createdAt).toISOString() : undefined;
      const ownerLabel = validOwner ? rosterOwner.name : formerOwner ? 'Former owner' : 'Unassigned';
      const branchLabel = branch?.name || branch?.code || task.branchId;
      return <button type="button" key={task.id} data-task-id={task.id}
        className={`wall-task is-${priority}${unassigned ? ' is-unassigned' : ''}${formerOwner ? ' is-former' : ''}`}
        style={{ '--owner-color': validOwner ? userMarker(rosterOwner) : formerOwner ? 'var(--board-red)' : 'var(--board-amber)' }}
        onClick={() => onOpenTask(task.id)} aria-haspopup="dialog"
        aria-label={`${task.title}, ${age}, ${ownerLabel}${aggregateMode ? `, ${branchLabel}` : ''}${priority === 'high' ? ', hot priority' : ''}`}>
        <span className="wall-task-rail" aria-hidden="true" />
        <strong className="wall-task-title">{task.title}</strong>
        <time className="wall-task-age" dateTime={dateTime} title={age} aria-label={age}>
          <span className="wall-label-full">{age}</span><span className="wall-label-short" aria-hidden="true">{age.split(' ')[0]}</span>
        </time>
        <span className="wall-task-identity" title={ownerLabel}>
          <span className="wall-label-full">{ownerLabel}</span>
          <span className="wall-label-short" aria-hidden="true">{validOwner ? personInitials(rosterOwner) : formerOwner ? 'Former' : 'Unassigned'}</span>
        </span>
        {priority === 'high' ? <span className="wall-task-hot" title="Hot priority"><AlertTriangle size={14} /><span>Hot</span></span> : null}
        {aggregateMode ? <span className="wall-task-branch" title={branch?.name || task.branchId}>
          {branch?.code || task.branchId}</span> : null}
      </button>;
      })}
    </WallCategory>)}</div>
  </div>;
}

function WallCategory({ category, children }) {
  const sectionRef = useRef(null);
  const gridRef = useRef(null);
  const [dense, setDense] = useState(false);

  useEffect(() => {
    const section = sectionRef.current;
    const grid = gridRef.current;
    let frame;
    const measure = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const style = getComputedStyle(grid);
        // Always measure the one-card layout, even when two-up is active. This
        // prevents a short two-up column from switching back and oscillating.
        const cardHeight = parseFloat(style.getPropertyValue('--wall-single-card-height'));
        const gap = parseFloat(style.rowGap) || 0;
        const available = window.innerHeight - (grid.getBoundingClientRect().top + window.scrollY) - 12;
        const singleHeight = category.tasks.length * (cardHeight + gap) - gap;
        setDense(window.innerWidth >= 1200 && grid.clientWidth >= 400 && singleHeight > available);
      });
    };
    const observer = new ResizeObserver(measure);
    observer.observe(section);
    observer.observe(section.closest('main'));
    window.addEventListener('resize', measure);
    measure();
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, [category.tasks.length]);

  return <section ref={sectionRef} className={`queue-category wall-category is-${category.id}${dense ? ' is-dense' : ''}`}
    data-category={category.id} aria-labelledby={`wall-${category.id}-heading`}>
    <header className="queue-category-header"><div className="queue-category-copy">
      <h2 id={`wall-${category.id}-heading`}>{category.label}</h2>
    </div><strong className="queue-category-count">{category.tasks.length}<span className="sr-only"> open tasks</span></strong></header>
    <div ref={gridRef} className="wall-grid">{children}</div>
    {!category.tasks.length ? <p className="queue-category-empty">All clear</p> : null}
  </section>;
}

function EmptyBoard({ selectedDate }) {
  return <div className="empty-board"><Check size={24} /><h2>No tasks for {formatCentralDate(selectedDate)}</h2>
    <p>Incoming email and manual tasks for this date will appear here.</p></div>;
}

function TeamControls({ roster, branches, todayKey, selectedDate, onMarkOut, onBulk, onSwitchPerson }) {
  const [branchId, setBranchId] = useState(branches[0]?.id || '');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  useEffect(() => {
    if (!branches.some((branch) => branch.id === branchId)) {
      setBranchId(branches[0]?.id || ''); setFrom(''); setTo('');
    }
  }, [branchId, branches]);
  const today = selectedDate === todayKey;
  const team = roster.filter((person) => person.branchIds?.includes(branchId));
  return <div className="team-controls">
    {branches.length > 1 ? <label className="team-branch-select"><span>Team branch</span><select value={branchId} onChange={(event) => {
      setBranchId(event.target.value); setFrom(''); setTo('');
    }}>{branches.map((branch) => <option key={branch.id} value={branch.id}>{branch.code} · {branch.name}</option>)}</select></label> : null}
    <div className="attendance-strip"><span>Today’s team</span>
    {team.map((person) => { const out = isOutToday(person, todayKey); return (
      <button type="button" key={person.id} className={out ? 'is-out' : ''} disabled={!today} onClick={() => onMarkOut(person)}>
        <span className="owner-mark" style={{ '--owner-color': userMarker(person) }} />{person.name}<small>{out ? 'Out' : 'In'}</small></button>); })}</div>
    <div className="bulk-reassign"><span>Move open work</span><select value={from} onChange={(event) => setFrom(event.target.value)} aria-label="Move tasks from">
      <option value="">From person</option>{team.map((person) => <option key={person.id} value={person.id}>{person.name}</option>)}</select>
      <ArrowRight size={14} /><select value={to} onChange={(event) => setTo(event.target.value)} aria-label="Move tasks to">
        <option value="">Unassigned</option>{team.map((person) => <option key={person.id} value={person.id}>{person.name}</option>)}</select>
      <button type="button" disabled={!from || from === to || !branchId} onClick={() => onBulk(from, to, branchId)}>Move</button></div>
    {!isConfigured ? <button type="button" className="switch-person" onClick={onSwitchPerson}>Switch preview user</button> : null}</div>;
}

function AddTaskDialog({ db, visibleBranchIds, selectedDate, onClose, onSave }) {
  const [title, setTitle] = useState('');
  const [branchId, setBranchId] = useState(visibleBranchIds[0] || '');
  const [accountId, setAccountId] = useState('');
  const [accountUnitId, setAccountUnitId] = useState('');
  const [detail, setDetail] = useState('');
  const [priority, setPriority] = useState('normal');
  const [assignee, setAssignee] = useState('auto');
  const [busy, setBusy] = useState(false);
  const submission = useRef({ id: makeId(), createdAt: Date.now() });
  const dialogRef = useRef(null);
  const unitById = useMemo(
    () => new Map((db.accountUnits || []).map((unit) => [unit.id, unit])),
    [db.accountUnits],
  );
  const branchAccounts = db.accounts.filter((item) => item.branchId === branchId && item.active !== false);
  const selectedAccount = branchAccounts.find((item) => item.id === accountId);
  const branchUnits = (db.accountUnits || []).filter((item) => item.branchId === branchId
    && item.accountId === accountId && activeUnitPath(item, unitById));
  const selectedUnit = branchUnits.find((item) => item.id === accountUnitId);
  const accountOwner = selectedUnit?.ownerId || selectedAccount?.ownerId;
  const ownerName = db.users.find((person) => person.id === accountOwner)?.name;
  useEffect(() => {
    const previous = document.activeElement;
    const dialog = dialogRef.current;
    dialog?.querySelector('input')?.focus();
    const onKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key !== 'Tab' || !dialog) return;
      const focusable = [...dialog.querySelectorAll('button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled)')];
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      previous?.focus?.();
    };
  }, []);
  async function submit(event) {
    event.preventDefault();
    if (!title.trim() || !branchId || busy) return;
    setBusy(true);
    const legacyAccount = selectedAccount
      ? `${selectedAccount.name}${selectedUnit ? ` · ${selectedUnit.name}` : ''}`
      : null;
    const saved = await onSave({ ...submission.current, title, branchId, account: legacyAccount,
      accountId: selectedAccount?.id || null, accountName: selectedAccount?.name || null,
      accountUnitId: selectedUnit?.id || null, accountUnitName: selectedUnit?.name || null,
      detail, priority,
      assigneeId: assignee === 'auto' ? undefined : (assignee || null) });
    if (!saved) setBusy(false);
  }
  return <div className="dialog-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
    <form ref={dialogRef} className="task-dialog" onSubmit={submit} role="dialog" aria-modal="true" aria-labelledby="add-task-title">
      <header><div><span>Add to</span><h2 id="add-task-title">{formatCentralDate(selectedDate)}</h2></div>
        <button type="button" onClick={onClose} aria-label="Close"><X size={20} /></button></header>
      <label><span>Task</span><input value={title} onChange={(event) => setTitle(event.target.value)} placeholder="What needs to happen?" required /></label>
      {visibleBranchIds.length > 1 ? <label><span>Branch</span><select value={branchId} onChange={(event) => { setBranchId(event.target.value); setAccountId(''); setAccountUnitId(''); setAssignee('auto'); }}>
        {db.branches.filter((branch) => visibleBranchIds.includes(branch.id)).map((branch) => <option key={branch.id} value={branch.id}>{branch.name}</option>)}</select></label> : null}
      <div className="dialog-grid"><label><span>Account</span><select value={accountId} onChange={(event) => { setAccountId(event.target.value); setAccountUnitId(''); setAssignee('auto'); }}>
        <option value="">No account</option>{branchAccounts.map((item) => <option key={item.id} value={item.id}>{item.name}{item.isPriority ? ' · priority' : ''}</option>)}</select></label>
        <label><span>Location / department</span><select value={accountUnitId} disabled={!accountId || !branchUnits.length} onChange={(event) => { setAccountUnitId(event.target.value); setAssignee('auto'); }}>
          <option value="">{branchUnits.length ? 'Account-wide' : 'No sub-accounts'}</option>{branchUnits.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label></div>
      <label><span>Priority</span><select value={priority} onChange={(event) => setPriority(event.target.value)}>
        {Object.entries(PRIORITIES).map(([id, item]) => <option key={id} value={id}>{item.label}</option>)}</select></label>
      <label><span>Owner</span><select value={assignee} onChange={(event) => setAssignee(event.target.value)}>
        <option value="auto">{ownerName ? `Account owner · ${ownerName}` : 'Auto · leave unassigned'}</option><option value="">Unassigned</option>
        {db.users.filter((person) => person.active !== false && person.branchIds.includes(branchId)).map((person) => <option key={person.id} value={person.id}>{person.name}</option>)}</select></label>
      <label><span>Details <em>optional</em></span><textarea value={detail} onChange={(event) => setDetail(event.target.value)} rows={3} placeholder="Context the team needs to act" /></label>
      <footer><button type="button" onClick={onClose}>Cancel</button><button type="submit" className="is-primary" disabled={!title.trim() || busy}>{busy ? 'Adding…' : 'Add task'}</button></footer>
    </form></div>;
}

function SetupPanel({ db, me, isAdmin, canManage, personal, visibleBranchIds, createRecord, updateRecord, deleteRecord, createBranch, onBack }) {
  const [tab, setTab] = useState(canManage ? 'accounts' : 'personal');
  const activeTab = !canManage ? 'personal' : tab === 'branches' && !isAdmin ? 'accounts' : tab;
  const accounts = db.accounts.filter((item) => visibleBranchIds.includes(item.branchId));
  const people = db.users.filter((person) => isAdmin || person.branchIds.some((id) => visibleBranchIds.includes(id)));
  const tabs = [
    ...(canManage ? [['accounts', 'Accounts and routing'], ['people', 'People and access']] : []),
    ...(isAdmin ? [['branches', 'Branches']] : []),
    ['personal', 'Personal'],
  ];
  return <section className="setup-panel"><header><button type="button" onClick={onBack}><ArrowLeft size={16} /> Back to board</button>
    <div><span>BranchSuite</span><h1>Settings</h1></div></header>
    <div className="setup-tabs" role="group" aria-label="Settings categories">{tabs.map(([id, label]) =>
      <button key={id} type="button" aria-pressed={activeTab === id} className={activeTab === id ? 'is-active' : ''}
        onClick={() => setTab(id)}>{label}</button>)}</div>
    {activeTab === 'personal' ? <PersonalSettings me={me} connection={personal.connection} mode={personal.mode} onMode={personal.chooseMode} />
      : activeTab === 'accounts' && canManage ? <AccountSetup db={db} accounts={accounts} visibleBranchIds={visibleBranchIds} createRecord={createRecord} updateRecord={updateRecord} />
      : activeTab === 'branches' && isAdmin ? <BranchSetup branches={db.branches} me={me} createBranch={createBranch} onPeople={() => setTab('people')} />
      : activeTab === 'people' && canManage ? <PeopleSetup db={db} people={people} me={me} isAdmin={isAdmin} visibleBranchIds={visibleBranchIds} createRecord={createRecord} updateRecord={updateRecord} deleteRecord={deleteRecord} /> : null}
    <p className="setup-note">Signed in as {me.name} · {ROLES[me.role]}</p></section>;
}

function BranchSetup({ branches, me, createBranch, onPeople }) {
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState('');
  const [saved, setSaved] = useState('');
  async function submit(event) {
    event.preventDefault();
    if (busy) return;
    setBusy(true); setProblem(''); setSaved('');
    try {
      await createBranch({ code, name });
      setSaved(`Branch ${code.trim()} added. You now have access. Use People and access to add your team.`);
      setCode(''); setName('');
    } catch (error) { setProblem(error.message || 'The branch could not be added. Please try again.'); }
    finally { setBusy(false); }
  }
  return <div className="branch-setup">
    <h2>Add branch</h2><p>Enter the branch number and location. You will receive access when it is created.</p>
    <form className="inline-add-form branch-add-form" onSubmit={submit}>
      <label><span>Branch number</span><input value={code} onChange={(event) => setCode(event.target.value)} inputMode="numeric" pattern="[0-9]{1,20}" maxLength={20} required disabled={busy} placeholder="30088" /></label>
      <label><span>Branch name</span><input value={name} onChange={(event) => setName(event.target.value)} maxLength={120} required disabled={busy} placeholder="St. Louis, MO" /></label>
      <button type="submit" disabled={busy || !code.trim() || !name.trim()}>{busy ? 'Adding…' : 'Add branch'}</button>
    </form>
    {problem ? <p className="form-problem" role="alert">{problem}</p> : null}
    {saved ? <p role="status">{saved}</p> : null}
    <div className="branch-directory">{[...branches].sort((a, b) => String(a.code).localeCompare(String(b.code), undefined, { numeric: true })).map((branch) => <div key={branch.id}>
      <span><strong>{branch.code} · {branch.name}</strong><small>{me.branchIds?.includes(branch.id) ? 'You have access' : 'Access not assigned to you'}</small></span>
      <button type="button" onClick={onPeople}>Manage access</button>
    </div>)}</div>
  </div>;
}

function CommitInput({ value, onCommit, normalize = (next) => next.trim(), required = false, ...props }) {
  const [draft, setDraft] = useState(value || '');
  useEffect(() => setDraft(value || ''), [value]);
  function commit() {
    const next = normalize(draft);
    if (required && !String(next || '').trim()) { setDraft(value || ''); return; }
    if (next !== value) {
      const result = onCommit(next);
      if (result === false) setDraft(value || '');
      else if (result && typeof result.then === 'function') {
        result.then((saved) => { if (saved === false) setDraft(value || ''); })
          .catch(() => setDraft(value || ''));
      }
    }
    if (next !== draft) setDraft(next);
  }
  return <input {...props} required={required} value={draft} onChange={(event) => setDraft(event.target.value)} onBlur={commit}
    onKeyDown={(event) => { if (event.key === 'Enter') event.currentTarget.blur(); }} />;
}

function routingPreview(sender, accounts, units, contacts) {
  const email = normalizeEmail(sender);
  if (!email) return null;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { tone: 'warning', label: 'Enter a complete email address', detail: 'Routing uses the normalized sender address.' };
  }
  const activeAccounts = accounts.filter((account) => account.active !== false);
  const activeAccountIds = new Set(activeAccounts.map((account) => account.id));
  const activeUnits = units.filter((unit) => unit.active !== false && activeAccountIds.has(unit.accountId));
  const exact = contacts.filter((contact) => contact.active !== false
    && activeAccountIds.has(contact.accountId)
    && normalizeEmail(contact.emailLower || contact.email) === email);
  if (exact.length) {
    const accountIds = [...new Set(exact.map((contact) => contact.accountId))];
    if (accountIds.length !== 1) {
      return { tone: 'warning', label: 'Needs review', detail: `${exact.length} active contact records span more than one parent account.` };
    }
    const account = activeAccounts.find((item) => item.id === accountIds[0]);
    const contactUnitIds = new Set(exact.flatMap((contact) => contact.accountUnitIds || []));
    const matchedUnits = activeUnits.filter((unit) => unit.accountId === account.id && contactUnitIds.has(unit.id));
    if (matchedUnits.length === 1) {
      return { tone: 'success', label: `${account.name} · ${matchedUnits[0].name}`,
        detail: 'Exact contact match routes unambiguously to this location or department.' };
    }
    if (matchedUnits.length > 1) {
      return { tone: 'warning', label: `${account.name} · needs review`,
        detail: 'The contact covers multiple sub-accounts, so message context must choose one.' };
    }
    const accountUnits = activeUnits.filter((unit) => unit.accountId === account.id);
    return accountUnits.length
      ? { tone: 'warning', label: `${account.name} · needs review`, detail: 'The contact is account-wide and does not designate a specific sub-account.' }
      : { tone: 'success', label: account.name, detail: 'Exact contact match routes to this parent account.' };
  }
  const domain = email.split('@')[1];
  const domainMatches = activeAccounts.filter((account) => (account.domains || []).some((item) => normalizeDomain(item) === domain));
  if (domainMatches.length === 1) {
    const possibleUnits = activeUnits.filter((unit) => unit.accountId === domainMatches[0].id);
    return possibleUnits.length
      ? { tone: 'warning', label: `${domainMatches[0].name} · needs review`, detail: 'The domain identifies the parent account only; it will not guess a location or department.' }
      : { tone: 'success', label: domainMatches[0].name, detail: 'The domain routes to this parent account, which has no sub-accounts.' };
  }
  if (domainMatches.length > 1) {
    return { tone: 'warning', label: 'Needs review', detail: `The domain is shared by ${domainMatches.length} parent accounts.` };
  }
  return { tone: 'neutral', label: 'No routing match', detail: 'The task will remain unassigned to an account for manual review.' };
}

function AccountSetup({ db, accounts, visibleBranchIds, createRecord, updateRecord }) {
  const [search, setSearch] = useState('');
  const [routingEmail, setRoutingEmail] = useState('');
  const [routingBranchId, setRoutingBranchId] = useState(visibleBranchIds[0] || '');
  const [addingAccount, setAddingAccount] = useState(false);
  const [newAccountName, setNewAccountName] = useState('');
  const [newAccountBranchId, setNewAccountBranchId] = useState(visibleBranchIds.length === 1 ? visibleBranchIds[0] : '');
  const [accountProblem, setAccountProblem] = useState('');
  const branchOptions = useMemo(
    () => db.branches.filter((branch) => visibleBranchIds.includes(branch.id)),
    [db.branches, visibleBranchIds],
  );
  const units = useMemo(
    () => (db.accountUnits || []).filter((unit) => visibleBranchIds.includes(unit.branchId)),
    [db.accountUnits, visibleBranchIds],
  );
  const contacts = useMemo(
    () => (db.accountContacts || []).filter((contact) => visibleBranchIds.includes(contact.branchId)),
    [db.accountContacts, visibleBranchIds],
  );
  useEffect(() => {
    if (!visibleBranchIds.includes(routingBranchId)) setRoutingBranchId(visibleBranchIds[0] || '');
    if (visibleBranchIds.length === 1) setNewAccountBranchId(visibleBranchIds[0]);
    else if (!visibleBranchIds.includes(newAccountBranchId)) setNewAccountBranchId('');
  }, [newAccountBranchId, routingBranchId, visibleBranchIds]);
  const activeAccountIds = useMemo(
    () => new Set(accounts.filter((account) => account.active !== false).map((account) => account.id)),
    [accounts],
  );
  const duplicateEmailKeys = useMemo(() => {
    const counts = new Map();
    contacts.filter((contact) => contact.active !== false && activeAccountIds.has(contact.accountId)).forEach((contact) => {
      const email = normalizeEmail(contact.emailLower || contact.email);
      const key = `${contact.branchId}|${email}`;
      if (email) counts.set(key, (counts.get(key) || 0) + 1);
    });
    return new Set([...counts].filter(([, count]) => count > 1).map(([key]) => key));
  }, [activeAccountIds, contacts]);
  const routingAccounts = useMemo(
    () => accounts.filter((account) => account.branchId === routingBranchId),
    [accounts, routingBranchId],
  );
  const routingUnits = useMemo(
    () => units.filter((unit) => unit.branchId === routingBranchId),
    [routingBranchId, units],
  );
  const routingContacts = useMemo(
    () => contacts.filter((contact) => contact.branchId === routingBranchId),
    [contacts, routingBranchId],
  );
  const preview = useMemo(
    () => routingPreview(routingEmail, routingAccounts, routingUnits, routingContacts),
    [routingAccounts, routingContacts, routingEmail, routingUnits],
  );
  const shownAccounts = useMemo(() => {
    const needle = search.trim().toLocaleLowerCase();
    return accounts.filter((account) => {
      if (!needle) return true;
      const relatedUnits = units.filter((unit) => unit.accountId === account.id);
      const relatedContacts = contacts.filter((contact) => contact.accountId === account.id);
      return [account.name, account.accountNumber, ...(account.aliases || []), ...(account.domains || []),
        ...relatedUnits.flatMap((unit) => [unit.name, unit.accountNumber, ...(unit.aliases || [])]),
        ...relatedContacts.flatMap((contact) => [contact.name, contact.email])]
        .filter(Boolean).some((value) => String(value).toLocaleLowerCase().includes(needle));
    }).sort((a, b) => Number(a.active === false) - Number(b.active === false)
      || String(a.name || '').localeCompare(String(b.name || '')));
  }, [accounts, contacts, search, units]);

  async function addAccount(event) {
    event.preventDefault();
    const name = newAccountName.trim();
    if (!name || !newAccountBranchId) {
      setAccountProblem('Choose a branch and enter an account name.');
      return;
    }
    if (accounts.some((account) => account.branchId === newAccountBranchId && account.active !== false
      && String(account.name || '').trim().toLocaleLowerCase() === name.toLocaleLowerCase())) {
      setAccountProblem('An active account with that name already exists in this branch.');
      return;
    }
    const now = Date.now();
    const created = await createRecord('accounts', { branchId: newAccountBranchId, name,
      aliases: [], domains: [], ownerId: null, isPriority: false, active: true, createdAt: now, updatedAt: now });
    if (!created) {
      setAccountProblem('The account could not be added. Check your access and try again.');
      return;
    }
    setNewAccountName('');
    setNewAccountBranchId(visibleBranchIds.length === 1 ? visibleBranchIds[0] : '');
    setAccountProblem('');
    setAddingAccount(false);
  }
  return <div className="account-setup">
    <div className="account-setup-toolbar"><label className="board-search"><Search size={15} /><span className="sr-only">Search accounts and contacts</span>
      <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search accounts, locations, contacts" />
      {search ? <button type="button" onClick={() => setSearch('')} aria-label="Clear account search"><X size={14} /></button> : null}</label>
      <button type="button" className="setup-add" onClick={() => { setAddingAccount(true); setAccountProblem(''); }}><Plus size={16} /> Add parent account</button></div>
    {addingAccount ? <form className="inline-add-form" onSubmit={addAccount}>
      <input value={newAccountName} onChange={(event) => setNewAccountName(event.target.value)} placeholder="Parent account name" aria-label="Parent account name" autoFocus />
      {branchOptions.length > 1 ? <select value={newAccountBranchId} onChange={(event) => setNewAccountBranchId(event.target.value)} aria-label="Account branch">
        <option value="">Choose branch</option>{branchOptions.map((branch) => <option key={branch.id} value={branch.id}>{branch.code} · {branch.name}</option>)}</select> : null}
      <button type="button" onClick={() => { setAddingAccount(false); setAccountProblem(''); }}>Cancel</button>
      <button type="submit" disabled={!newAccountName.trim() || !newAccountBranchId}>Add account</button>
      {accountProblem ? <p className="form-problem" role="alert">{accountProblem}</p> : null}</form> : null}
    <section className="routing-tester" aria-labelledby="routing-tester-title"><div><h2 id="routing-tester-title">Test sender routing</h2>
      <p>Exact contacts can select a sub-account. A domain alone only identifies the parent.</p></div>
      {branchOptions.length > 1 ? <label><span>Branch</span><select value={routingBranchId} onChange={(event) => setRoutingBranchId(event.target.value)}>
        {branchOptions.map((branch) => <option key={branch.id} value={branch.id}>{branch.code} · {branch.name}</option>)}</select></label> : null}
      <label><span>Sender email</span><input type="email" value={routingEmail} onChange={(event) => setRoutingEmail(event.target.value)} placeholder="person@customer.com" /></label>
      {preview ? <output className={`routing-preview is-${preview.tone}`}><strong>{preview.label}</strong><span>{preview.detail}</span></output> : null}</section>
    <div className="account-editor-list">{shownAccounts.map((account) => <AccountEditor key={account.id} account={account}
      db={db} units={units.filter((unit) => unit.accountId === account.id)} contacts={contacts.filter((contact) => contact.accountId === account.id)}
      siblingAccounts={accounts.filter((item) => item.branchId === account.branchId)}
      branchContacts={contacts.filter((contact) => contact.branchId === account.branchId && activeAccountIds.has(contact.accountId))}
      duplicateEmailKeys={duplicateEmailKeys} createRecord={createRecord} updateRecord={updateRecord} />)}</div>
    {!shownAccounts.length ? <p className="setup-empty">No accounts match this search.</p> : null}
  </div>;
}

function AccountEditor({ account, db, units, contacts, siblingAccounts, branchContacts, duplicateEmailKeys, createRecord, updateRecord }) {
  const active = account.active !== false;
  const [nameProblem, setNameProblem] = useState('');
  const branchPeople = db.users.filter((person) => person.active !== false && person.branchIds?.includes(account.branchId));
  const orderedUnits = useMemo(() => {
    const children = new Map();
    units.forEach((unit) => {
      const parent = unit.parentUnitId && units.some((item) => item.id === unit.parentUnitId) ? unit.parentUnitId : null;
      children.set(parent, [...(children.get(parent) || []), unit]);
    });
    const result = [];
    const visited = new Set();
    function visit(parentId, depth) {
      (children.get(parentId) || []).sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''))).forEach((unit) => {
        if (visited.has(unit.id)) return;
        visited.add(unit.id); result.push({ ...unit, depth }); visit(unit.id, depth + 1);
      });
    }
    visit(null, 0);
    units.forEach((unit) => { if (!visited.has(unit.id)) result.push({ ...unit, depth: 0 }); });
    return result;
  }, [units]);

  return <details className={`account-editor${active ? '' : ' is-archived'}`}>
    <summary><span><strong>{account.name || 'Unnamed account'}</strong><small>{units.filter((unit) => unit.active !== false).length} sub-accounts · {contacts.filter((contact) => contact.active !== false).length} contacts</small></span>
      <span>{account.accountNumber ? `#${account.accountNumber} · ` : ''}{active ? 'Active' : 'Archived'} <ChevronDown size={16} /></span></summary>
    <div className="account-editor-body">
      <div className="account-fields">
        <label><span>Parent account</span><CommitInput value={account.name} required aria-label="Parent account name"
          onCommit={(name) => {
            if (siblingAccounts.some((item) => item.id !== account.id && item.active !== false
              && String(item.name || '').trim().toLocaleLowerCase() === name.toLocaleLowerCase())) {
              setNameProblem('That active account name already exists in this branch.');
              return false;
            }
            setNameProblem('');
            return updateRecord('accounts', account.id, { name, updatedAt: Date.now() });
          }} />{nameProblem ? <small className="form-problem" role="alert">{nameProblem}</small> : null}</label>
        <label><span>Branch <em>fixed after creation</em></span><select value={account.branchId} disabled aria-label={`${account.name} branch`}>
          {db.branches.filter((branch) => branch.id === account.branchId).map((branch) => <option key={branch.id} value={branch.id}>{branch.code} · {branch.name}</option>)}</select></label>
        {account.accountNumber ? <label><span>Account number</span><input value={account.accountNumber} readOnly /></label> : null}
        <label><span>Owner</span><select value={account.ownerId || ''} disabled={!active} onChange={(event) => updateRecord('accounts', account.id, { ownerId: event.target.value || null, updatedAt: Date.now() })}>
          <option value="">No owner</option>{branchPeople.map((person) => <option key={person.id} value={person.id}>{person.name}</option>)}</select></label>
        <label><span>Aliases <em>comma separated</em></span><CommitInput value={(account.aliases || []).join(', ')} disabled={!active}
          onCommit={(value) => updateRecord('accounts', account.id, { aliases: parseList(value), updatedAt: Date.now() })} /></label>
        <label><span>Email domains <em>comma separated</em></span><CommitInput value={(account.domains || []).join(', ')} disabled={!active}
          normalize={(value) => parseList(value, normalizeDomain).join(', ')}
          onCommit={(value) => updateRecord('accounts', account.id, { domains: parseList(value, normalizeDomain), updatedAt: Date.now() })} /></label>
        <button type="button" disabled={!active} aria-pressed={account.isPriority} className={account.isPriority ? 'priority-account is-active' : 'priority-account'}
          onClick={() => updateRecord('accounts', account.id, { isPriority: !account.isPriority, updatedAt: Date.now() })}><Star size={14} /> Priority account</button>
        <button type="button" className="account-archive" onClick={() => updateRecord('accounts', account.id, active
          ? { active: false, archivedAt: Date.now(), updatedAt: Date.now() }
          : { active: true, archivedAt: null, updatedAt: Date.now() })}>{active ? 'Archive account' : 'Restore account'}</button>
      </div>

      <section className="account-units" aria-labelledby={`account-${account.id}-units`}><header><div><h3 id={`account-${account.id}-units`}>Locations and departments</h3>
        <p>Nested sub-accounts make shared customer domains safe to use.</p></div>{active ? <AddUnit account={account} units={units} createRecord={createRecord} /> : null}</header>
        <div>{orderedUnits.map((unit) => <AccountUnitEditor key={unit.id} unit={unit} depth={unit.depth} allUnits={units}
          people={branchPeople} parentActive={active} updateRecord={updateRecord} />)}</div>
        {!units.length ? <p className="setup-empty">No locations or departments yet.</p> : null}</section>

      <section className="account-contacts" aria-labelledby={`account-${account.id}-contacts`}><header><div><h3 id={`account-${account.id}-contacts`}>Contacts</h3>
        <p>Scope global contacts to the parent; scope operational contacts to one or more sub-accounts.</p></div>{active ? <AddContact account={account} units={units} contacts={branchContacts} createRecord={createRecord} /> : null}</header>
        <div>{contacts.map((contact) => <AccountContactEditor key={contact.id} contact={contact} units={units}
          branchContacts={branchContacts} parentActive={active}
          duplicate={active && contact.active !== false && duplicateEmailKeys.has(`${contact.branchId}|${normalizeEmail(contact.emailLower || contact.email)}`)} updateRecord={updateRecord} />)}</div>
        {!contacts.length ? <p className="setup-empty">No contacts yet.</p> : null}</section>
    </div>
  </details>;
}

function AddUnit({ account, units, createRecord }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [parentUnitId, setParentUnitId] = useState('');
  if (!open) return <button type="button" className="setup-add is-compact" onClick={() => setOpen(true)}><Plus size={14} /> Add sub-account</button>;
  async function submit(event) {
    event.preventDefault();
    if (!name.trim()) return;
    const now = Date.now();
    const created = await createRecord('accountUnits', { branchId: account.branchId, accountId: account.id,
      name: name.trim(), aliases: [], ownerId: null, parentUnitId: parentUnitId || null, active: true,
      createdAt: now, updatedAt: now });
    if (created) { setName(''); setParentUnitId(''); setOpen(false); }
  }
  return <form className="inline-add-form" onSubmit={submit}><input value={name} onChange={(event) => setName(event.target.value)} placeholder="Location or department" aria-label="Sub-account name" autoFocus />
    <select value={parentUnitId} onChange={(event) => setParentUnitId(event.target.value)} aria-label="Parent sub-account"><option value="">Top level</option>
      {units.filter((unit) => unit.active !== false).map((unit) => <option key={unit.id} value={unit.id}>{unit.name}</option>)}</select>
    <button type="button" onClick={() => setOpen(false)}>Cancel</button><button type="submit" disabled={!name.trim()}>Add</button></form>;
}

function AccountUnitEditor({ unit, depth, allUnits, people, parentActive, updateRecord }) {
  const active = unit.active !== false;
  const editable = parentActive && active;
  const descendants = useMemo(() => {
    const found = new Set();
    let changed = true;
    while (changed) {
      changed = false;
      allUnits.forEach((item) => {
        if (!found.has(item.id) && (item.parentUnitId === unit.id || found.has(item.parentUnitId))) {
          found.add(item.id); changed = true;
        }
      });
    }
    return found;
  }, [allUnits, unit.id]);
  const possibleParents = allUnits.filter((item) => item.id !== unit.id && !descendants.has(item.id) && item.active !== false);
  return <div className={`account-unit-row${active ? '' : ' is-archived'}`} style={{ '--unit-depth': depth }}>
    <div className="unit-name-field"><CommitInput value={unit.name} disabled={!editable} required aria-label="Sub-account name" onCommit={(name) => updateRecord('accountUnits', unit.id, { name, updatedAt: Date.now() })} />
      {unit.accountNumber ? <small>Account #{unit.accountNumber}</small> : null}</div>
    <select value={unit.parentUnitId || ''} disabled={!editable} onChange={(event) => updateRecord('accountUnits', unit.id, { parentUnitId: event.target.value || null, updatedAt: Date.now() })} aria-label={`${unit.name} parent`}>
      <option value="">Top level</option>{possibleParents.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select>
    <select value={unit.ownerId || ''} disabled={!editable} onChange={(event) => updateRecord('accountUnits', unit.id, { ownerId: event.target.value || null, updatedAt: Date.now() })} aria-label={`${unit.name} owner`}>
      <option value="">Use account owner</option>{people.map((person) => <option key={person.id} value={person.id}>{person.name}</option>)}</select>
    <CommitInput value={(unit.aliases || []).join(', ')} disabled={!editable} aria-label={`${unit.name} aliases`} placeholder="Aliases, comma separated"
      onCommit={(value) => updateRecord('accountUnits', unit.id, { aliases: parseList(value), updatedAt: Date.now() })} />
    <button type="button" className="account-archive" disabled={!parentActive} onClick={() => updateRecord('accountUnits', unit.id, active
      ? { active: false, archivedAt: Date.now(), updatedAt: Date.now() }
      : { active: true, archivedAt: null, updatedAt: Date.now() })}>{active ? 'Archive' : 'Restore'}</button>
  </div>;
}

function AddContact({ account, units, contacts, createRecord }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [scope, setScope] = useState('account');
  const [accountUnitIds, setAccountUnitIds] = useState([]);
  const [problem, setProblem] = useState('');
  const activeUnits = units.filter((unit) => unit.active !== false);
  if (!open) return <button type="button" className="setup-add is-compact" onClick={() => setOpen(true)}><Plus size={14} /> Add contact</button>;
  async function submit(event) {
    event.preventDefault();
    const emailLower = normalizeEmail(email);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailLower)) { setProblem('Enter a complete email address.'); return; }
    if (scope === 'unit' && !accountUnitIds.length) { setProblem('Choose at least one location or department.'); return; }
    const duplicate = contacts.some((contact) => contact.active !== false && normalizeEmail(contact.emailLower || contact.email) === emailLower);
    if (duplicate) { setProblem('That email already exists in this branch. Edit the existing contact instead.'); return; }
    const now = Date.now();
    const created = await createRecord('accountContacts', { branchId: account.branchId, accountId: account.id,
      accountUnitIds: scope === 'unit' ? accountUnitIds : [], name: name.trim(), email: emailLower,
      emailLower, scope, active: true, createdAt: now, updatedAt: now });
    if (created) { setOpen(false); setName(''); setEmail(''); setScope('account'); setAccountUnitIds([]); setProblem(''); }
  }
  return <form className="contact-add-form" onSubmit={submit}><div><input value={name} onChange={(event) => setName(event.target.value)} placeholder="Contact name" required />
    <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="person@customer.com" required /></div>
    <select value={scope} onChange={(event) => { const next = event.target.value; setScope(next); setAccountUnitIds(next === 'account' ? [] : accountUnitIds); }}>
      <option value="account">Entire parent account</option><option value="unit" disabled={!activeUnits.length}>Selected sub-accounts</option></select>
    {scope === 'unit' ? <UnitChecks units={activeUnits} selected={accountUnitIds} onChange={setAccountUnitIds} /> : null}
    {problem ? <p className="form-problem">{problem}</p> : null}<footer><button type="button" onClick={() => setOpen(false)}>Cancel</button><button type="submit">Add contact</button></footer></form>;
}

function UnitChecks({ units, selected, onChange, disabled = false }) {
  return <fieldset className="contact-unit-checks"><legend>Applies to</legend>{units.map((unit) => { const checked = selected.includes(unit.id); return (
    <label key={unit.id}><input type="checkbox" checked={checked} disabled={disabled} onChange={() => onChange(checked ? selected.filter((id) => id !== unit.id) : [...selected, unit.id])} />{unit.name}</label>); })}</fieldset>;
}

function AccountContactEditor({ contact, units, branchContacts, duplicate, parentActive, updateRecord }) {
  const active = contact.active !== false;
  const editable = parentActive && active;
  const activeUnits = units.filter((unit) => unit.active !== false);
  const selectedUnits = contact.accountUnitIds || [];
  const [problem, setProblem] = useState('');
  function setScope(scope) {
    updateRecord('accountContacts', contact.id, { scope,
      accountUnitIds: scope === 'unit' ? (selectedUnits.length ? selectedUnits : activeUnits.slice(0, 1).map((unit) => unit.id)) : [],
      updatedAt: Date.now() });
  }
  function setUnits(ids) {
    if (!ids.length) return;
    updateRecord('accountContacts', contact.id, { accountUnitIds: ids, updatedAt: Date.now() });
  }
  return <div className={`account-contact-row${active ? '' : ' is-archived'}${duplicate ? ' has-duplicate' : ''}`}>
    <CommitInput value={contact.name} disabled={!editable} required aria-label="Contact name" placeholder="Contact name"
      onCommit={(name) => updateRecord('accountContacts', contact.id, { name, updatedAt: Date.now() })} />
    <div className="contact-email-field"><CommitInput type="email" value={contact.email} disabled={!editable} required aria-label="Contact email"
      normalize={normalizeEmail} onCommit={(email) => {
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          setProblem('Enter a complete email address.');
          return false;
        }
        if (branchContacts.some((item) => item.id !== contact.id && item.active !== false
          && normalizeEmail(item.emailLower || item.email) === email)) {
          setProblem('That active email already exists in this branch.');
          return false;
        }
        setProblem('');
        return updateRecord('accountContacts', contact.id, { email, emailLower: email, updatedAt: Date.now() });
      }} />
      {problem ? <small role="alert"><AlertTriangle size={13} /> {problem}</small> : null}
      {duplicate ? <small role="alert"><AlertTriangle size={13} /> Duplicate active email</small> : null}</div>
    <select value={contact.scope || 'account'} disabled={!editable} onChange={(event) => setScope(event.target.value)} aria-label={`${contact.name || contact.email} scope`}>
      <option value="account">Entire account</option><option value="unit" disabled={!activeUnits.length}>Selected sub-accounts</option></select>
    {contact.scope === 'unit' ? <UnitChecks units={activeUnits} selected={selectedUnits} onChange={setUnits} disabled={!editable} /> : <span className="contact-scope-note">All {activeUnits.length || ''} sub-accounts</span>}
    <button type="button" className="account-archive" disabled={!parentActive} onClick={() => updateRecord('accountContacts', contact.id, active
      ? { active: false, archivedAt: Date.now(), updatedAt: Date.now() }
      : { active: true, archivedAt: null, updatedAt: Date.now() })}>{active ? 'Archive' : 'Restore'}</button>
  </div>;
}

/** Admins maintain the whole roster; a manager maintains their own branches. */
function PeopleSetup({ db, people, me, isAdmin, visibleBranchIds, createRecord, updateRecord, deleteRecord }) {
  const myBranchIds = isAdmin ? db.branches.map((branch) => branch.id) : (me?.branchIds || []);
  const rolesFor = (person) => Object.entries(ROLES)
    .filter(([id]) => isAdmin || id !== 'admin' || person.role === 'admin');
  return <div className="setup-list">{people.map((person) => { const editable = isAdmin || person.role !== 'admin'; return (
    <div className="setup-row setup-person" key={person.id}>
    <span className="owner-mark" style={{ '--owner-color': userMarker(person) }} /><span className="person-identity"><strong>{person.name}</strong><small>{person.email}</small></span>
    <select value={person.marker || 'none'} onChange={(event) => updateRecord('users', person.id, { marker: event.target.value })} aria-label={`${person.name} marker`}>
      {Object.entries(MARKERS).map(([id, item]) => <option key={id} value={id}>{item.label}</option>)}</select>
    <select value={person.role} disabled={!editable} onChange={(event) => updateRecord('users', person.id, { role: event.target.value })} aria-label={`${person.name} role`}>
      {rolesFor(person).map(([id, label]) => <option key={id} value={id}>{label}</option>)}</select>
    {editable ? <div className="branch-toggles">{db.branches.filter((branch) => myBranchIds.includes(branch.id)).map((branch) => { const enabled = person.branchIds.includes(branch.id); return (
      <button type="button" key={branch.id} className={enabled ? 'is-active' : ''} onClick={() => updateRecord('users', person.id, { branchIds: enabled ? person.branchIds.filter((id) => id !== branch.id) : [...person.branchIds, branch.id] })}>{branch.name}</button>); })}</div> : null}
    {isAdmin && person.id !== me?.id ? <RemovePerson person={person} deleteRecord={deleteRecord} /> : null}</div>); })}
    <AddPerson db={db} me={me} isAdmin={isAdmin} visibleBranchIds={visibleBranchIds} createRecord={createRecord} /></div>;
}

/** Two steps, because removing a person deletes their sign-in for good. */
function RemovePerson({ person, deleteRecord }) {
  const [state, setState] = useState('idle');
  const [problem, setProblem] = useState('');
  async function remove() {
    setState('working');
    setProblem('');
    try {
      if (isConfigured) await deleteBoardUser(person.id);
      else await deleteRecord('users', person.id);
      // The roster subscription drops the row, so there is nothing to reset.
    } catch (error) {
      setProblem(createBoardUserMessage(error, 'That person could not be removed. Try again.'));
      setState('idle');
    }
  }
  if (state === 'working') return <span className="person-remove-confirm" role="status">Removing…</span>;
  if (problem) {
    return <span className="person-remove-confirm" role="alert"><small>{problem}</small>
      <button type="button" className="person-remove" onClick={() => { setProblem(''); setState('confirm'); }}>Retry</button></span>;
  }
  if (state === 'confirm') {
    return <span className="person-remove-confirm"><strong>Remove?</strong>
      <button type="button" className="person-remove" onClick={remove}>Yes</button>
      <button type="button" onClick={() => setState('idle')}>No</button></span>;
  }
  return <button type="button" className="person-remove" onClick={() => setState('confirm')}
    aria-label={`Remove ${person.name}`}>Remove</button>;
}

function AddPerson({ db, me, isAdmin, visibleBranchIds, createRecord }) {
  // A manager can only staff the branches they belong to; the function enforces
  // the same limit, so a stale page cannot widen it.
  const allowedBranches = db.branches.filter((branch) => isAdmin || (me?.branchIds || []).includes(branch.id));
  const allowedRoles = Object.entries(ROLES).filter(([id]) => isAdmin || id !== 'admin');
  const emptyForm = () => {
    const first = allowedBranches.find((branch) => visibleBranchIds.includes(branch.id)) || allowedBranches[0];
    return { name: '', email: '', initials: '', role: 'member', marker: 'none', branchIds: first ? [first.id] : [] };
  };
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [problem, setProblem] = useState('');
  const [notice, setNotice] = useState('');
  const [saving, setSaving] = useState(false);
  if (!open) return <>
    <button type="button" className="setup-add" onClick={() => { setForm(emptyForm()); setProblem(''); setNotice(''); setOpen(true); }}><Plus size={16} /> Add person</button>
    {notice ? <p className="setup-add-notice" role="status">{notice}</p> : null}
  </>;
  function field(name, value) { setForm((current) => ({ ...current, [name]: value })); }
  async function savePerson(event) {
    event.preventDefault();
    if (saving) return;
    const person = { name: form.name.trim(), email: normalizeEmail(form.email), initials: form.initials.trim().toUpperCase(),
      role: form.role, marker: form.marker, branchIds: form.branchIds };
    if (!person.name || !person.email || !person.initials) { setProblem('Name, email, and initials are required.'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(person.email)) { setProblem('Enter a complete email address.'); return; }
    if (!person.branchIds.length) { setProblem('Choose at least one branch.'); return; }
    if (db.users.some((existing) => normalizeEmail(existing.email) === person.email)) { setProblem('That email is already on the roster.'); return; }
    setProblem('');
    setSaving(true);
    try {
      if (!isConfigured) {
        if (!(await createRecord('users', { ...person, outToday: false, outDate: null }))) {
          setProblem('That person could not be added. Try again.');
          return;
        }
        setNotice(`${person.name} was added.`);
      } else {
        const result = await createBoardUser(person);
        setNotice(result.reusedSignIn
          ? `${person.name} was added. They already had a sign-in, so their existing password still works.`
          : result.setupEmailSent
            ? `${person.name} was added. A password setup email was sent to ${person.email}.`
            : `${person.name} was added, but the setup email did not send. Ask them to use “Forgot your password” on the sign-in screen.`);
      }
      setOpen(false);
    } catch (error) {
      setProblem(createBoardUserMessage(error));
    } finally {
      setSaving(false);
    }
  }
  return <form className="add-person" onSubmit={savePerson}><h2>Add a person</h2>
    <p>{isConfigured
      ? 'Their sign-in is created for them, and they get an email to choose a password.'
      : 'Local mode: this person is added to this browser only.'}</p>
    <div className="dialog-grid"><input value={form.name} onChange={(event) => field('name', event.target.value)} placeholder="Name" />
      <input value={form.email} onChange={(event) => field('email', event.target.value)} placeholder="Work email" type="email" /></div>
    <div className="dialog-grid three"><input value={form.initials} onChange={(event) => field('initials', event.target.value)} placeholder="Initials" maxLength={4} />
      <select value={form.role} onChange={(event) => field('role', event.target.value)}>{allowedRoles.map(([id, label]) => <option key={id} value={id}>{label}</option>)}</select>
      <select value={form.marker} onChange={(event) => field('marker', event.target.value)}>{Object.entries(MARKERS).map(([id, item]) => <option key={id} value={id}>{item.label}</option>)}</select></div>
    <div className="branch-toggles">{allowedBranches.map((branch) => { const enabled = form.branchIds.includes(branch.id); return (
      <button type="button" key={branch.id} className={enabled ? 'is-active' : ''} onClick={() => field('branchIds', enabled ? form.branchIds.filter((id) => id !== branch.id) : [...form.branchIds, branch.id])}>{branch.name}</button>); })}</div>
    {problem ? <p className="form-problem">{problem}</p> : null}
    <footer><button type="button" onClick={() => setOpen(false)}>Cancel</button><button type="submit" className="is-primary">Add person</button></footer></form>;
}
