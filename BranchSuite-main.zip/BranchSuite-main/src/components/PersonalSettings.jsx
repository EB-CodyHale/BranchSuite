import React, { useState } from 'react';
import { Copy, Download, ExternalLink, Mail, ShieldCheck } from 'lucide-react';
import { app, isConfigured } from '../lib/firebaseApp';
import { managePersonalEmail } from '../lib/usePersonalBoard';

const LABELS = { 'awaiting-email': 'Waiting for first email', receiving: 'Email received', disconnected: 'Disconnected' };

export default function PersonalSettings({ me, connection, mode, onMode }) {
  const [credential, setCredential] = useState(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const endpoint = isConfigured ? `https://us-central1-${app.options.projectId}.cloudfunctions.net/ingestPersonalEmail` : 'Available after Firebase is configured';
  async function manage(action) {
    setBusy(true); setMessage('');
    try {
      const result = await managePersonalEmail(action);
      setCredential(action === 'connect' ? result : null);
      setMessage(action === 'connect'
        ? 'Your key is ready. Copy it now; it is shown only during this setup. Any previous key has stopped working.'
        : 'Disconnected. New email deliveries are blocked. Turn off the flow in Power Automate too. Your tasks are kept.');
    } catch (error) {
      setMessage(error.code === 'functions/not-found'
        ? 'Personal email setup is not deployed yet. Deploy the Personal Mode functions first.'
        : 'The connection could not be changed. Check your sign-in and try again.');
    } finally { setBusy(false); }
  }
  async function copy(value, label) {
    try { await navigator.clipboard.writeText(value); setMessage(`${label} copied.`); }
    catch { setMessage('Clipboard is unavailable. Select the value and copy it manually.'); }
  }
  return <section className="personal-settings">
    <header><span className="board-eyebrow">Personal Mode</span><h2>Your inbox. Your tasks.</h2>
      <p>Connect your work Outlook inbox to create tasks from emails that need your attention.</p></header>
    <div className="personal-privacy"><ShieldCheck size={19} /><span>Only you can see your personal tasks and emails. Combined view keeps them private.</span></div>
    <div className="personal-settings-grid">
      <section className="personal-settings-card"><h2>Board view</h2>
        <p>Choose where your personal tasks appear.</p>
        <div className="personal-view-options">{[['branch', 'Branch only', 'Show shared branch tasks.'], ['personal', 'Personal board', 'Show only your personal tasks.'], ['combined', 'Combined view', 'Show your personal tasks beside the selected branch tasks.']].map(([value, label, detail]) =>
          <label key={value}><input type="radio" name="personal-mode" value={value} checked={mode === value} onChange={() => onMode(value)} /><span><strong>{label}</strong><small>{detail}</small></span></label>)}</div>
      </section>
      <section className="personal-settings-card"><h2><Mail size={18} /> Outlook connection</h2>
        <p>{connection?.mailboxAddress || me.email}</p>
        <strong className="personal-connection-state">{isConfigured ? LABELS[connection?.status] || 'Not connected' : 'Local preview · Email connection unavailable'}</strong>
        {connection?.lastReceivedAt ? <p>Last successful delivery: {new Date(connection.lastReceivedAt).toLocaleString()}</p> : null}
        <p>This setup uses your own Power Automate account. No BranchSuite Azure subscription or app registration is needed.</p>
        <p>Power Automate must allow you to import flows and use the premium HTTP action. Your organization may restrict these.</p>
        <div className="personal-actions"><button type="button" className="primary-control" disabled={!isConfigured || busy} onClick={() => manage('connect')}>
          {busy ? 'Updating…' : connection?.status && connection.status !== 'disconnected' ? 'Generate replacement key' : 'Connect personal email'}</button>
          {connection?.status && connection.status !== 'disconnected' ? <button type="button" className="secondary-control" disabled={busy} onClick={() => manage('disconnect')}>Disconnect</button> : null}</div>
        {connection?.status && connection.status !== 'disconnected' ? <small>Generating a replacement key immediately disables the previous key. Update your flow with the new key.</small> : null}
      </section>
    </div>
    <section className="personal-settings-card"><h2>Set up your email flow</h2>
      <p>Download the starter package, then import it into Power Automate. You’ll choose your Outlook connection and paste three settings. The package still needs its first import check in your organization.</p>
      <ol className="personal-setup-steps">
        <li><strong>Download and import the flow.</strong><p>In Power Automate, open My flows → Import → Import Package (Legacy). Upload the ZIP, choose Create as new, and select your own Office 365 Outlook connection.</p>
          <div className="personal-actions"><a className="secondary-control" href="/power-automate/BranchSuite-Personal-Mode.zip" download><Download size={15} /> Download flow package</a>
            <a className="secondary-control" href="https://make.powerautomate.com/" target="_blank" rel="noreferrer"><ExternalLink size={15} /> Open Power Automate</a></div></li>
        <li><strong>Keep the flow off while you configure it.</strong><p>Edit the actions named BranchSuite endpoint, Mailbox address, and Personal key using these values. Generate your key above first.</p>
          <div className="personal-copy-field"><label htmlFor="personal-endpoint">BranchSuite endpoint</label><input id="personal-endpoint" readOnly value={endpoint} /><button aria-label="Copy endpoint" disabled={!isConfigured} onClick={() => copy(endpoint, 'Endpoint')}><Copy size={15} /></button></div>
          <div className="personal-copy-field"><label htmlFor="personal-mailbox">Mailbox address</label><input id="personal-mailbox" readOnly value={credential?.mailboxAddress || connection?.mailboxAddress || me.email || ''} /><button aria-label="Copy mailbox address" onClick={() => copy(credential?.mailboxAddress || connection?.mailboxAddress || me.email, 'Mailbox address')}><Copy size={15} /></button></div>
          {credential ? <div className="personal-copy-field"><label htmlFor="personal-key">Personal key</label><input id="personal-key" type="password" readOnly value={credential.token} autoComplete="off" /><button aria-label="Copy personal key" onClick={() => copy(credential.token, 'Personal key')}><Copy size={15} /></button></div> : null}
          <p>The key is shown only here and is not included in the download. Keep Secure Inputs enabled on Personal key; this also hides its output. Keep both Secure Inputs and Secure Outputs enabled on the HTTP action.</p></li>
        <li><strong>Review the inbox and turn on your flow.</strong><p>The trigger watches new mail in Inbox. Once enabled, message bodies go to BranchSuite for AI task classification. Existing mail is not imported, and attachments are not processed.</p></li>
        <li><strong>Check the first delivery.</strong><p>After your next incoming email, this page will show “Email received.” Actionable mail appears on your Personal board; informational mail may create no task. Check Power Automate run history if delivery fails.</p></li>
      </ol>
    </section>
    {message ? <p className="personal-feedback" role="status">{message}</p> : null}
  </section>;
}
