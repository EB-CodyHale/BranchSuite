import React, { useState, useMemo } from 'react';
import {
  Plus, Minus, Star, Pause, Play, X, Check, Filter, Trash2,
  ArrowUpDown, RefreshCw, Calendar, Building2, AlertTriangle, Mail, ListTodo
} from 'lucide-react';
import { useBoard } from '../lib/store';
import { isConfigured } from '../lib/firebaseApp';
import { centralDateKey, shiftDateKey } from '../lib/centralTime';

/* ==================================================================
 * Job order board
 *
 * Keeps the whiteboard's core move: an opening is a line, and a line
 * with initials on it is spoken for. Everything else the marker cannot
 * do is added here. Sorting by need, a real difference between a
 * candidate committed and a candidate who actually started, start dates
 * that surface before the day arrives, and a pause state that is not
 * the word PAUSE written across a corner.
 *
 * Firestore shape:  orders/{id}  with slots as an embedded array.
 * ================================================================== */

const STORE_KEY = 'orders-state-v3';
const MAX_ACTIVE_UNIT_PATH_RECORDS = 5;

const C = {
  ground: 'var(--app-ground)', felt: 'var(--app-surface)', feltEdge: 'var(--app-border)', rail: 'var(--app-surface-subtle)',
  ink: 'var(--job-ink)', inkSoft: 'var(--job-ink-soft)', inkFaint: 'var(--job-ink-faint)',
  edgeRed: 'var(--app-danger-text)', edgeAmber: 'var(--app-warning-text)',
  signal: 'var(--app-accent)', stamp: 'var(--app-positive-text)',
  paper: 'var(--app-text)', chalk: 'var(--app-text)', chalkDim: 'var(--app-text-muted)',
};

/* Marker colors match the day board so ownership reads the same way
 * across both views. */
const MARKERS = {
  none:   { label: 'Black',  ink: 'var(--marker-none-ink)',   wash: 'var(--marker-none-wash)' },
  blue:   { label: 'Blue',   ink: 'var(--marker-blue-ink)',   wash: 'var(--marker-blue-wash)' },
  green:  { label: 'Green',  ink: 'var(--marker-green-ink)',  wash: 'var(--marker-green-wash)' },
  red:    { label: 'Red',    ink: 'var(--marker-red-ink)',    wash: 'var(--marker-red-wash)' },
  purple: { label: 'Purple', ink: 'var(--marker-purple-ink)', wash: 'var(--marker-purple-wash)' },
  orange: { label: 'Orange', ink: 'var(--marker-orange-ink)', wash: 'var(--marker-orange-wash)' },
  teal:   { label: 'Teal',   ink: 'var(--marker-teal-ink)',   wash: 'var(--marker-teal-wash)' },
};

const uid = () => Math.random().toString(36).slice(2, 10);
const ymd = (value) => centralDateKey(value);
const dayNumber = (value) => {
  const [year, month, day] = ymd(value).split('-').map(Number);
  return Date.UTC(year, month - 1, day) / 86400000;
};
const dayDiff = (a, b) => dayNumber(b) - dayNumber(a);
const shortDate = (s) => {
  if (!s) return '';
  const [y, m, d] = s.split('-');
  return `${Number(m)}/${Number(d)}`;
};
const ago = (n) => Date.now() - n * 86400000;
const inDays = (n) => shiftDateKey(centralDateKey(), n);

/* ------------------------------------------------------------------ *
 * Seed, read off the Bolingbrook board. Rates and shifts are
 * approximate, they are meant to be corrected in place.
 * ------------------------------------------------------------------ */
const slot = (initials, startDate, status) =>
  ({ id: uid(), initials: initials || null, startDate: startDate || null, status: status || 'committed' });
const empty = (n) => Array.from({ length: n }, () => slot());

const SEED = {
  /* Same ids and codes as the day board. When both boards move to
   * Firestore these stop being two seeds and become one `branches`
   * collection. */
  branches: [
    { id: 'b1', name: 'Granite City', code: '30080' },
    { id: 'b2', name: 'Bolingbrook', code: '20062' },
  ],
  /* `branchIds` matches the day board's user shape on purpose, so the
   * two rosters merge into one `users` collection by rename rather than
   * redesign. Everyone here came off the Bolingbrook board, so everyone
   * here is on b2. The whole-office entry spans both. */
  people: [
    { id: 'u1', initials: 'PR',   name: 'Priya R.',  marker: 'red',    branchIds: ['b2'], active: true },
    { id: 'u2', initials: 'PV',   name: 'Pav V.',    marker: 'blue',   branchIds: ['b2'] },
    { id: 'u3', initials: 'LUZ',  name: 'Luz M.',    marker: 'purple', branchIds: ['b2'] },
    { id: 'u4', initials: 'HL',   name: 'Hal L.',    marker: 'green',  branchIds: ['b2'] },
    { id: 'u5', initials: 'LS',   name: 'Lena S.',   marker: 'orange', branchIds: ['b2'] },
    { id: 'u6', initials: 'NIXW', name: 'Nix W.',    marker: 'teal',   branchIds: ['b2'] },
    { id: 'u7', initials: 'PB',   name: 'Pete B.',   marker: 'none',   branchIds: ['b2'] },
    { id: 'u8', initials: 'BB',   name: 'Whole office', marker: 'none', branchIds: ['b1', 'b2'] },
  ],
  accounts: [
    { id: 'jo-a-geodis', branchId: 'b2', name: 'GEODIS', ownerId: 'u1', isPriority: true, active: true },
    { id: 'jo-a-td-kane', branchId: 'b2', name: 'TD Kane', ownerId: 'u1', isPriority: false, active: true },
    { id: 'jo-a-quality-craft', branchId: 'b2', name: 'Quality Craft', ownerId: null, isPriority: false, active: true },
    { id: 'jo-a-weathertech', branchId: 'b2', name: 'WeatherTech', ownerId: 'u3', isPriority: false, active: true },
  ],
  accountUnits: [
    { id: 'jo-au-geodis-1536', branchId: 'b2', accountId: 'jo-a-geodis', name: '1536', ownerId: 'u1', parentUnitId: null, active: true },
    { id: 'jo-au-geodis-1500', branchId: 'b2', accountId: 'jo-a-geodis', name: '1500 Lint', ownerId: 'u2', parentUnitId: null, active: true },
    { id: 'jo-au-td-lockport', branchId: 'b2', accountId: 'jo-a-td-kane', name: 'Lockport', ownerId: null, parentUnitId: null, active: true },
    { id: 'jo-au-weathertech-machine', branchId: 'b2', accountId: 'jo-a-weathertech', name: 'Machine operators', ownerId: 'u3', parentUnitId: null, active: true },
  ],
  orders: [
    { id: uid(), branchId: 'b2', account: 'GEODIS', site: '1536', role: 'Op / Sit-down', shift: '1st',
      accountId: 'jo-a-geodis', accountName: 'GEODIS', accountUnitId: 'jo-au-geodis-1536', accountUnitName: '1536',
      days: 'M-F', hours: '6:00am-2:30pm', rate: 19.00, ownerId: 'u1', owner: 'PR', isPriority: true,
      source: 'email', sourceTaskId: 'demo-email-task-1536', sourceMessageId: 'demo-message-1536',
      sourceConversationId: 'demo-conversation-geodis', sourceBoardDate: centralDateKey(),
      status: 'active', createdAt: ago(11), slots: empty(3) },
    { id: uid(), branchId: 'b2', account: 'GEODIS', site: '1500 Lint', role: 'Reach / EPJ', shift: '2nd',
      accountId: 'jo-a-geodis', accountName: 'GEODIS', accountUnitId: 'jo-au-geodis-1500', accountUnitName: '1500 Lint',
      days: 'M-F', hours: null, rate: 21.00, ownerId: 'u2', owner: 'PV', isPriority: true,
      status: 'active', createdAt: ago(9), slots: [slot('AR', inDays(1)), slot(), slot()] },
    { id: uid(), branchId: 'b2', account: 'TD Kane', site: 'Lockport', role: 'Reach', shift: '2nd',
      accountId: 'jo-a-td-kane', accountName: 'TD Kane', accountUnitId: 'jo-au-td-lockport', accountUnitName: 'Lockport',
      days: 'M-F', hours: '1:30pm start', rate: 20.50, ownerId: 'u1', owner: 'PR', isPriority: false,
      status: 'active', createdAt: ago(6), slots: empty(3) },
    { id: uid(), branchId: 'b2', account: 'TD Kane', site: 'Lockport', role: 'Reach', shift: '3rd',
      days: 'M-F', hours: null, rate: 22.00, owner: 'PR', isPriority: false,
      status: 'active', createdAt: ago(6), slots: empty(2) },
    { id: uid(), branchId: 'b2', account: 'Quality Craft', site: 'Bolingbrook', role: 'General labor', shift: '1st',
      accountId: 'jo-a-quality-craft', accountName: 'Quality Craft', accountUnitId: null, accountUnitName: null,
      days: 'Sep 14-19', hours: '8:00am-5:00pm', rate: 18.00, ownerId: null, owner: null, isPriority: false,
      status: 'active', createdAt: ago(2), note: 'Plus $1 attendance bonus', slots: empty(4) },
    { id: uid(), branchId: 'b2', account: 'Bridgestone', site: null, role: 'Reach', shift: '3rd',
      days: 'M-F', hours: null, rate: 22.00, owner: 'PV', isPriority: false,
      status: 'active', createdAt: ago(8), slots: [slot('AD', inDays(0), 'started'), slot('DN', ago(2) && inDays(-2), 'started')] },
    { id: uid(), branchId: 'b2', account: 'Penske Bread', site: 'Lockport', role: 'Warehouse', shift: '3rd',
      days: 'Sun-Th', hours: '9:00pm-7:00am', rate: 19.50, owner: 'LUZ', isPriority: false,
      status: 'active', createdAt: ago(5),
      slots: [slot('ER', inDays(-3), 'started'), slot('JG', inDays(-3), 'started'), slot('JH', inDays(2)), slot('GT', inDays(2)), slot()] },
    { id: uid(), branchId: 'b2', account: 'Novolex', site: 'Romeoville', role: 'Forklift', shift: '1st',
      days: 'Sun-Th', hours: null, rate: 21.00, owner: 'PB', isPriority: false,
      status: 'active', createdAt: ago(14),
      slots: [slot('RD', inDays(-6), 'started'), slot('AS', inDays(-6), 'started'), slot('DD', inDays(1))] },
    { id: uid(), branchId: 'b2', account: 'Novolex', site: 'Romeoville', role: 'Forklift', shift: '2nd',
      days: 'Sun-Th', hours: null, rate: 27.50, owner: 'PB', isPriority: false,
      status: 'active', createdAt: ago(14),
      slots: [slot('LR', inDays(-6), 'started'), slot('CB', inDays(-1), 'started'), slot('DC', inDays(3))] },
    { id: uid(), branchId: 'b2', account: 'Westrock', site: null, role: 'Group lead', shift: '1st',
      days: 'M-F', hours: null, rate: 17.05, owner: 'LS', isPriority: true,
      status: 'active', createdAt: ago(4), slots: empty(2) },
    { id: uid(), branchId: 'b2', account: 'Westrock', site: null, role: 'Group lead', shift: '2nd',
      days: 'M-F', hours: null, rate: 18.05, owner: 'LS', isPriority: true,
      status: 'active', createdAt: ago(4), slots: empty(2) },
    { id: uid(), branchId: 'b2', account: 'Armada', site: null, role: 'Stand-up', shift: '2nd',
      days: 'M-F', hours: null, rate: 22.75, owner: null, isPriority: true,
      status: 'active', createdAt: ago(7), slots: [slot('F2', inDays(-1), 'started'), slot(), slot(), slot()] },
    { id: uid(), branchId: 'b2', account: 'ODW Cold', site: 'Romeoville', role: 'Stand-up, 30 degree cold', shift: '2nd',
      days: 'M-F', hours: '2:00pm-12:00am', rate: 20.50, owner: 'NIXW', isPriority: false,
      status: 'active', createdAt: ago(3), slots: [slot('JC', inDays(1)), slot(), slot()] },
    { id: uid(), branchId: 'b2', account: 'Veritiv', site: 'Lockport', role: 'Stand-up', shift: '2nd',
      days: 'M-F', hours: null, rate: 20.25, owner: 'NIXW', isPriority: false,
      status: 'active', createdAt: ago(6),
      slots: [slot('AH', inDays(-1), 'started'), slot('JS', inDays(-5), 'started'), slot()] },
    { id: uid(), branchId: 'b2', account: 'Ryder / Diageo', site: 'Plainfield', role: 'Warehouse, D shift',
      shift: '1st', days: 'Wed-Sat', hours: null, rate: 20.50, owner: 'PB', isPriority: false,
      status: 'active', createdAt: ago(10), slots: [slot('TJ', inDays(-2), 'started'), slot('MB', inDays(2)), slot()] },
    { id: uid(), branchId: 'b2', account: 'Berlin Packaging', site: 'Lockport', role: 'Sit-down', shift: '1st',
      days: 'M-F', hours: '7:00am-3:30pm', rate: 20.00, owner: 'LUZ', isPriority: false,
      status: 'active', createdAt: ago(5), slots: [slot('CE', inDays(0)), slot()] },
    { id: uid(), branchId: 'b2', account: 'Wayfair', site: null, role: 'Warehouse', shift: '2nd',
      days: 'M-F', hours: '5:30pm-2:30am', rate: 26.50, owner: 'LS', isPriority: false,
      status: 'paused', createdAt: ago(12), note: 'On hold at client request', slots: empty(4) },
    { id: uid(), branchId: 'b2', account: 'Clerks', site: 'McCook', role: 'Clerk', shift: '3rd',
      days: 'M-F', hours: '9:00pm-7:30am', rate: 21.50, owner: null, isPriority: false,
      status: 'active', createdAt: ago(1), slots: empty(2) },
  ],
};

function slotsOf(order) {
  return Array.isArray(order?.slots) ? order.slots : [];
}

function ownerInitialsOf(order, accountById, unitById, people) {
  if (order?.accountId) {
    const account = accountById.get(order.accountId);
    if (!account || account.branchId !== order.branchId) return null;
    const candidateUnit = unitById.get(order.accountUnitId);
    const unit = candidateUnit?.accountId === account.id && candidateUnit?.branchId === order.branchId
      ? candidateUnit
      : null;
    return eligibleOwner(account, unit, unitById, people, order.branchId)?.initials || null;
  }
  // Legacy labels are not proof that somebody owns a configured account.
  // Keep them editable for migration, but render the order as unowned until
  // it is linked to a real account record.
  return null;
}

function accountDetailsOf(order, accountById, unitById) {
  const account = accountById.get(order?.accountId);
  const unit = unitById.get(order?.accountUnitId);
  return {
    accountName: account?.name || order?.accountName || order?.account || 'Unlinked account',
    unitName: unit?.name || order?.accountUnitName || null,
  };
}

function eligibleOwner(account, unit, unitsById, people, branchId) {
  let configuredOwnerId = null;
  const visited = new Set();
  let current = unit || null;

  while (current
    && current.accountId === account.id
    && current.branchId === branchId
    && !visited.has(current.id)) {
    visited.add(current.id);
    if (current.ownerId) {
      configuredOwnerId = current.ownerId;
      break;
    }
    current = current.parentUnitId ? unitsById.get(current.parentUnitId) : null;
  }
  configuredOwnerId ||= account?.ownerId || null;
  if (!configuredOwnerId) return null;
  const person = people.find((candidate) => candidate.id === configuredOwnerId);
  return person?.active !== false && person?.branchIds?.includes(branchId) ? person : null;
}

function unitPath(unit, unitsById) {
  const names = [];
  const visited = new Set();
  let current = unit;
  while (current && !visited.has(current.id)) {
    visited.add(current.id);
    names.unshift(current.name);
    current = current.parentUnitId ? unitsById.get(current.parentUnitId) : null;
  }
  return names.filter(Boolean).join(' / ') || 'Unnamed location';
}

function activeUnitPath(unit, unitsById) {
  if (!unit?.id) return false;
  const visited = new Set();
  const { accountId, branchId } = unit;
  let current = unit;
  let records = 0;

  while (current?.id) {
    if (visited.has(current.id)
      || current.active === false
      || current.accountId !== accountId
      || current.branchId !== branchId) return false;
    visited.add(current.id);
    records += 1;
    if (!current.parentUnitId) return true;
    if (records >= MAX_ACTIVE_UNIT_PATH_RECORDS) return false;
    current = unitsById.get(current.parentUnitId);
  }
  return false;
}

/* ================================================================== */

export default function JobOrders() {
  const [sort, setSort] = useState('need');
  const [branchFilter, setBranchFilter] = useState('all');
  const [ownerFilter, setOwnerFilter] = useState('all');
  const [unfilledOnly, setUnfilledOnly] = useState(false);
  const [showPaused, setShowPaused] = useState(false);
  const [editing, setEditing] = useState(null);
  const [adding, setAdding] = useState(false);

  const {
    db, meId, loading, err, syncing, createDoc, updateDoc, deleteDoc, mutateDoc, pickMe, pull,
  } = useBoard(STORE_KEY, SEED, { consumeLocalOrderInbox: true });

  /* In the deployed build identity is the signed-in account, so there is no
   * fallback. Local mode keeps its default person, since the picker is a
   * preview device rather than a sign in. */
  const me = db?.people.find((p) => p.id === meId)
    || (isConfigured ? null : db?.people.find((p) => p.id === 'u8'));
  const canManage = !isConfigured || me?.role === 'admin' || me?.role === 'manager';

  /* Branch scoping, same shape as the day board. `visibleBranchIds` is the
   * one thing every list below filters on, so the rule in firestore.rules
   * and the rule in the UI cannot drift apart. */
  const myBranches = useMemo(
    () => (db?.branches || []).filter((b) => me?.branchIds?.includes(b.id)), [db, me]);
  const visibleBranchIds = branchFilter === 'all' ? (me?.branchIds || []) : [branchFilter];
  const inView = (o) => visibleBranchIds.includes(o.branchId);
  const branchLabel = branchFilter === 'all'
    ? (myBranches.length > 1 ? 'All branches' : myBranches[0]?.name || 'No branch')
    : (myBranches.find((b) => b.id === branchFilter)?.name || 'No branch');

  /* Who can own an order, and who the owner filter offers. Not the Writing
   * as row, which is the identity picker and has to list everyone, or you
   * could never switch to a person in the branch you are not looking at. */
  const roster = useMemo(
    () => (db?.people || []).filter((p) => p.branchIds?.some((b) => visibleBranchIds.includes(b))),
    [db, branchFilter, me]);

  const accountById = useMemo(
    () => new Map((db?.accounts || []).map((account) => [account.id, account])), [db]);
  const unitById = useMemo(
    () => new Map((db?.accountUnits || []).map((unit) => [unit.id, unit])), [db]);

  /* Deliberately not scoped. A slot can carry initials for someone who is
   * not in the branch you are looking at, and their marker color still has
   * to render. */
  const personBy = (initials) => db?.people.find((p) => p.initials === initials);
  const markerOf = (initials) => MARKERS[personBy(initials)?.marker || 'none'];

  const patchOrder = (id, fields) => updateDoc('orders', id, { ...fields, updatedAt: Date.now() });

  const setSlot = (orderId, slotId, f) =>
    mutateDoc('orders', orderId, (order) => ({
      ...order,
      slots: slotsOf(order).map((item) => (item.id === slotId ? { ...item, ...f } : item)),
      updatedAt: Date.now(),
    }));

  const addSlot = (o) => mutateDoc('orders', o.id, (order) => ({
    ...order, slots: [...slotsOf(order), slot()], updatedAt: Date.now(),
  }));
  const removeSlot = (o) => {
    mutateDoc('orders', o.id, (order) => {
      const orderSlots = slotsOf(order);
      const idx = [...orderSlots].reverse().findIndex((item) => !item.initials);
      if (idx === -1) return order;
      const real = orderSlots.length - 1 - idx;
      return {
        ...order,
        slots: orderSlots.filter((_, index) => index !== real),
        updatedAt: Date.now(),
      };
    });
  };

  /* ---------- derived ---------- */
  const stats = useMemo(() => {
    if (!db) return { openings: 0, filled: 0, unfilled: 0, startingSoon: 0, atRisk: 0 };
    const active = db.orders.filter((o) => o.status === 'active' && inView(o));
    const slots = active.flatMap(slotsOf);
    const startingSoon = slots.filter(
      (s) => s.initials && s.status === 'committed' && s.startDate &&
        dayDiff(Date.now(), s.startDate) >= 0 && dayDiff(Date.now(), s.startDate) <= 2).length;
    const atRisk = active.filter(
      (o) => slotsOf(o).some((s) => !s.initials) && dayDiff(o.createdAt, Date.now()) >= 7).length;
    return {
      openings: slots.length,
      filled: slots.filter((s) => s.initials).length,
      unfilled: slots.filter((s) => !s.initials).length,
      startingSoon, atRisk,
    };
  }, [db, branchFilter, me]);

  const visible = useMemo(() => {
    if (!db) return [];
    let list = db.orders.filter((o) => inView(o) && (showPaused ? true : o.status === 'active'));
    if (ownerFilter === 'unowned') {
      list = list.filter((o) => !ownerInitialsOf(o, accountById, unitById, db.people || []));
    } else if (ownerFilter !== 'all') {
      list = list.filter((o) => ownerInitialsOf(o, accountById, unitById, db.people || []) === ownerFilter);
    }
    if (unfilledOnly) list = list.filter((o) => slotsOf(o).some((s) => !s.initials));

    const openCount = (o) => slotsOf(o).filter((s) => !s.initials).length;
    const soonest = (o) => {
      const ds = slotsOf(o).filter((s) => s.startDate).map((s) => dayDiff(Date.now(), s.startDate));
      return ds.length ? Math.min(...ds) : 999;
    };

    return [...list].sort((a, b) => {
      if (a.status !== b.status) return a.status === 'active' ? -1 : 1;
      if (sort === 'need') {
        if (openCount(b) !== openCount(a)) return openCount(b) - openCount(a);
        return a.createdAt - b.createdAt;
      }
      if (sort === 'age') return a.createdAt - b.createdAt;
      if (sort === 'start') return soonest(a) - soonest(b);
      const aName = accountDetailsOf(a, accountById, unitById).accountName;
      const bName = accountDetailsOf(b, accountById, unitById).accountName;
      return aName.localeCompare(bName) || (a.shift || '').localeCompare(b.shift || '');
    });
  }, [db, sort, branchFilter, me, ownerFilter, unfilledOnly, showPaused, accountById, unitById]);

  if (loading) {
    return (
      <div style={{ background: C.ground, color: C.chalk, minHeight: 420, fontFamily: 'Barlow, system-ui, sans-serif' }}
           className="job-orders-loading flex items-center justify-center"><Fonts />Loading job orders</div>
    );
  }

  return (
    <div style={{ background: C.ground, minHeight: 660, color: C.paper, fontFamily: 'Barlow, system-ui, sans-serif' }} className="job-orders-shell">
      <Fonts />

      {/* -------- summary rail -------- */}
      <div style={{ background: C.rail, borderBottom: `1px solid ${C.feltEdge}` }} className="job-orders-summary px-4 py-3">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div>
            <div style={{ fontFamily: '"Barlow Condensed", sans-serif', fontSize: 26, lineHeight: 1 }}>
              Job orders
            </div>
            <div style={{ color: C.chalkDim, fontSize: 14, marginTop: 4 }}>
              {branchLabel} · {stats.unfilled} to fill of {stats.openings}
              {stats.startingSoon > 0 && (
                <span style={{ color: C.signal }}> · {stats.startingSoon} starting in 48 hours</span>
              )}
              {stats.atRisk > 0 && (
                <span style={{ color: C.edgeRed }}> · {stats.atRisk} open a week or more</span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => pull(false)}
              style={{ border: `1px solid ${C.feltEdge}`, color: C.chalk, fontSize: 14 }}
              className="px-3 py-2 rounded flex items-center gap-2">
              <RefreshCw size={15} className={syncing ? 'animate-spin' : ''} /> Refresh
            </button>
            {canManage && (
              <button onClick={() => setAdding(true)}
                style={{ background: C.signal, border: `1px solid ${C.signal}`, color: 'var(--app-on-accent)', fontSize: 14 }}
                className="px-3 py-2 rounded flex items-center gap-2">
                <Plus size={15} /> New order
              </button>
            )}
          </div>
        </div>

        {myBranches.length > 1 && (
          <div className="flex items-center gap-2 mt-3 flex-wrap">
            <Building2 size={15} color={C.chalkDim} />
            <Chip active={branchFilter === 'all'} onClick={() => setBranchFilter('all')}>All branches</Chip>
            {myBranches.map((b) => (
              <Chip key={b.id} active={branchFilter === b.id} onClick={() => setBranchFilter(b.id)}>{b.name}</Chip>
            ))}
          </div>
        )}

        {/* -------- who am I, drives the color of initials I write --------
            Only in local mode. When Firebase is configured this is the
            signed-in account and is not something to pick. */}
        {!isConfigured && (
        <div className="flex items-center gap-2 mt-3 flex-wrap">
          <span style={{ color: C.chalkDim, fontSize: 13 }}>Writing as</span>
          {db.people.filter((p) => p.initials !== 'BB').map((p) => (
            <button key={p.id}
              onClick={() => pickMe(p.id)}
              style={{
                fontSize: 13, padding: '3px 9px',
                border: `1px solid ${meId === p.id ? MARKERS[p.marker].ink : C.feltEdge}`,
                background: meId === p.id ? MARKERS[p.marker].wash : 'transparent',
                color: meId === p.id ? MARKERS[p.marker].ink : C.chalkDim,
                fontWeight: meId === p.id ? 600 : 400,
              }}
              className="rounded">{p.initials}</button>
          ))}
        </div>
        )}
      </div>

      {/* -------- filters -------- */}
      <div style={{ background: 'var(--app-surface-subtle)', borderBottom: `1px solid ${C.feltEdge}` }}
           className="job-orders-filters px-4 py-3 flex items-center gap-2 flex-wrap">
        <ArrowUpDown size={15} color={C.chalkDim} />
        <Chip active={sort === 'need'} onClick={() => setSort('need')}>Most to fill</Chip>
        <Chip active={sort === 'start'} onClick={() => setSort('start')}>Next start</Chip>
        <Chip active={sort === 'age'} onClick={() => setSort('age')}>Open longest</Chip>
        <Chip active={sort === 'account'} onClick={() => setSort('account')}>By account</Chip>

        <span style={{ width: 1, height: 20, background: C.feltEdge }} className="mx-1" />

        <Filter size={15} color={C.chalkDim} />
        <select value={ownerFilter} onChange={(e) => setOwnerFilter(e.target.value)}
          style={{ background: C.felt, border: `1px solid ${C.feltEdge}`, color: C.paper, fontSize: 14, padding: '5px 8px' }}
          className="rounded" aria-label="Filter by owner">
          <option value="all">All owners</option>
          <option value="unowned">Unowned</option>
          {roster.map((p) => <option key={p.id} value={p.initials}>{p.initials}</option>)}
        </select>
        <Chip active={unfilledOnly} onClick={() => setUnfilledOnly(!unfilledOnly)}>Has openings</Chip>
        <Chip active={showPaused} onClick={() => setShowPaused(!showPaused)}>Show paused</Chip>
      </div>

      {/* -------- orders -------- */}
      <div className="job-orders-list p-4 flex flex-col gap-3" style={{ maxWidth: 1100 }}>
        {visible.length === 0 && (
          <div style={{ background: C.felt, border: `1px solid ${C.feltEdge}`, color: C.chalkDim, fontSize: 14 }}
               className="rounded p-4">
            Nothing matches these filters.
          </div>
        )}
        {err && (
          <div style={{ background: 'var(--app-danger-soft)', color: 'var(--app-danger-text)', fontSize: 14 }}
               className="rounded px-3 py-2 flex items-center gap-2">
            <AlertTriangle size={15} /> {err}
          </div>
        )}
        {visible.map((o) => (
          <OrderCard key={o.id} order={o} me={me} markerOf={markerOf}
                     people={db.people || []} accountById={accountById} unitById={unitById}
                     canManage={canManage}
                     onSlot={(sid, f) => setSlot(o.id, sid, f)}
                     onAddSlot={() => addSlot(o)} onRemoveSlot={() => removeSlot(o)}
                     onPatch={(f) => patchOrder(o.id, f)}
                     onEdit={() => setEditing(o)}
                     onDelete={() => deleteDoc('orders', o.id)} />
        ))}
      </div>

      {canManage && (adding || editing) && (
        <OrderForm order={editing} branches={myBranches} people={db.people || []}
          accounts={db.accounts || []} units={db.accountUnits || []}
          defaultBranchId={visibleBranchIds[0]}
          onClose={() => { setAdding(false); setEditing(null); }}
          onSave={({ openings, ...vals }) => {
            if (editing) patchOrder(editing.id, vals);
            else createDoc('orders', {
              status: 'active', source: 'manual', createdAt: Date.now(), updatedAt: Date.now(),
              slots: empty(openings || 1), ...vals,
            });
            setAdding(false); setEditing(null);
          }} />
      )}
    </div>
  );
}

/* ================================================================== */

function Fonts() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600&family=Barlow+Condensed:wght@500;600&display=swap');
      * { box-sizing: border-box; }
      button:focus-visible, select:focus-visible, input:focus-visible { outline: 2px solid ${C.signal}; outline-offset: 2px; }
      select, input { font-family: Barlow, system-ui, sans-serif; }
      @media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
    `}</style>
  );
}

function Chip({ active, onClick, children }) {
  return (
    <button onClick={onClick}
      style={{
        fontSize: 13, padding: '5px 10px',
        border: `1px solid ${active ? C.signal : C.feltEdge}`,
        background: active ? 'var(--app-accent-soft)' : 'transparent',
        color: active ? C.paper : C.chalkDim,
      }}
      className="rounded">{children}</button>
  );
}

function OrderCard({
  order, me, markerOf, people, accountById, unitById, canManage,
  onSlot, onAddSlot, onRemoveSlot, onPatch, onEdit, onDelete,
}) {
  const [openSlot, setOpenSlot] = useState(null);
  const [menu, setMenu] = useState(false);

  const ownerInitials = ownerInitialsOf(order, accountById, unitById, people);
  const owner = markerOf(ownerInitials);
  const { accountName, unitName } = accountDetailsOf(order, accountById, unitById);
  const orderSlots = slotsOf(order);
  const openCount = orderSlots.filter((s) => !s.initials).length;
  const age = dayDiff(order.createdAt, Date.now());
  const paused = order.status === 'paused';
  const full = openCount === 0;
  const fromEmail = order.source === 'email' || Boolean(
    order.sourceMessageId || order.sourceConversationId || order.sourceEmail,
  );
  const sourceTaskId = order.sourceTaskId || null;
  const shortTaskId = sourceTaskId?.length > 18
    ? `${sourceTaskId.slice(0, 15)}…`
    : sourceTaskId;

  const edge = paused ? C.inkFaint : full ? C.stamp : owner.ink;

  return (
    <div style={{
      background: paused ? 'var(--job-paper-paused)' : owner.wash,
      borderLeft: `5px solid ${edge}`,
      color: C.ink, opacity: paused ? 0.72 : 1,
      boxShadow: '0 0 0 1px var(--job-line)',
    }} className="job-order-card rounded-sm p-3">

      {/* header */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            {order.isPriority && <Star size={14} fill={C.edgeAmber} color={C.edgeAmber} />}
            <span style={{ fontFamily: '"Barlow Condensed", sans-serif', fontSize: 22, lineHeight: 1.1 }}>
              {accountName}
            </span>
            {unitName && (
              <span style={{ color: C.inkSoft, fontSize: 13, border: '1px solid var(--job-line)', padding: '2px 7px' }}
                    className="rounded">
                {unitName}
              </span>
            )}
            {order.site && order.site !== unitName && (
              <span style={{ color: C.inkSoft, fontSize: 14 }}>{order.site}</span>
            )}
            <span style={{
              fontSize: 12, fontWeight: 600, padding: '2px 7px',
              border: `1.5px solid ${owner.ink}`, color: owner.ink, borderRadius: 999,
            }}>{ownerInitials || 'Unowned'}</span>
            {paused && (
              <span style={{ fontSize: 12, color: C.inkSoft, border: `1px solid ${C.inkFaint}`, padding: '2px 7px' }}
                    className="rounded">Paused</span>
            )}
          </div>
          <div style={{ color: C.inkSoft, fontSize: 14, marginTop: 3 }}>
            {[order.role, order.shift, order.days, order.hours].filter(Boolean).join(' · ')}
            {order.rate ? ` · $${order.rate.toFixed(2)}` : ''}
          </div>
          {order.note && (
            <div style={{ color: C.inkSoft, fontSize: 13, marginTop: 3, fontStyle: 'italic' }}>{order.note}</div>
          )}
          {(fromEmail || sourceTaskId) && (
            <div className="flex items-center gap-3 flex-wrap" style={{ color: C.inkSoft, fontSize: 12, marginTop: 5 }}>
              {fromEmail && (
                <span className="flex items-center gap-1">
                  <Mail size={12} /> Email request
                </span>
              )}
              {sourceTaskId && (
                <span className="flex items-center gap-1" title={`Source task ${sourceTaskId}`}>
                  <ListTodo size={12} /> Task {shortTaskId}
                </span>
              )}
              {order.sourceBoardDate && <span>Board {shortDate(order.sourceBoardDate)}</span>}
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <div style={{ textAlign: 'right' }}>
            <div style={{
              fontSize: 15, fontWeight: 600,
              color: full ? C.stamp : openCount >= 3 ? C.edgeRed : C.ink,
            }}>
              {full ? 'Covered' : `${openCount} to fill`}
            </div>
            <div style={{
              fontSize: 12,
              color: !full && age >= 7 ? C.edgeRed : C.inkSoft,
            }}>
              open {age}d
            </div>
          </div>
          {canManage && (
            <button onClick={() => setMenu(!menu)} aria-label="Order actions"
              style={{ color: C.inkSoft, border: '1px solid var(--job-line)', padding: '4px 8px', fontSize: 13 }}
              className="rounded">•••</button>
          )}
        </div>
      </div>

      {canManage && menu && (
        <div className="flex items-center gap-2 flex-wrap mt-3 pt-3"
             style={{ borderTop: '1px solid var(--job-line)' }}>
          <MiniBtn onClick={onAddSlot} icon={<Plus size={13} />} disabled={orderSlots.length >= 200}>
            Add opening
          </MiniBtn>
          <MiniBtn onClick={onRemoveSlot} icon={<Minus size={13} />}
                   disabled={openCount === 0 || orderSlots.length <= 1}>
            Remove opening
          </MiniBtn>
          <MiniBtn onClick={() => onPatch({ isPriority: !order.isPriority })} icon={<Star size={13} />}>
            {order.isPriority ? 'Unstar' : 'Star'}
          </MiniBtn>
          <MiniBtn onClick={() => onPatch({ status: paused ? 'active' : 'paused' })}
                   icon={paused ? <Play size={13} /> : <Pause size={13} />}>
            {paused ? 'Resume' : 'Pause'}
          </MiniBtn>
          <MiniBtn onClick={onEdit}>Edit details</MiniBtn>
          {order.source !== 'email' && !order.sourceTaskId ? (
            <MiniBtn onClick={onDelete} icon={<Trash2 size={13} />} danger>Delete</MiniBtn>
          ) : null}
        </div>
      )}

      {/* the lines */}
      <div className="flex items-center gap-2 flex-wrap mt-3">
        {orderSlots.map((s) => (
          <SlotLine key={s.id} slot={s} markerOf={markerOf}
                    active={openSlot === s.id}
                    onOpen={() => setOpenSlot(openSlot === s.id ? null : s.id)}
                    onSet={(f) => { onSlot(s.id, f); setOpenSlot(null); }}
                    onClear={() => { onSlot(s.id, { initials: null, startDate: null, status: 'committed' }); setOpenSlot(null); }}
                    me={me} />
        ))}
      </div>
    </div>
  );
}

function MiniBtn({ onClick, icon, children, danger, disabled }) {
  return (
    <button onClick={onClick} disabled={disabled}
      style={{
        fontSize: 13, padding: '5px 9px',
        border: '1px solid var(--job-line)',
        color: disabled ? C.inkFaint : danger ? C.edgeRed : C.ink,
        opacity: disabled ? 0.5 : 1,
      }}
      className="rounded flex items-center gap-1">{icon}{children}</button>
  );
}

/* A single opening. Empty renders as a blank line, the way it does on the
 * whiteboard. Filled renders the initials in the marker color of whoever
 * wrote them, with the start date, and a check once the person started. */
function SlotLine({ slot, markerOf, active, onOpen, onSet, onClear, me }) {
  const [initials, setInitials] = useState(slot.initials || '');
  const [date, setDate] = useState(slot.startDate || '');

  const filled = !!slot.initials;
  const started = slot.status === 'started';
  const mark = filled ? markerOf(slot.writtenBy || me?.initials) : null;
  const daysOut = slot.startDate ? dayDiff(Date.now(), slot.startDate) : null;
  const soon = filled && !started && daysOut !== null && daysOut >= 0 && daysOut <= 2;
  const overdue = filled && !started && daysOut !== null && daysOut < 0;

  if (active) {
    return (
      <div style={{ background: 'var(--job-editor)', border: '1px solid var(--job-line)', minWidth: 210 }}
           className="rounded p-2 flex flex-col gap-2">
        <input value={initials} onChange={(e) => setInitials(e.target.value.toUpperCase().slice(0, 4))}
               placeholder="Initials" autoFocus
               style={{ background: 'var(--job-paper)', border: '1px solid var(--job-line)', color: C.ink, padding: '6px 8px', fontSize: 14, width: '100%' }}
               className="rounded" aria-label="Candidate initials" />
        <div className="flex items-center gap-1">
          <Calendar size={14} color={C.inkSoft} />
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
                 style={{ background: 'var(--job-paper)', border: '1px solid var(--job-line)', color: C.ink, padding: '5px 6px', fontSize: 13, flex: 1 }}
                 className="rounded" aria-label="Start date" />
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => initials.trim() && onSet({
              initials: initials.trim(), startDate: date || null,
              status: slot.status || 'committed', writtenBy: me?.initials || null,
            })}
            style={{ background: C.signal, color: 'var(--app-on-accent)', fontSize: 13, padding: '6px 10px' }}
            className="rounded flex-1">Save</button>
          {filled && (
            <button onClick={onClear}
              style={{ border: '1px solid var(--job-line)', color: C.edgeRed, fontSize: 13, padding: '6px 10px' }}
              className="rounded">Clear</button>
          )}
          <button onClick={onOpen}
            style={{ border: '1px solid var(--job-line)', color: C.inkSoft, fontSize: 13, padding: '6px 8px' }}
            className="rounded" aria-label="Cancel"><X size={14} /></button>
        </div>
      </div>
    );
  }

  if (!filled) {
    return (
      <button onClick={onOpen}
        style={{
          minWidth: 88, height: 40, borderBottom: '2px solid var(--job-line-strong)',
          color: 'var(--job-ink-faint)', fontSize: 20, lineHeight: 1,
        }}
        className="flex items-end justify-center pb-1" aria-label="Fill this opening">+</button>
    );
  }

  return (
    <div className="flex flex-col items-stretch" style={{ minWidth: 88 }}>
      <button onClick={onOpen}
        style={{
          borderBottom: `2px solid ${started ? C.stamp : mark.ink}`,
          color: mark.ink, fontSize: 17, fontWeight: 600, height: 40,
          paddingBottom: 2,
        }}
        className="flex items-end justify-center gap-1">
        {started && <Check size={14} color={C.stamp} />}
        {slot.initials}
      </button>
      <span style={{
        fontSize: 11, textAlign: 'center', marginTop: 2,
        color: overdue ? C.edgeRed : soon ? C.signal : C.inkSoft,
        fontWeight: overdue || soon ? 600 : 400,
      }}>
        {started
          ? 'started'
          : slot.startDate
            ? (overdue ? `due ${shortDate(slot.startDate)}` : `starts ${shortDate(slot.startDate)}`)
            : 'no date'}
      </span>
      {!started && (
        <button onClick={() => onSet({ ...slot, status: 'started' })}
          style={{ fontSize: 11, color: C.stamp, marginTop: 2 }}>mark started</button>
      )}
    </div>
  );
}

function OrderForm({ order, branches, people, accounts, units, defaultBranchId, onClose, onSave }) {
  const linkedEmailOrder = Boolean(order && (order.source === 'email' || order.sourceTaskId));
  const [v, setV] = useState({
    branchId: order?.branchId || defaultBranchId || branches[0]?.id || null,
    accountId: order?.accountId || '',
    accountName: order?.accountName || order?.account || '',
    accountUnitId: order?.accountUnitId || '',
    accountUnitName: order?.accountUnitName || '',
    site: order?.site || '', role: order?.role || '',
    shift: order?.shift || '1st', days: order?.days || 'M-F', hours: order?.hours || '',
    rate: order?.rate ?? '', note: order?.note || '',
    openings: order ? slotsOf(order).length : 2,
    isPriority: order?.isPriority || false,
  });
  const set = (k, val) => setV((current) => ({ ...current, [k]: val }));
  const field = { background: C.ground, border: `1px solid ${C.feltEdge}`, color: C.paper, fontSize: 15, padding: '9px 10px', width: '100%' };

  const accountById = useMemo(
    () => new Map(accounts.map((account) => [account.id, account])), [accounts]);
  const unitById = useMemo(
    () => new Map(units.map((unit) => [unit.id, unit])), [units]);
  const selectedAccountCandidate = accountById.get(v.accountId);
  const selectedAccount = selectedAccountCandidate?.branchId === v.branchId
    ? selectedAccountCandidate
    : null;
  const missingCurrentAccount = Boolean(
    order?.accountId && v.accountId === order.accountId && !selectedAccount,
  );
  const branchAccounts = accounts
    .filter((account) => account.branchId === v.branchId
      && (account.active !== false || account.id === order?.accountId))
    .sort((a, b) => a.name.localeCompare(b.name));
  const accountUnits = units
    .filter((unit) => unit.branchId === v.branchId && unit.accountId === v.accountId
      && (activeUnitPath(unit, unitById) || unit.id === order?.accountUnitId))
    .sort((a, b) => unitPath(a, unitById).localeCompare(unitPath(b, unitById)));
  const selectedUnitCandidate = unitById.get(v.accountUnitId);
  const selectedUnit = selectedUnitCandidate?.branchId === v.branchId
    && selectedUnitCandidate?.accountId === v.accountId
    ? selectedUnitCandidate
    : null;
  const missingCurrentUnit = Boolean(
    order?.accountUnitId && v.accountUnitId === order.accountUnitId && !selectedUnit,
  );
  const derivedOwner = selectedAccount
    ? eligibleOwner(selectedAccount, selectedUnit, unitById, people, v.branchId)
    : null;
  const legacyOwner = !v.accountId && order
    ? (people.find((person) => person.id === order.ownerId || person.initials === order.owner) || null)
    : null;
  const ownerLabel = selectedAccount
    ? (derivedOwner ? `${derivedOwner.initials} · ${derivedOwner.name}` : 'Unowned · no eligible account owner')
    : 'Unowned · link an account to determine ownership';

  /* An order with no branch is invisible to everyone, including whoever
   * wrote it, so it cannot be saved without one. New orders must use an
   * account record. An unlinked legacy order may retain its old label until
   * a manager deliberately links it. */
  const rateIsValid = v.rate === '' || Number.isFinite(Number(v.rate));
  const ready = Boolean(rateIsValid && v.branchId && (
    selectedAccount
    || missingCurrentAccount
    || (order && !v.accountId && v.accountName.trim())
  ));

  const chooseBranch = (branchId) => setV((current) => ({
    ...current,
    branchId,
    accountId: '',
    accountName: '',
    accountUnitId: '',
    accountUnitName: '',
    site: current.site === current.accountUnitName ? '' : current.site,
  }));

  const chooseAccount = (accountId) => {
    const account = accountById.get(accountId);
    setV((current) => ({
      ...current,
      accountId,
      accountName: account?.name || '',
      accountUnitId: '',
      accountUnitName: '',
      site: current.site === current.accountUnitName ? '' : current.site,
    }));
  };

  const chooseUnit = (accountUnitId) => {
    const unit = unitById.get(accountUnitId);
    setV((current) => ({
      ...current,
      accountUnitId,
      accountUnitName: unit?.name || '',
      site: !current.site || current.site === current.accountUnitName
        ? unit?.name || ''
        : current.site,
    }));
  };

  const submit = () => {
    if (!ready) return;
    if (linkedEmailOrder) {
      onSave({
        role: v.role || null,
        shift: v.shift || null,
        days: v.days || null,
        hours: v.hours || null,
        rate: v.rate === '' ? null : Number(v.rate),
        note: v.note || null,
        isPriority: v.isPriority,
      });
      return;
    }
    const accountId = selectedAccount?.id || (missingCurrentAccount ? v.accountId : null);
    const accountName = selectedAccount?.name || v.accountName.trim() || null;
    const accountUnitId = selectedUnit?.id || (missingCurrentUnit ? v.accountUnitId : null);
    const accountUnitName = selectedUnit?.name
      || (missingCurrentUnit ? v.accountUnitName || order?.accountUnitName : null)
      || null;
    const owner = selectedAccount
      ? derivedOwner
      : (!accountId && order ? legacyOwner : null);

    onSave({
      ...v,
      ...(accountId ? { source: 'manual' } : {}),
      account: accountName,
      accountId,
      accountName,
      accountUnitId,
      accountUnitName,
      ownerId: owner?.id || (!accountId && order?.ownerId) || null,
      owner: owner?.initials || (!accountId && order?.owner) || null,
      rate: v.rate === '' ? null : Number(v.rate),
      site: v.site || null,
      hours: v.hours || null,
      note: v.note || null,
    });
  };

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'var(--app-overlay)', zIndex: 50 }}
         className="job-order-backdrop flex items-end justify-center">
      <div style={{ background: C.felt, border: `1px solid ${C.feltEdge}`, width: '100%', maxWidth: 460, maxHeight: '90vh' }}
           className="job-order-form rounded-t p-4 overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <div style={{ fontFamily: '"Barlow Condensed", sans-serif', fontSize: 22, color: C.paper }}>
            {order ? 'Edit order' : 'New job order'}
          </div>
          <button onClick={onClose} aria-label="Close"><X size={20} color={C.chalkDim} /></button>
        </div>

        <div className="flex flex-col gap-3">
          {branches.length > 1 && (
            <select value={v.branchId || ''} onChange={(e) => chooseBranch(e.target.value)}
              disabled={linkedEmailOrder} style={field} className="rounded" aria-label="Branch">
              {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          )}
          <label style={{ color: C.chalkDim, fontSize: 13 }}>
            Account
            <select value={v.accountId} onChange={(e) => chooseAccount(e.target.value)}
              disabled={linkedEmailOrder}
              style={{ ...field, marginTop: 5, opacity: linkedEmailOrder ? 0.72 : 1 }}
              className="rounded" autoFocus aria-label="Account">
              {!v.accountId && (
                <option value="" disabled={!order}>
                  {order?.account ? `Legacy · ${order.account}` : 'Choose an account'}
                </option>
              )}
              {missingCurrentAccount && (
                <option value={v.accountId}>{v.accountName || order?.account || 'Unavailable account'} (unavailable)</option>
              )}
              {branchAccounts.map((account) => (
                <option key={account.id} value={account.id}>
                  {account.name}{account.active === false ? ' (archived)' : ''}
                </option>
              ))}
            </select>
          </label>
          {!v.accountId && order && (
            <label style={{ color: C.chalkDim, fontSize: 13 }}>
              Legacy account label
              <input value={v.accountName} onChange={(e) => set('accountName', e.target.value)}
                style={{ ...field, marginTop: 5 }} className="rounded" aria-label="Legacy account label" />
            </label>
          )}
          {v.branchId && branchAccounts.length === 0 && !missingCurrentAccount && (
            <div style={{ background: 'var(--app-warning-soft)', color: 'var(--app-warning-text)', fontSize: 13, padding: '8px 10px' }}
                 className="rounded flex items-start gap-2">
              <AlertTriangle size={15} style={{ flexShrink: 0, marginTop: 1 }} />
              Add an active account for this branch before linking or creating an order.
            </div>
          )}

          <label style={{ color: C.chalkDim, fontSize: 13 }}>
            Location / department (optional)
            <select value={v.accountUnitId} onChange={(e) => chooseUnit(e.target.value)}
              disabled={linkedEmailOrder || !v.accountId || (!accountUnits.length && !missingCurrentUnit)}
              style={{ ...field, marginTop: 5, opacity: !v.accountId ? 0.6 : 1 }}
              className="rounded" aria-label="Location or department">
              <option value="">Entire account</option>
              {missingCurrentUnit && (
                <option value={v.accountUnitId}>{v.accountUnitName || 'Unavailable location'} (unavailable)</option>
              )}
              {accountUnits.map((unit) => (
                <option key={unit.id} value={unit.id}>
                  {unitPath(unit, unitById)}{!activeUnitPath(unit, unitById) ? ' (archived)' : ''}
                </option>
              ))}
            </select>
          </label>

          {linkedEmailOrder ? (
            <div style={{ background: 'var(--app-accent-soft)', color: C.chalkDim, fontSize: 13, padding: '8px 10px' }}
                 className="rounded flex items-start gap-2">
              <Mail size={15} style={{ flexShrink: 0, marginTop: 1 }} />
              Account routing is locked to the source day-board task. You can still update the order details below.
            </div>
          ) : null}

          <div style={{ background: C.rail, border: `1px solid ${C.feltEdge}`, padding: '9px 10px' }}
               className="rounded" aria-live="polite">
            <div style={{ color: C.chalkDim, fontSize: 12 }}>Owner from account setup</div>
            <div style={{ color: derivedOwner || legacyOwner ? C.paper : C.edgeAmber, fontSize: 14, marginTop: 2 }}>
              {ownerLabel}
            </div>
          </div>

          <input value={v.site} onChange={(e) => set('site', e.target.value)} placeholder="Site or building, optional"
                 disabled={linkedEmailOrder}
                 style={{ ...field, opacity: linkedEmailOrder ? 0.72 : 1 }} className="rounded" aria-label="Site" />
          <input value={v.role} onChange={(e) => set('role', e.target.value)} placeholder="Role, for example Reach or Sit-down"
                 style={field} className="rounded" aria-label="Role" />

          <div className="job-order-field-row flex gap-2">
            <select value={v.shift} onChange={(e) => set('shift', e.target.value)} style={field} className="rounded" aria-label="Shift">
              {['1st', '2nd', '3rd', 'Weekend'].map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
            <input value={v.days} onChange={(e) => set('days', e.target.value)} placeholder="M-F"
                   style={field} className="rounded" aria-label="Days" />
          </div>

          <div className="job-order-field-row flex gap-2">
            <input value={v.hours} onChange={(e) => set('hours', e.target.value)} placeholder="6:00am-2:30pm"
                   style={field} className="rounded" aria-label="Hours" />
            <input value={v.rate} onChange={(e) => set('rate', e.target.value)} placeholder="Rate" inputMode="decimal"
                   style={{ ...field, borderColor: rateIsValid ? C.feltEdge : C.edgeRed }}
                   className="rounded" aria-label="Pay rate" aria-invalid={!rateIsValid} />
          </div>

          {!order && (
            <input value={v.openings} onChange={(e) => set('openings', Math.min(200, Math.max(1, Number(e.target.value) || 1)))}
                   type="number" min="1" max="200" placeholder="Openings"
                   style={field} className="rounded" aria-label="Number of openings" />
          )}

          <input value={v.note} onChange={(e) => set('note', e.target.value)} placeholder="Note, optional"
                 style={field} className="rounded" aria-label="Note" />

          <button onClick={() => set('isPriority', !v.isPriority)}
            style={{
              border: `1px solid ${v.isPriority ? C.edgeAmber : C.feltEdge}`,
              color: v.isPriority ? C.edgeAmber : C.chalkDim, fontSize: 14, padding: '9px',
            }}
            className="rounded flex items-center justify-center gap-2">
            <Star size={14} fill={v.isPriority ? C.edgeAmber : 'none'} color={v.isPriority ? C.edgeAmber : C.chalkDim} />
            Priority account
          </button>

          <button
            onClick={submit}
            disabled={!ready}
            style={{
              background: ready ? C.signal : C.feltEdge,
              color: ready ? 'var(--app-on-accent)' : C.chalkDim, fontSize: 15,
            }}
            className="w-full py-3 rounded">
            {order ? 'Save changes' : 'Add job order'}
          </button>
        </div>
      </div>
    </div>
  );
}
