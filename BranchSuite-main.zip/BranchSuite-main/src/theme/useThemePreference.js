import { useCallback, useEffect, useRef, useState } from 'react';
import { isConfigured } from '../lib/firebaseApp';
import {
  applyTheme, cacheTheme, DEFAULT_THEME, INITIAL_THEME, normalizeTheme, readCachedTheme,
} from './themes';

export function useThemePreference(user) {
  const uid = user?.uid || null;
  const [theme, setTheme] = useState(INITIAL_THEME);
  const [syncState, setSyncState] = useState('local');
  const pendingTheme = useRef(null);
  const saveVersion = useRef(0);
  const identityVersion = useRef(0);
  const currentUid = useRef(uid);
  currentUid.current = uid;

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  useEffect(() => {
    const subscriptionIdentity = ++identityVersion.current;
    saveVersion.current += 1;
    pendingTheme.current = null;

    if (!isConfigured || !uid) {
      setSyncState('local');
      return undefined;
    }

    let active = true;
    let unsubscribe = null;
    setTheme(readCachedTheme(uid));
    setSyncState('loading');

    import('./themePreference').then(({ subscribeToThemePreference }) => {
      if (!active) return;
      unsubscribe = subscribeToThemePreference(uid, (snapshot) => {
        if (!active || currentUid.current !== uid || identityVersion.current !== subscriptionIdentity) return;

        // An offline "missing" snapshot cannot tell us the user has no saved
        // preference, so retain the durable local cache until the server can.
        if (!snapshot.exists && snapshot.fromCache) {
          setSyncState('offline');
          return;
        }

        const savedTheme = snapshot.theme || DEFAULT_THEME;
        if (pendingTheme.current && savedTheme !== pendingTheme.current) return;
        if (savedTheme === pendingTheme.current && !snapshot.hasPendingWrites) {
          pendingTheme.current = null;
        }
        setTheme(savedTheme);
        cacheTheme(savedTheme, uid);
        setSyncState(snapshot.hasPendingWrites
          ? (snapshot.fromCache ? 'queued' : 'saving')
          : (snapshot.fromCache ? 'offline' : 'saved'));
      }, () => {
        if (active) {
          pendingTheme.current = null;
          setSyncState('offline');
        }
      });
    }).catch(() => {
      if (active) {
        pendingTheme.current = null;
        setSyncState('offline');
      }
    });

    return () => {
      active = false;
      unsubscribe?.();
    };
  }, [uid]);

  const chooseTheme = useCallback((nextTheme) => {
    const validTheme = normalizeTheme(nextTheme);
    if (!validTheme) return;
    const requestUid = uid;
    const requestIdentity = identityVersion.current;
    const requestVersion = ++saveVersion.current;

    pendingTheme.current = validTheme;
    setTheme(validTheme);
    cacheTheme(validTheme, uid);

    if (!isConfigured || !uid) {
      pendingTheme.current = null;
      setSyncState('local');
      return;
    }

    setSyncState('saving');
    import('./themePreference')
      .then(({ saveThemePreference }) => saveThemePreference(requestUid, validTheme))
      .then(() => {
        if (currentUid.current !== requestUid || identityVersion.current !== requestIdentity
          || saveVersion.current !== requestVersion) return;
        pendingTheme.current = null;
        setSyncState('saved');
      })
      .catch(() => {
        if (currentUid.current !== requestUid || identityVersion.current !== requestIdentity
          || saveVersion.current !== requestVersion) return;
        pendingTheme.current = null;
        setSyncState('offline');
      });
  }, [uid]);

  return { theme, chooseTheme, syncState };
}
