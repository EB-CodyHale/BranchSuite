export const DEFAULT_THEME = 'daylight';

export const THEMES = Object.freeze([
  {
    id: 'daylight',
    name: 'Daylight',
    description: 'Bright, crisp, and optimized for the wall board.',
    themeColor: '#f4f7fb',
  },
  {
    id: 'soft-slate',
    name: 'Soft Slate',
    description: 'Cool neutral surfaces with reduced glare.',
    themeColor: '#e8edf2',
  },
  {
    id: 'night',
    name: 'Night',
    description: 'A focused dark theme for lower-light spaces.',
    themeColor: '#101820',
  },
]);

const THEME_IDS = new Set(THEMES.map((theme) => theme.id));
const RECENT_THEME_KEY = 'branchsuite:theme:v1';
const userThemeKey = (uid) => `${RECENT_THEME_KEY}:${uid}`;

export function normalizeTheme(value) {
  return THEME_IDS.has(value) ? value : null;
}

function readStorage(key) {
  if (typeof window === 'undefined') return null;
  try {
    return normalizeTheme(window.localStorage.getItem(key));
  } catch {
    return null;
  }
}

export function readCachedTheme(uid) {
  return (uid ? readStorage(userThemeKey(uid)) : null)
    || readStorage(RECENT_THEME_KEY)
    || DEFAULT_THEME;
}

export function cacheTheme(theme, uid) {
  const validTheme = normalizeTheme(theme) || DEFAULT_THEME;
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(RECENT_THEME_KEY, validTheme);
    if (uid) window.localStorage.setItem(userThemeKey(uid), validTheme);
  } catch {
    // A blocked or full localStorage should never prevent theme selection.
  }
}

export function applyTheme(theme) {
  const validTheme = normalizeTheme(theme) || DEFAULT_THEME;
  if (typeof document !== 'undefined') {
    document.documentElement.dataset.theme = validTheme;
    const themeColor = THEMES.find((option) => option.id === validTheme)?.themeColor;
    if (themeColor) document.querySelector('meta[name="theme-color"]')?.setAttribute('content', themeColor);
  }
  return validTheme;
}

// This runs before React paints, using the last local choice to avoid a flash
// while authentication and the Firestore preference subscription catch up.
export const INITIAL_THEME = applyTheme(readCachedTheme());
