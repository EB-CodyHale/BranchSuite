import {
  doc, getFirestore, onSnapshot, serverTimestamp, setDoc,
} from 'firebase/firestore';
import { app } from '../lib/firebaseApp';
import { normalizeTheme } from './themes';

const preferences = getFirestore(app);

export function subscribeToThemePreference(uid, onValue, onError) {
  const preferenceRef = doc(preferences, 'userPreferences', uid);
  return onSnapshot(
    preferenceRef,
    { includeMetadataChanges: true },
    (snapshot) => onValue({
      exists: snapshot.exists(),
      theme: normalizeTheme(snapshot.data()?.theme),
      fromCache: snapshot.metadata.fromCache,
      hasPendingWrites: snapshot.metadata.hasPendingWrites,
    }),
    onError,
  );
}

export function saveThemePreference(uid, theme) {
  return setDoc(doc(preferences, 'userPreferences', uid), {
    theme,
    updatedAt: serverTimestamp(),
  }, { merge: true });
}
