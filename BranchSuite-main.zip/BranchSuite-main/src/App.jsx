import React, { lazy, Suspense, useEffect, useRef, useState } from 'react';
import {
  Briefcase, Check, ChevronDown, CloudSun, ClipboardList, LogOut, Moon, Palette, Sun,
} from 'lucide-react';
import { isConfigured, auth, signInWithEmail, sendResetEmail, signOutOfBoard } from './lib/firebase';
import { THEMES } from './theme/themes';
import { useThemePreference } from './theme/useThemePreference';

const TeamBoard = lazy(() => import('./components/TeamBoard'));
const JobOrders = lazy(() => import('./components/JobOrders'));

const THEME_ICONS = { daylight: Sun, 'soft-slate': CloudSun, night: Moon };

export default function App() {
  const [tab, setTab] = useState('board');
  const [boardLayout, setBoardLayout] = useState('queue');
  const [boardHeaderTarget, setBoardHeaderTarget] = useState(null);
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(isConfigured);
  const { theme, chooseTheme, syncState } = useThemePreference(user);

  useEffect(() => {
    if (!isConfigured) return undefined;
    return auth.onAuthStateChanged((u) => { setUser(u); setChecking(false); });
  }, []);

  if (checking) {
    return <Shell><div className="app-loading">Checking your sign in</div></Shell>;
  }

  // Real auth is on and nobody is signed in.
  if (isConfigured && !user) {
    return <Shell><SignIn /></Shell>;
  }

  return (
    <Shell>
      {!(tab === 'board' && boardLayout === 'wall') && <header className="app-header">
        <div className="app-brand">BranchSuite</div>
        <nav className="app-nav" aria-label="Primary">
          <TabButton active={tab === 'board'} onClick={() => setTab('board')} icon={<ClipboardList size={16} />}>
            Day board
          </TabButton>
          <TabButton active={tab === 'orders'} onClick={() => setTab('orders')} icon={<Briefcase size={16} />}>
            Job orders
          </TabButton>
        </nav>
        <div className="app-header-spacer" />
        {tab === 'board' ? <div className="app-board-controls" ref={setBoardHeaderTarget} /> : null}
        <div className="app-live-state" title={isConfigured ? 'Firebase-backed board' : 'Local preview mode'}>
          <span className={isConfigured ? 'app-live-dot' : 'app-live-dot is-local'} />
          <span>{isConfigured ? 'Cloud board' : 'Local preview'}</span>
        </div>
        <ThemeMenu
          theme={theme}
          onTheme={chooseTheme}
          syncState={syncState}
          user={isConfigured ? user : null}
        />
      </header>}

      <Suspense fallback={<div className="app-loading">Loading the board</div>}>
        <div className={`app-view app-view-${tab}`}>
          {tab === 'board'
            ? <TeamBoard layout={boardLayout} onLayoutChange={setBoardLayout} headerControlsTarget={boardHeaderTarget}
              onOpenJobOrders={() => { setBoardLayout('queue'); setTab('orders'); }} />
            : <JobOrders />}
        </div>
      </Suspense>
    </Shell>
  );
}

/* Wrong password and unknown address say the same thing on purpose. Telling
 * them apart turns the sign in form into a way to ask whether an address has
 * an account here. */
const AUTH_MESSAGES = {
  'auth/invalid-email': 'That does not look like an email address.',
  'auth/invalid-credential': 'Wrong email or password.',
  'auth/wrong-password': 'Wrong email or password.',
  'auth/user-not-found': 'Wrong email or password.',
  'auth/missing-password': 'Type your password.',
  'auth/user-disabled': 'That account is turned off. An admin can re-enable it in the Firebase console.',
  'auth/too-many-requests': 'Too many tries. Wait a few minutes, or reset your password.',
  'auth/network-request-failed': 'Could not reach Firebase. Check the connection and try again.',
};

function authMessage(err) {
  return AUTH_MESSAGES[err?.code] || 'Sign in failed. The browser console has the exact error.';
}

function SignIn() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState(null);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setNote(null);
    try {
      // On success the auth listener in App swaps this whole screen out,
      // so there is nothing to reset here.
      await signInWithEmail(email, password);
    } catch (err) {
      console.error(err);
      setNote({ bad: true, text: authMessage(err) });
      setBusy(false);
    }
  }

  async function reset() {
    if (!email.trim()) {
      setNote({ bad: true, text: 'Type your email address first, then use the reset link.' });
      return;
    }
    setBusy(true);
    setNote(null);
    try {
      await sendResetEmail(email);
    } catch (err) {
      console.error(err);
      if (err?.code === 'auth/invalid-email') {
        setNote({ bad: true, text: AUTH_MESSAGES['auth/invalid-email'] });
        setBusy(false);
        return;
      }
      // Anything else is reported the same as success, for the reason above.
    }
    setNote({ bad: false, text: 'If that address has an account, a reset link is on its way. Check junk mail.' });
    setBusy(false);
  }

  return (
    <div className="sign-in-screen">
      <form onSubmit={submit} className="sign-in-card">
        <h1>
          BranchSuite
        </h1>
        <p className="sign-in-copy">
          Sign in with your work address. That address is how the board knows
          which branches you are on, and how a reply in the shared mailbox gets
          matched back to you.
        </p>

        <div className="flex flex-col gap-3">
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                 className="sign-in-field" placeholder="you@company.com"
                 autoComplete="username" aria-label="Work email" autoFocus required />
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                 className="sign-in-field" placeholder="Password"
                 autoComplete="current-password" aria-label="Password" required />
          <button type="submit" disabled={busy}
            className="sign-in-submit">
            {busy ? 'Working' : 'Sign in'}
          </button>
        </div>

        {note && (
          <p className={note.bad ? 'sign-in-note is-error' : 'sign-in-note'} role="status">
            {note.text}
          </p>
        )}

        <button type="button" onClick={reset} disabled={busy}
          className="sign-in-reset">
          Forgot your password
        </button>
      </form>
    </div>
  );
}

function Shell({ children }) {
  return <div className="app-shell">{children}</div>;
}

function TabButton({ active, onClick, icon, children }) {
  return (
    <button onClick={onClick} aria-current={active ? 'page' : undefined} className={`app-nav-button${active ? ' is-active' : ''}`}>
      {icon}<span>{children}</span>
    </button>
  );
}

function ThemeMenu({ theme, onTheme, syncState, user }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);
  const triggerRef = useRef(null);
  const optionRefs = useRef([]);
  const activeTheme = THEMES.find((option) => option.id === theme) || THEMES[0];

  useEffect(() => {
    if (!open) return undefined;
    const selectedIndex = Math.max(0, THEMES.findIndex((option) => option.id === theme));
    const focusFrame = window.requestAnimationFrame(() => optionRefs.current[selectedIndex]?.focus());
    const closeOnPointer = (event) => {
      if (!menuRef.current?.contains(event.target)) setOpen(false);
    };
    const closeOnEscape = (event) => {
      if (event.key !== 'Escape') return;
      setOpen(false);
      triggerRef.current?.focus();
    };
    document.addEventListener('pointerdown', closeOnPointer);
    document.addEventListener('keydown', closeOnEscape);
    return () => {
      window.cancelAnimationFrame(focusFrame);
      document.removeEventListener('pointerdown', closeOnPointer);
      document.removeEventListener('keydown', closeOnEscape);
    };
  }, [open, theme]);

  function moveThemeFocus(event, index) {
    let nextIndex = null;
    if (event.key === 'ArrowDown' || event.key === 'ArrowRight') nextIndex = (index + 1) % THEMES.length;
    if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') nextIndex = (index - 1 + THEMES.length) % THEMES.length;
    if (event.key === 'Home') nextIndex = 0;
    if (event.key === 'End') nextIndex = THEMES.length - 1;
    if (nextIndex === null) return;
    event.preventDefault();
    onTheme(THEMES[nextIndex].id);
    optionRefs.current[nextIndex]?.focus();
  }

  const syncLabel = syncState === 'loading'
    ? 'Checking your saved preference…'
    : syncState === 'saving'
      ? 'Saving preference…'
      : syncState === 'queued'
        ? 'Saved here; it will sync when you’re online.'
        : syncState === 'offline'
          ? 'Saved on this device; cloud sync is unavailable.'
          : user
            ? 'Saved to your profile.'
            : 'Saved on this device.';
  const syncNeedsAttention = syncState === 'offline' || syncState === 'queued';

  return (
    <div className="profile-menu-wrap" ref={menuRef}>
      <button
        type="button"
        className="app-user-trigger"
        ref={triggerRef}
        aria-controls="profile-appearance-menu"
        aria-expanded={open}
        aria-label={`${user ? 'Profile and appearance' : 'Appearance'}; ${activeTheme.name} theme selected`}
        onClick={() => setOpen((value) => !value)}
      >
        {user ? (
          <>
            <span className="app-avatar" aria-hidden="true">{(user.email || '?').slice(0, 1).toUpperCase()}</span>
            <span className="app-user-email">{user.email}</span>
          </>
        ) : <Palette size={18} aria-hidden="true" />}
        <ChevronDown size={14} aria-hidden="true" />
      </button>

      {open ? (
        <section id="profile-appearance-menu" className="profile-menu" aria-label="Profile and appearance">
          {user ? (
            <header className="profile-menu-header">
              <span className="app-avatar" aria-hidden="true">{(user.email || '?').slice(0, 1).toUpperCase()}</span>
              <span><strong>Signed in</strong><small>{user.email}</small></span>
            </header>
          ) : null}

          <div className="profile-menu-heading"><Palette size={15} aria-hidden="true" /><span>Appearance</span></div>
          <div className="theme-options" role="radiogroup" aria-label="Color theme">
            {THEMES.map((option, index) => {
              const ThemeIcon = THEME_ICONS[option.id];
              const selected = option.id === theme;
              return (
                <button
                  key={option.id}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  tabIndex={selected ? 0 : -1}
                  ref={(element) => { optionRefs.current[index] = element; }}
                  className={`theme-option theme-option-${option.id}${selected ? ' is-selected' : ''}`}
                  onClick={() => onTheme(option.id)}
                  onKeyDown={(event) => moveThemeFocus(event, index)}
                >
                  <span className="theme-option-icon"><ThemeIcon size={16} aria-hidden="true" /></span>
                  <span className="theme-option-copy"><strong>{option.name}</strong><small>{option.description}</small></span>
                  {selected ? <Check className="theme-option-check" size={16} aria-hidden="true" /> : null}
                </button>
              );
            })}
          </div>
          <p className={`theme-sync-state${syncNeedsAttention ? ' is-offline' : ''}`} aria-live="polite">{syncLabel}</p>

          {user ? (
            <button type="button" onClick={() => signOutOfBoard()} className="profile-sign-out">
              <LogOut size={15} aria-hidden="true" /> Sign out
            </button>
          ) : null}
        </section>
      ) : null}
    </div>
  );
}
