# Whiteboard accounts and openings — review draft

Source: `IMG_3418.JPEG`, transcribed September 10, 2026.

This is a review draft, not import-ready data. A question mark means the
handwriting or the relationship between two notes is uncertain. I treated a
blank underline as a possible open slot, but the team should confirm that
convention before any headcount is entered. Initials are preserved as board
notes and are not assumed to be open positions.

## Named accounts and sites

| Account / site | Opening | Shift / schedule | Pay | Possible blank slots | Board notes / items to confirm |
| --- | --- | --- | --- | ---: | --- |
| GEODIS — 1536 | Order picker / sit-down (`OP - Sit`) | 1st; 6:00 a.m.–2:30 p.m. | $19.00 | 2 | Priority star. Days are not clearly written. |
| GEODIS — 1500 | Lift / EPJ / reach; resume required | 1st | $19.00 | 1 | `AK` appears on another slot. A small note may say Raymond. |
| GEODIS — 1500 | Lift / EPJ / reach; resume required | 2nd | $21.00 | about 3 | Confirm whether the heading says `Lift`. |
| TD Kane — Lockport | Reach | 2nd; approximately 1:30 p.m.–10:00 p.m. | about $20.50 | 3 | Marker `PR`; priority star; note may mention loaders. |
| TD Kane — Lockport | Reach | 3rd | $22.00 | 1 | Exact hours are not shown. |
| Bridgestone | Reach | 3rd | $22.00 | 0 clearly visible | `AO/AP?` and `DW` shown; marker `PV`; `HSD?` note. |
| Novolex — Romeoville | Forklift | 1st; Sun–Thu | $21.00 | 0 clearly visible | `RD`, `QS/AS?`, and `DD` shown. |
| Novolex — Romeoville | Forklift | 2nd; Sun–Thu | $27.50? | 0 clearly visible | `LR`, `CB`, and `DC` shown. Confirm the unusually high written rate. |
| GEA — Romeoville | Reach | 1st; M–F; 6:00 a.m.–2:30 p.m. | $20.00 | 2 | Marker `PV`; note appears to say `+3 resumes`. |
| ODW Dry | Forklift; stand-up/reach/Raymond equipment | 1st; 7:00 a.m.–3:00 p.m. | $19.00/hr | 1 | `BB` is written beside the account. |
| ODW Cold — Romeoville | Stand-up; 30-degree cold environment | 2nd; M–F; 2:00 p.m.–12:00 a.m. | $20.50 | 0 clearly visible | `JC` shown; circled marker looks like `NIXW?`. |
| Penske BB | Clerk | 1st; 8:00 a.m.–4:00 p.m. | Not shown | 0 clearly visible | `VG` shown; marker `PR`. |
| Penske BB | Clerk | 2nd; 6:30 p.m.–3:00 a.m. | Not shown | 1 | Marker `PR`. |
| Penske BB | General labor | 2nd; M–F; 4:00 p.m.–12:30 a.m. | $22.50 | about 4 | `AM`, `JG`, `RO`, and `JR` shown. Confirm whether these belong to this opening or the clerk row. |
| Ryder (Diageo) — Plainfield | Role not written | D shift; Wed–Sat | $20.50 | 2 | `CH` shown; marker appears to be `PR`. |
| Ryder (Diageo) — Plainfield | Role not written | F shift; Sun–Wed | $20.50 | 1 | `TJ` and `MB` shown. |
| Ryder (Diageo) — Plainfield | Role not written | E shift; Wed–Sat | $22.50 | 1 | `MH` shown. |
| Diageo — Plainfield | Role not written; shift A | AM, likely 6:00 a.m.–6:00 p.m.? | $18.00 | several | Marker `LUZ`. Confirm hours and slot count. |
| Diageo — Plainfield | Role not written; shift B | PM, likely 6:00 p.m.–6:00 a.m.? | $18.50 | several | Marker `LUZ`. Confirm hours and slot count. |
| Diageo — Plainfield | Role not written; shift C | AM | $18.00 | several | Marker `LUZ`. Hours are not legible. |
| Diageo — Plainfield | Role not written; shift D | PM | $18.50 | several | Marker `LUZ`. Hours are not legible. |
| Quality-Craft — BB | Role not written, possibly general labor | 8:00 a.m.–5:00 p.m.; Sep 14–19? | $18.00 + $1 attendance | 5 | Circled marker reads `HV/HL?`. Confirm whether the date is a work period or start window. |
| WestRock — BB | General labor (`GLs`) | 1st; M–F | $17.05 | at least 1 | Priority star; circled marker `LJ/LS?`. |
| WestRock — BB | General labor (`GLs`) | 2nd; M–F | $18.05 | unclear | Note appears to say `AL 9/1 starts`. |
| Veritiv — Lockport | Stand-up | 2nd; M–F | $20.25 | 1 | Circled marker `NIXW?`; `AH/AT 9/8?` and `JS 9/4 interview` notes. |
| S&S — Woodridge | Sit-down / reach / LTO | 8:00 a.m.–5:00 p.m.; M–F | $19.25 | 1 | Account may be `S&S Worldwide`; circled marker `NIXW?`. |
| S&S — Woodridge | Reach / order picker / inventory | 8:00 a.m.–5:00 p.m.; M–F | $19.25 | 1 | Confirm whether this is one combined opening or separate Reach, OP, and Inventory roles. |
| Penske Bread — Lockport | Role not written | 3rd; 9:00 p.m.–7:00 a.m.; days look like Tue/Wed/Sat/Sun? | $19.50 | 1 | `ER?`, `JG`, `JH`, and `GT` shown; marker `LUZ`. Confirm days. |
| WeatherTech Lake — BB | Machine operator (`Sewer/Sawer/Sauer?`) | 2nd | $20.50 | 5 | Priority star. Confirm the parenthetical specialty. |
| Armada | Stand-up | 2nd | $22.75 | 4 | `FZ` shown; priority star. |
| Armada | Dry | 2nd | Not shown | 1 | Confirm whether `Dry` is a department or role. |
| Armada | Cycle counter | 1st | Not shown | 1 | — |
| Crane — McCook | Clerk | 3rd; 9:00 p.m.–7:30 a.m. | $21.50 | 1 | A date near the heading looks like `8/14`. |
| Crane — McCook | Label appears to read `WEPM?` | possibly 5:00 p.m.–5:30 a.m. | about $22.50? | 1 | Role label, time, and rate all need confirmation. |
| Crane — McCook | Additional role not shown | 5:00 a.m.–1:30 p.m.; 1:00 p.m.–9:30 p.m.; 9:00 p.m.–5:30 a.m. | three diagonal rates are not reliably legible | unclear | The rates may be roughly $22.60, $23.60, and $24.50, but should not be entered without confirmation. |
| Berlin — Lockport | Sit-down; possibly also general labor | M–F; 7:00 a.m.–3:30 p.m. | $20.00 | 1 | `FE/CE?` and `GL` shown. Confirm whether `GL` is a second role. |
| Wayfair | `WT` — role abbreviation not expanded | 5:30 p.m.–2:30 a.m. | $26.50 | 0 clearly visible | **PAUSE**; marker `LS/LD?`; note appears `NHO 9/1 or 9/11? @ 8 a.m. Cherry`. |

## Account not identified on the board

These look more like requisition counts than account names.

| Location / label | Opening | Shift / schedule | Pay | Board notes |
| --- | --- | --- | --- | --- |
| BB — `4 WW` | Four warehouse workers / general labor? | 1st; 6:00 a.m.–2:30 p.m. | $18.00 | `AR` shown. The client/account name is not visible. |
| Bolingbrook — `2 WW` | Two warehouse workers? | 1st | $18.00 | Marker `LUZ`; priority star. Client/account is not visible. |
| Bolingbrook — `2 WW` | Two warehouse workers? | 2nd | $19.00? | Confirm whether this is part of the same two-person request. |
| Bolingbrook — `2 WW` | Two warehouse workers? | 3rd | $19.50 | `LG? 9/10?` shown; about two blank lines. |

## Highest-priority review questions

1. Confirm whether a blank underline means an open headcount slot.
2. Supply the missing account for the `4 WW` and `2 WW` Bolingbrook notes.
3. Confirm the Crane `WEPM?` role and the three small diagonal pay rates.
4. Confirm Novolex second-shift pay (`$27.50` as written).
5. Confirm the WeatherTech specialty (`Sewer`, `Sawer`, or something else).
6. Confirm the Diageo A/B/C/D hours and the roles those shifts represent.
7. Confirm whether Wayfair should be excluded because it is marked `PAUSE`.
